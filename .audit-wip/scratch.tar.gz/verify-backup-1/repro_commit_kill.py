"""Kill del processo durante il commit di UN evento (fra scrittura nel DB e cancellazione del -journal)."""
import shutil, sqlite3, subprocess, sys, tempfile
from pathlib import Path
from app import backup_copy
from app.db import Database

SCRATCH = Path(__file__).parent
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="ck_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7"); db.add_person("Mario (prima del backup HA)", None); db.close()
backup_copy.DB_PATH = path
backup_copy.main()
db = Database(path, "0.21.7"); db.add_person("Anna (dopo il backup HA)", None); db.close()

child = (
    "import sys; sys.path.insert(0, 'axis_access_manager')\n"
    "from app.db import Database\n"
    f"db = Database({str(path)!r}, '0.21.7')\n"
    "db.add_event(ts='2026-10-28T10:00:00+00:00', kind='concesso', card='1234')\n"
)
journal = str(path) + "-journal"
r = subprocess.run(["strace", "-qq", "-f", "-o", "/dev/null", "-P", journal, "-e", "trace=unlink,unlinkat",
                    "-e", "inject=unlink,unlinkat:error=EPERM:signal=SIGKILL", sys.executable, "-c", child],
                   capture_output=True, text=True)
print("exit:", r.returncode, r.stderr[-300:])
j = Path(journal)
print("journal presente:", j.exists(), j.stat().st_size if j.exists() else 0, "byte; primo byte:", j.read_bytes()[:1] if j.exists() else None)
probe = work / "probe"; probe.mkdir()
shutil.copy(path, probe / path.name); shutil.copy(j, probe / j.name)
pc = sqlite3.connect(probe / path.name)
print("apertura normale:", pc.execute("PRAGMA quick_check").fetchone()[0], [r[0] for r in pc.execute("SELECT name FROM persons")])
pc.close()
print("is_healthy:", backup_copy.is_healthy(path))
try:
    sqlite3.connect(f"file:{path}?mode=ro", uri=True).execute("PRAGMA quick_check").fetchone()
except sqlite3.Error as e:
    print("errore mode=ro:", type(e).__name__, e, getattr(e, "sqlite_errorname", ""))
db = Database(path, "0.21.7")
print("Database.recovered:", db.recovered)
print("persone dopo il riavvio:", [p["name"] for p in db.list_persons()])
print("file:", sorted(p.name for p in work.iterdir()))

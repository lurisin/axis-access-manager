import asyncio, tempfile, sys
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
import test_full_restore as tfr
from test_backup import Plant

async def main(do_get):
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    ctrl = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
    plant = Plant(db, ctrl, settings, tmp / "backup")
    tfr.bench_like(ctrl)
    await plant.rules.add_holidays([{"day": "2026-12-25", "name": "Natale", "yearly": True}], "admin")
    tok = (await plant.rules.create_schedule("Uffici", "", [{"days": ["MO"], "start": "08:00", "end": "18:00"}], True, "admin"))["token"]
    print("managed before:", list(db.schedule_rules()))
    backup = await plant.backup()
    ctrl.factory_reset()
    if do_get:
        await plant.rules.list_groups()   # GET /api/groups (pagina Persone)
    print("managed after reset (+GET?):", list(db.schedule_rules()))
    items, result = await tfr.full_restore(plant, backup["id"], password="segreta")
    print("restored schedule on controller:", tok in ctrl.schedules)
    print("managed after full restore:", list(db.schedule_rules()))
    ctrl.calls.clear()
    await plant.rules.add_holidays([{"day": "2027-01-06", "name": "Epifania", "yearly": True}], "admin")
    print("set_schedule calls after new holiday:", len([c for c in ctrl.calls if c[0] == "set_schedule"]))
    print("0106 in exceptions:", "0106" in (ctrl.schedules[tok].get("ExceptionScheduleDefinition") or "") or "BYMONTH=1;" in (ctrl.schedules[tok].get("ExceptionScheduleDefinition") or ""))
    print(ctrl.schedules[tok].get("ExceptionScheduleDefinition"))

for g in (True, False):
    print("=== do_get", g)
    asyncio.run(main(g))

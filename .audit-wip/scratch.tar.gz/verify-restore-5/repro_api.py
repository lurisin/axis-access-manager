"""Verifica indipendente: due persone con slug uguale ricreate dal ripristino Persone via API."""
import os, sys, tempfile, time
from pathlib import Path
from unittest import mock

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app

names = sys.argv[1:3] if len(sys.argv) > 2 else ["Senza Nome", "Senza Nome"]
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app, raise_server_exceptions=False) as client:
    client.get("/api/me", headers=admin)
    a = client.post("/api/persons", json={"name": names[0], "card": "04aa"}, headers=admin).json()
    time.sleep(1.1)
    b = client.post("/api/persons", json={"name": names[1], "card": "04bb"}, headers=admin).json()
    print("token A", a["axis_user_token"], "token B", b["axis_user_token"])
    created = client.post("/api/backups", json={}, headers=admin).json()
    print("backup", created.get("id"))
    client.delete(f"/api/persons/{a['id']}", headers=admin)
    client.delete(f"/api/persons/{b['id']}", headers=admin)
    print("utenti sul controller dopo delete:", list(controller.users))
    preview = client.post(f"/api/backups/{created['id']}/preview", json={"sections": ["persone"]}, headers=admin).json()
    print("righe:", [(i["key"], i["action"], i["default"], i["blocked"]) for i in preview["items"]])
    keys = [i["key"] for i in preview["items"] if i["default"]]
    t=time.time(); time.sleep(1 - (t - int(t)) + 0.01)  # inizio di un secondo, senza patch
    r = client.post(f"/api/backups/{created['id']}/restore", json={"sections": ["persone"], "keys": keys}, headers=admin)
    print("HTTP", r.status_code, r.text[:200])
    print("persone:", [(p["name"], p["axis_user_token"], [c["number"] for c in p["cards"]]) for p in client.get("/api/persons", headers=admin).json()])
    print("tessere controller:", [(c["IdData"][0]["Value"], c["UserToken"]) for c in controller.credentials.values()])
    print("utenti controller:", list(controller.users))
    audit = client.get("/api/audit", headers=admin).json()
    rows = audit if isinstance(audit, list) else audit.get("items", audit)
    print("audit:", [x.get("action") for x in rows[:6]])
    s = client.post("/api/sync", headers=admin)
    print("sync", s.status_code, s.text[:200])
    print("persone dopo sync:", [(p["name"], [c["number"] for c in p["cards"]]) for p in client.get("/api/persons", headers=admin).json()])

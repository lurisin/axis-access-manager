"""restore_missing con due persone '(Senza nome)' importate da tessere senza utente."""
import asyncio, tempfile, time
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = FakeController()
    for card in ("04a1", "04a2"):
        tok = c.add_existing("x", "x", card)
        c.credentials[tok]["UserToken"] = ""
        c.credentials[tok]["Description"] = ""
    c.users.clear()
    svc = AccessService(db, c, settings)
    print(await svc.sync_from_controller())
    print("persone:", [(p["name"], p["axis_user_token"]) for p in db.all_persons()])
    c.credentials.clear()  # controller resettato
    print(await svc.sync_from_controller())
    t = time.time(); await asyncio.sleep(1 - (t - int(t)) + 0.01)
    try:
        print(await svc.restore_missing("admin"))
    except Exception as e:
        print("ECCEZIONE", type(e).__name__, e)
    print("persone:", [(p["name"], p["axis_user_token"], [(x["number"], x["missing_since"] is not None and x["missing_since"] != "") for x in db.cards_of(p["id"])]) for p in db.all_persons()])
    print("controller:", [(v["IdData"][0]["Value"], v["UserToken"]) for v in c.credentials.values()])
    print(await svc.sync_from_controller())
    print("persone dopo sync:", [(p["name"], [x["number"] for x in db.cards_of(p["id"])]) for p in db.all_persons()])

asyncio.run(main())

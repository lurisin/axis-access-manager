"""Sequenza di intercomEditor/cameraEditor quando si cambia porta: PUT porta vecchia (svuota) poi PUT porta nuova."""
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

tmp = Path(tempfile.mkdtemp())
app = create_app(parse_options({}), allow_any_client=True, controller=FakeController(), db_path=tmp / "i.db")
FIELDS = ["name", "door_token", "ha_buttons", "snapshot_camera", "snapshot_on_granted", "intercom_name", "intercom_relay", "intercom_open_door", "intercom_mqtt_prefix", "area_id"]


def body(door, **changes):
    return {**{k: door[k] for k in FIELDS if k in door}, **changes}


with TestClient(app) as client:
    data = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
    cid = client.post("/api/controllers", json=data).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso", "intercom_name": "Citofono", "intercom_open_door": True, "snapshot_camera": "camera.ingresso"})
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina"})
    doors = client.get("/api/installation").json()["controllers"][0]["doors"]
    old, new = doors[0], doors[1]
    print("prima: ", [(d["name"], d["intercom_name"], d["snapshot_camera"]) for d in doors])
    # intercomEditor: sposta su Cantina con prefisso non valido
    r1 = client.put(f"/api/doors/{old['id']}", json=body(old, intercom_name="", intercom_open_door=False))
    r2 = client.put(f"/api/doors/{new['id']}", json=body(new, intercom_name="Citofono", intercom_open_door=True, intercom_relay=1, intercom_mqtt_prefix="hmd 2"))
    print("PUT vecchia:", r1.status_code, "PUT nuova:", r2.status_code, r2.json())
    # cameraEditor: entità scritta a mano non valida
    r3 = client.put(f"/api/doors/{old['id']}", json=body(old, intercom_name="", intercom_open_door=False, snapshot_camera="", snapshot_on_granted=False))
    r4 = client.put(f"/api/doors/{new['id']}", json=body(new, snapshot_camera="ingresso", snapshot_on_granted=False))
    print("PUT vecchia:", r3.status_code, "PUT nuova:", r4.status_code, r4.json())
    doors = client.get("/api/installation").json()["controllers"][0]["doors"]
    print("dopo:  ", [(d["name"], d["intercom_name"], d["snapshot_camera"]) for d in doors])
    print("citofoni attivi:", client.get("/api/status").json()["intercoms"])

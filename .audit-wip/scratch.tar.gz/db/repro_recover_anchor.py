"""Recovery after an MQTT outage starts from MAX(ts): a live event arrived before the health tick hides the gap.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

from conftest import FakeController

from app import main
from app.config import parse_options
from app.db import Database
from app.events import Event, EventMonitor
from app.service import AccessService


def log_entry(rowid: int, ts: datetime, cred: str) -> dict:
    return {
        "rowid": rowid,
        "UtcTime": ts.strftime("%Y-%m-%dT%H:%M:%S.000000Z"),
        "KeyValues": [
            {"Key": "topic0", "Value": "AccessControl"},
            {"Key": "topic1", "Value": "AccessGranted"},
            {"Key": "topic2", "Value": "Card"},
            {"Key": "AccessPointToken", "Value": "ap-in"},
            {"Key": "CredentialToken", "Value": cred},
        ],
    }


def granted(ts: datetime, cred: str) -> Event:
    return Event("AccessControl", "AccessControl/AccessGranted/Card/", ts, {"AccessPointToken": "ap-in",
                                                                            "CredentialToken": cred})


async def run() -> None:
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    controller = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta",
                              "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
    monitor = EventMonitor(prefix="accessi/x", door_token="porta")
    service = AccessService(db, controller, settings, monitor)
    mario = await service.create_person("Mario", "04aa", "admin")
    anna = await service.create_person("Anna", "04bb", "admin")
    cred_m, cred_a = mario["cards"][0]["axis_credential_token"], anna["cards"][0]["axis_credential_token"]

    now = datetime.now(tz=UTC).replace(microsecond=0)
    t_before, t_lost, t_live = now - timedelta(minutes=40), now - timedelta(minutes=20), now - timedelta(seconds=15)
    service.record_event(granted(t_before, cred_m))  # live, before the broker went down
    # The controller's internal log has everything; MQTT lost the 20-minutes-ago passage of Anna
    controller.log_events = [log_entry(1, t_before, cred_m), log_entry(2, t_lost, cred_a), log_entry(3, t_live, cred_m)]

    # Broker back: outage counted, connected again. Mario badges in before the next 30 s health tick
    monitor.outages, monitor.connected, monitor.controller_online = 1, True, True
    service.record_event(granted(t_live, cred_m))

    state = SimpleNamespace(
        monitor=monitor, recover_pending=False, recover_outages=0,
        installation=SimpleNamespace(primary={"id": 1}),
        health=SimpleNamespace(states={1: SimpleNamespace(online=True)}),
        controller=SimpleNamespace(paused=""), mqtt=object(), db=db, service=service, last_recovery=None,
    )
    await main._recover_if_needed(state)
    print("last_recovery:", state.last_recovery)
    print("events:", [(e["ts"], e["person_name"], bool(e["recovered"])) for e in db.list_events()])
    print("pending afterwards:", state.recover_pending, "outages acknowledged:", state.recover_outages)


asyncio.run(run())

"""Controller removed from the app: category_rules keep pointing at door ids that get reused by new doors.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
controller.access_points.append(
    {"token": "ap-cantina", "Entity": "porta2", "Name": "Cantina", "Attribute": [{"Name": "Direction", "Value": "in"}]}
)
work = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=work / "api.db")

CTRL = {"name": "A1210", "host": "a1210.local", "username": "root", "password": "x", "mqtt_topic_prefix": "accessi/x"}


def door(token, name):
    return {"door_token": token, "name": name}


with TestClient(app) as client:
    doors = client.get("/api/installation").json()["controllers"][0]["doors"]
    print("doors at start:", [(d["id"], d["door_token"], d["name"]) for d in doors])
    cid = client.get("/api/installation").json()["controllers"][0]["id"]
    r = client.post(f"/api/controllers/{cid}/doors", json=door("porta2", "Cantina"))
    print("add Cantina:", r.status_code, r.json())
    doors = {d["name"]: d["id"] for d in client.get("/api/installation").json()["controllers"][0]["doors"]}
    print("doors:", doors)

    # Category "Pulizie": only the cellar (Cantina)
    r = client.post("/api/categories", json={"name": "Pulizie", "color": "green",
                                             "rules": [{"target": "door", "target_id": doors["Cantina"],
                                                        "schedule": "standard_always"}]})
    cat = r.json()
    token = cat["token"]
    print("Pulizie profile access points:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])

    # Remove the controller from the app (UI: "Rimuovi Controller"), then add it again and its doors
    print("delete controller:", client.delete(f"/api/controllers/{cid}").status_code)
    print("rules left in DB:", app.state.db.all_category_rules())
    r = client.post("/api/controllers", json=CTRL)
    cid2 = r.json()["id"]
    print("new controller id:", cid2)
    # Doors added in a different order: Cantina first, then the main entrance
    print(client.post(f"/api/controllers/{cid2}/doors", json=door("porta2", "Cantina")).json())
    print(client.post(f"/api/controllers/{cid2}/doors", json=door("porta", "Ingresso")).json())
    doors = {d["name"]: d["id"] for d in client.get("/api/installation").json()["controllers"][0]["doors"]}
    print("doors now:", doors)
    print("Pulizie rules:", app.state.db.category_rules(cat["id"]))
    print("Pulizie profile access points:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    print("categories page:", [(c["name"], c["rules"]) for c in client.get("/api/categories").json()])


def buttons(app):
    return [(c["unique_id"], c["name"], c["payload_press"]) for comp, _, c in app.state.bridge._entities()
            if comp == "button"]


print("--- Home Assistant buttons are keyed by door id (first door keeps the legacy id) ---")
settings2 = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                           "mqtt_topic_prefix": "accessi/x", "ha_integration": True})
controller2 = FakeController()
app2 = create_app(settings2, allow_any_client=True, controller=controller2, db_path=Path(tempfile.mkdtemp()) / "b.db")
with TestClient(app2) as client:
    cid = client.get("/api/installation").json()["controllers"][0]["id"]
    client.put(f"/api/doors/1", json=door("porta", "Ingresso"))
    client.post(f"/api/controllers/{cid}/doors", json=door("porta2", "Cantina"))
    print("before:", buttons(app2))
    client.delete(f"/api/controllers/{cid}")
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json=door("porta2", "Cantina"))
    client.post(f"/api/controllers/{cid}/doors", json=door("porta", "Ingresso"))
    print("after: ", buttons(app2))

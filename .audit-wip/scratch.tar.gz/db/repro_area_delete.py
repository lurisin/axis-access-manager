"""Deleting an area inside a site used by a category: the doors leave the site and lose the category's access.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
controller.access_points.append(
    {"token": "ap-cantina", "Entity": "porta2", "Name": "Cantina", "Attribute": [{"Name": "Direction", "Value": "in"}]}
)
app = create_app(settings, allow_any_client=True, controller=controller, db_path=Path(tempfile.mkdtemp()) / "a.db")

with TestClient(app) as client:
    site = client.get("/api/locations").json()[0]
    print("site:", site["name"], [(a["id"], a["name"]) for a in site["areas"]])
    general = site["areas"][0]["id"]
    tech = client.post(f"/api/sites/{site['id']}/areas", json={"name": "Locali Tecnici"}).json()["id"]
    cid = client.get("/api/installation").json()["controllers"][0]["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina", "area_id": tech})
    cat = client.post("/api/categories", json={"name": "Dipendenti", "color": "blue", "rules": [
        {"target": "site", "target_id": site["id"], "schedule": "standard_always"}]}).json()
    print("Dipendenti opens:", sorted(p["AccessPoint"] for p in controller.profiles[cat["token"]]["AccessPolicy"]))
    r = client.delete(f"/api/areas/{general}")
    print("delete area Generale:", r.status_code, r.json())
    print("Dipendenti opens:", sorted(p["AccessPoint"] for p in controller.profiles[cat["token"]]["AccessPolicy"]))

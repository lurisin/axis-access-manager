"""A card number moved from one credential to another on the controller: sync crashes with IntegrityError.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import asyncio
import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app import main as main_module  # noqa: E402
from app.main import create_app  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
t_anna = controller.add_existing("utente_anna", "Anna", "04aaaa")
t_bruno = controller.add_existing("utente_bruno", "Bruno", "04bbbb")

# The maintenance loop runs a sync every SYNC_INTERVAL: make it fast for the experiment
main_module.SYNC_INTERVAL = 0.2
main_module.SYNC_RETRY = 0.2
work = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=work / "api.db")

with TestClient(app, raise_server_exceptions=False) as client:
    time.sleep(1)
    first = app.state.last_sync["at"]
    time.sleep(2.1)
    print("loop alive before the swap?", app.state.last_sync["at"] != first)
    print("persons:", [(p["name"], [c["number"] for c in p["cards"]]) for p in client.get("/api/persons").json()])
    # On the controller (Axis web page) the card 04bbbb is moved from Bruno to Anna: Bruno's credential is
    # deleted and Anna's credential now carries 04bbbb
    controller.credentials.pop(t_bruno)
    controller.credentials[t_anna]["IdData"] = [{"Name": "Card", "Value": "04bbbb"}]
    before = dict(app.state.last_sync)
    time.sleep(1.5)
    print("last_sync before the swap:", before["at"], "after 1.5 s of 0.2 s sync loop:", app.state.last_sync)
    r = client.post("/api/sync")
    print("manual sync:", r.status_code, r.text[:200])
    at = app.state.last_sync["at"]
    time.sleep(2)
    print("background loop still syncing?", app.state.last_sync["at"] != at, app.state.last_sync)

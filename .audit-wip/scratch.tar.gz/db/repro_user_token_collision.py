"""Two persons whose names give the same 30-char slug, created in the same second: same Axis user token.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402
from app.service import user_token_for  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
work = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=work / "api.db")

a, b = "Cooperativa Sociale Pulizie Splendor - Mario Bianchi", "Cooperativa Sociale Pulizie Splendor - Luca Verdi"
print(user_token_for(a), user_token_for(b))
csv = f"nome;tessera\n{a};04a1\n{b};04b2\n"
with TestClient(app, raise_server_exceptions=False) as client:
    r = client.post("/api/import/persons", json={"csv": csv, "apply": True})
    print("import:", r.status_code, r.text[:300])
    print("app persons:", [(p["name"], p["axis_user_token"], [c["number"] for c in p["cards"]])
                           for p in client.get("/api/persons").json()])
    print("controller users:", {t: u["Name"] for t, u in controller.users.items()})
    print("controller credentials:", [(c["UserToken"], c["IdData"][0]["Value"]) for c in controller.credentials.values()])
    client.post("/api/sync")
    print("after sync:", [(p["name"], [c["number"] for c in p["cards"]]) for p in client.get("/api/persons").json()])

"""Category ids are reused after a deletion: the restore preview matches the new category by id.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import json
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
controller.access_points.append(
    {"token": "ap-cantina", "Entity": "porta2", "Name": "Cantina", "Attribute": [{"Name": "Direction", "Value": "in"}]}
)
work = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=work / "api.db")

with TestClient(app) as client:
    cid = client.get("/api/installation").json()["controllers"][0]["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina"})
    doors = {d["name"]: d["id"] for d in client.get("/api/installation").json()["controllers"][0]["doors"]}
    rule = lambda d: [{"target": "door", "target_id": doors[d], "schedule": "standard_always"}]  # noqa: E731
    ospiti = client.post("/api/categories", json={"name": "Ospiti", "color": "green", "rules": rule("Porta")}).json()
    print("Ospiti:", ospiti)
    backup = client.post("/api/backups", json={"name": "con Ospiti"}).json()
    print("backup:", backup.get("id"))
    print("delete Ospiti:", client.delete(f"/api/categories/{ospiti['id']}").status_code)
    manut = client.post("/api/categories", json={"name": "Manutentori", "color": "red", "rules": rule("Cantina")}).json()
    print("Manutentori:", manut)
    preview = client.post(f"/api/backups/{backup['id']}/preview", json={"sections": ["tipologie"]}).json()
    for item in preview["items"]:
        print(json.dumps({k: item[k] for k in ("key", "action", "label", "text", "changes", "default")},
                         ensure_ascii=False))

"""While backup_copy.py (backup_pre of Home Assistant) copies the database, the app cannot commit.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import json
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from app.db import Database

work = Path(tempfile.mkdtemp())
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")

# ~ one year of a small office: 150k events with the raw MQTT payload (~400 bytes)
raw = {"AccessPointToken": "accesso_via_consulta_ingresso_scala", "CredentialToken": "Axis-b8a44f3f2c0e:1729875283.1",
       "CredentialHolderName": "utente_mario_rossi_261025174243", "Card": "04A11A34B2C580", "IdData": "04A11A34B2C580",
       "DoorToken": "porta_via_consulta_ingresso_scala", "Reason": "", "topic": "AccessControl/AccessGranted/Card"}
with db._lock:
    db._conn.executemany(
        "INSERT INTO events (ts, kind, card, person_name, source, raw, door, ref) VALUES (?,?,?,?,?,?,?,?)",
        [(f"2026-{1 + i % 12:02d}-{1 + i % 28:02d}T{i % 24:02d}:{i % 60:02d}:{i % 60:02d}+00:00", "concesso",
          "04A11A34B2C580", "Mario Rossi", "controller", json.dumps(raw), "porta_via_consulta_ingresso_scala",
          "concesso|porta") for i in range(150_000)],
    )
    db._conn.commit()
print("database size: %.1f MB" % (path.stat().st_size / 1e6))

# Time of the real hook on this (fast) machine
t = time.monotonic()
subprocess.run([sys.executable, "axis_access_manager/app/backup_copy.py"], env={"AAM_DB_PATH": str(path)},
               check=True, capture_output=True)
print("backup_copy.py took %.2f s here" % (time.monotonic() - t))

# The hook keeps a read transaction open for the whole copy; on a Raspberry Pi SD card this lasts seconds.
# Simulate an 8 s copy with a reader in another process holding the same SHARED lock.
reader = subprocess.Popen([sys.executable, "-c", (
    "import sqlite3, time, sys\n"
    "c = sqlite3.connect(f'file:{sys.argv[1]}?mode=ro', uri=True, isolation_level=None)\n"
    "c.execute('BEGIN'); c.execute('SELECT COUNT(*) FROM events').fetchone()\n"
    "print('reader holds the lock', flush=True); time.sleep(8); c.execute('COMMIT')\n"
), str(path)], stdout=subprocess.PIPE, text=True)
print(reader.stdout.readline().strip())
t = time.monotonic()
try:
    db.add_event(ts="2026-10-28T08:00:00+00:00", kind="concesso", person_name="Anna", door="porta")
    print("add_event ok after %.1f s" % (time.monotonic() - t))
except sqlite3.OperationalError as err:
    print("add_event failed after %.1f s (event loop blocked meanwhile): %s" % (time.monotonic() - t, err))
print("transaction left open:", db._conn.in_transaction)
reader.wait()

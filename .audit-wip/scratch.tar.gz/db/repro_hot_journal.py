"""Hot journal after a crash mid-commit: recover() treats the DB as damaged and replaces it with the old HA copy.

Run from the repo root:
  PYTHONPATH=axis_access_manager:tests python3 <this file>
"""

import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

from app.backup_copy import consistent_copy, ha_copy_path, is_healthy, recover
from app.db import Database

work = Path(tempfile.mkdtemp())
path = work / "axis_access_manager.db"

# 1. Database with one person, then the pre-backup copy of Home Assistant (backup_pre)
db = Database(path, "0.21.7")
db.add_person("Prima del backup", "utente_a")
db.close()
consistent_copy(path, ha_copy_path(path))

# 2. After the HA backup: more work is done (new persons, events)
db = Database(path, "0.21.7")
for i in range(50):
    db.add_person(f"Dopo il backup {i}", f"utente_b{i}")
db.close()

# 3. A process crashes (power loss / SIGKILL) while a write transaction is spilling to the database file:
#    the rollback journal is synced (hot) and some pages of the main file are already overwritten.
child = r"""
import os, sqlite3, sys
conn = sqlite3.connect(sys.argv[1], isolation_level=None)
conn.execute("PRAGMA cache_size = 5")
conn.execute("BEGIN")
for i in range(3000):
    conn.execute("INSERT INTO events (ts, kind, raw) VALUES ('2026-10-28T08:00:00+00:00', 'concesso', ?)", ("x" * 200,))
os._exit(1)  # crash before COMMIT
"""
subprocess.run([sys.executable, "-c", child, str(path)], check=False)
journal = Path(str(path) + "-journal")
print("hot journal present:", journal.exists(), journal.stat().st_size if journal.exists() else 0)

# What a normal read-write open would do: roll back the journal, data intact
probe = work / "probe.db"
probe.write_bytes(path.read_bytes())
Path(str(probe) + "-journal").write_bytes(journal.read_bytes())
conn = sqlite3.connect(probe)
print("read-write open, quick_check:", conn.execute("PRAGMA quick_check").fetchone()[0],
      "persons:", conn.execute("SELECT COUNT(*) FROM persons").fetchone()[0])
conn.close()

# 4. Add-on restart: Database() calls recover() first
print("is_healthy (mode=ro):", is_healthy(path))
db = Database(path, "0.21.7")
print("recovered message:", repr(db.recovered))
print("persons after restart:", [p["name"] for p in db.all_persons()][:3], "... total", len(db.all_persons()))
db.close()
broken = [p for p in work.iterdir() if "danneggiato" in p.name]
for p in broken:
    c = sqlite3.connect(p)
    try:
        print("set-aside file", p.name, "quick_check:", c.execute("PRAGMA quick_check").fetchone()[0],
              "persons:", c.execute("SELECT COUNT(*) FROM persons").fetchone()[0])
    except sqlite3.DatabaseError as err:
        print("set-aside file", p.name, "error:", err)
    c.close()

"""Repro: persona senza tipologia (letta dal controller). Il modulo "Modifica" Accesso non ha l'opzione "Nessuna"
e preseleziona la tipologia predefinita: salvando solo una nuova scadenza, la UI manda category_id = predefinita
e il server cambia il profilo di accesso delle tessere."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "x.db", scheduled_backups=False)
with TestClient(app) as client:
    # Tipologia "Ospite" predefinita
    r = client.post("/api/categories", json={"name": "Ospite", "color": "blue", "rules": [{"target": "door", "target_id": client.get("/api/summary").json()["doors"][0]["id"], "schedule": "standard_office_hours"}]})
    print("categoria:", r.status_code, r.json())
    cat = r.json()
    client.put("/api/default-category", json={"category_id": cat["id"]})
    # Persona creata fuori dall'app (altro strumento) con un suo profilo, letta dalla sincronizzazione
    controller.users["u-mario"] = {"token": "u-mario", "Name": "Mario Tecnico", "Attribute": []}
    controller.credentials["cr-mario"] = {
        "token": "cr-mario", "UserToken": "u-mario", "Description": "Mario", "Enabled": True,
        "IdData": [{"Name": "Card", "Value": "04DD"}], "ValidFrom": "", "ValidTo": "",
        "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre", "ValidFrom": "", "ValidTo": ""}],
    }
    client.post("/api/sync")
    mario = next(p for p in client.get("/api/persons").json() if p["name"] == "Mario Tecnico")
    print("prima: category_id =", mario["category_id"], "profilo =", mario["cards"][0]["access_profile"])
    # La UI: categorySelect(0) preseleziona la predefinita (nessuna opzione "Nessuna"); l'utente cambia solo la scadenza
    body = {"category_id": cat["id"], "valid_from": "", "valid_to": "2026-12-31T17:00:00.000Z"}
    r = client.put(f"/api/persons/{mario['id']}/access", json=body).json()
    print("dopo:  category_id =", r["category_id"], "profilo =", r["cards"][0]["access_profile"])

    # Variante: tipologie non caricate (api/groups fallita con il controller irraggiungibile all'apertura della pagina):
    # categorySelect(2) produce solo <option value="0" selected>Nessuna</option>; la UI manda category_id 0.
    anna = client.post("/api/persons", json={"name": "Anna", "card": "04ee", "category_id": cat["id"]}).json()
    print("Anna prima: category_id =", anna["category_id"], "profilo =", anna["cards"][0]["access_profile"])
    controller.fail_set_credential = True  # il controller non risponde ancora alla scrittura
    r = client.put(f"/api/persons/{anna['id']}/access", json={"category_id": 0, "valid_from": "", "valid_to": ""})
    print("PUT con controller in errore:", r.status_code, r.json())
    anna = client.get(f"/api/persons/{anna['id']}").json()
    print("Anna dopo l'errore: category_id =", anna["category_id"], "profilo =", anna["cards"][0]["access_profile"])

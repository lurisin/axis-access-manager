"""Repro: il banner "Togli dall'App" manda ids=null; il server toglie TUTTE le tessere mancanti al momento
della richiesta, non quelle che l'utente ha visto e confermato."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "x.db", scheduled_backups=False)
with TestClient(app) as client:
    for name, card in (("Anna", "04aa"), ("Bruno", "04bb"), ("Carla", "04cc")):
        r = client.post("/api/persons", json={"name": name, "card": card, "group": "profilo_sempre", "company": "ACME", "notes": "nota"})
        assert r.status_code == 200, r.text
    # 1) Solo la tessera di Anna sparisce: la pagina Persone mostra il banner "1 tessera non presente"
    anna = next(t for t, c in controller.credentials.items() if c["IdData"][0]["Value"].lower() == "04aa")
    del controller.credentials[anna]
    client.post("/api/sync")
    page = client.get("/api/persons").json()  # quello che ha la pagina (store.persons)
    shown = sum(1 for p in page for c in p["cards"] if c["missing_since"])
    print("tessere non presenti mostrate nel banner:", shown)
    # 2) Più tardi il controller viene resettato: la sincronizzazione periodica segna tutte le altre
    controller.credentials.clear()
    client.post("/api/sync")
    # 3) L'utente (pagina non ricaricata) conferma "Togliere dall'app la tessera non presente?" -> body {ids: null}
    r = client.post("/api/missing-cards/forget", json={"ids": None}).json()
    print("risposta forget:", r)
    print("persone rimaste nell'app:", [p["name"] for p in client.get("/api/persons").json()])

"""Repro: "Tutto il Registro" / "Tutti i Suoi Eventi" filtrano il registro per nome (q=), non per persona:
dopo una rinomina spariscono i passaggi vecchi e compaiono quelli di chi ha un nome che contiene il suo."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "x.db", scheduled_backups=False)
with TestClient(app) as client:
    anna = client.post("/api/persons", json={"name": "Anna Rosi", "card": "04aa", "group": "profilo_sempre"}).json()
    mari = client.post("/api/persons", json={"name": "Marianna Rosi", "card": "04bb", "group": "profilo_sempre"}).json()
    db = app.state.db
    db.add_event(ts="2026-10-27T08:00:00+00:00", kind="concesso", card="04AA", person_id=anna["id"], person_name="Anna Rosi")
    db.add_event(ts="2026-10-27T09:00:00+00:00", kind="concesso", card="04BB", person_id=mari["id"], person_name="Marianna Rosi")
    # Correzione del cognome (refuso): gli eventi vecchi restano con il nome di allora
    client.patch(f"/api/persons/{anna['id']}", json={"name": "Anna Rossi"})
    db.add_event(ts="2026-10-28T08:00:00+00:00", kind="concesso", card="04AA", person_id=anna["id"], person_name="Anna Rossi")
    # Prima della rinomina: q=Anna Rosi
    print("q='Anna Rosi' (prima della rinomina):", [e["person_name"] for e in client.get("/api/events", params={"q": "Anna Rosi", "limit": 100}).json()])
    # Dopo: la scheda manda q=p.name
    print("q='Anna Rossi' (scheda dopo rinomina):", [e["person_name"] for e in client.get("/api/events", params={"q": "Anna Rossi", "limit": 100}).json()])
    print("person_id (Ultimi Passaggi della scheda):", [e["person_name"] for e in client.get(f"/api/persons/{anna['id']}").json()["events"]])

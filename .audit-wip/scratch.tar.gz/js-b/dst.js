// Stessa formula di logParams (index.html:1933-1934)
const to = "2026-10-25"; // giorno del cambio d'ora (25 ore)
const until = new Date(new Date(to + "T00:00:00").getTime() + 86400000);
console.log("until fall-back:", until.toString(), until.toISOString());
const to2 = "2026-03-29"; // 23 ore
const until2 = new Date(new Date(to2 + "T00:00:00").getTime() + 86400000);
console.log("until spring:", until2.toString(), until2.toISOString());
// evento alle 23:30 del 25/10 locale
const ev = new Date("2026-10-25T23:30:00");
console.log("evento 25/10 23:30 incluso?", ev < until);

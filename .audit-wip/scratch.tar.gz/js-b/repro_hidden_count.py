"""Repro: il conteggio "accessi riusciti non mostrati" del Registro (updateHiddenCount, ACCESS_KINDS con "lettura" e
"citofono") conta due volte ogni passaggio con tessera, e conta anche letture di accessi negati e squilli del citofono."""

import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "x.db", scheduled_backups=False)
with TestClient(app) as client:
    p = client.post("/api/persons", json={"name": "Anna", "card": "04aa", "group": "profilo_sempre"}).json()
    db = app.state.db
    now = datetime.now(tz=UTC).replace(microsecond=0)
    ts = now.isoformat()
    # Un passaggio riuscito: il controller manda la lettura e poi il concesso
    db.add_event(ts=ts, kind="lettura", card="04AA", person_id=p["id"], person_name="Anna", source="lettore", door="porta")
    db.add_event(ts=ts, kind="concesso", card="04AA", person_id=p["id"], person_name="Anna", door="porta")
    # Un passaggio negato (fuori fascia): lettura + negato
    db.add_event(ts=ts, kind="lettura", card="04AA", person_id=p["id"], person_name="Anna", source="lettore", door="porta")
    db.add_event(ts=ts, kind="negato", card="04AA", person_id=p["id"], person_name="Anna", detail="fuori fascia", door="porta")
    # Una chiamata al citofono senza risposta
    db.add_event(ts=ts, kind="citofono", detail="nessuna risposta", source="Citofono")
    since = now.replace(hour=0, minute=0, second=0).isoformat()
    ui = client.get("/api/events/count", params={"kind": "concesso,apertura_remota,uscita,citofono,lettura", "since": since}).json()
    real = client.get("/api/events/count", params={"kind": "concesso,apertura_remota,uscita", "since": since}).json()
    print("UI: accessi riusciti non mostrati =", ui["count"], "| accessi riusciti veri =", real["count"])

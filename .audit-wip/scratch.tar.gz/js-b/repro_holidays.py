"""Repro: "Aggiungi le Festività Nazionali Italiane" premuto in due anni diversi duplica tutte le festività fisse."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "x.db", scheduled_backups=False)
with TestClient(app) as client:
    client.post("/api/holidays/italia", json={"year": 2026})
    client.post("/api/holidays/italia", json={"year": 2027})  # l'anno dopo, per avere la Pasquetta 2028
    rows = client.get("/api/holidays").json()
    yearly = [(h["day"], h["name"]) for h in rows if h["yearly"]]
    print(len(yearly), "festività 'ogni anno':")
    for d, n in yearly[:6]:
        print("  ", d, n)

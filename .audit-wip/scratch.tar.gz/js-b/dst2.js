const now = new Date("2026-03-30T00:30:00"); // locale, giorno dopo il passaggio all'ora legale
const yesterday = new Date(now.getTime() - 86400000);
console.log("now", now.toDateString(), "| 'ieri' calcolato:", yesterday.toDateString());

const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const fs = require("fs");
const HTML = fs.readFileSync("/home/user/axis-access-manager/axis_access_manager/app/static/index.html", "utf8");
const now = new Date().toISOString();
const doors = [{id: 1, name: "Ingresso", token: "D1", site_id: 0, area_id: 0, mode: "Locked", today: {granted: 1, denied: 0, alarms: 0}}];
const routes = {
  "api/me": {user: "Admin", username: "admin", admin: true, perms: [], version: "0.21.7", role: "Amministratore"},
  "api/summary": {version: "0.21.7", configured: true, doors, faults: [], alarms: []},
  "api/installation": {controllers: [{id: 1, name: "Controller A1210", host: "1.2.3.4", doors: [], place: {}, health: {online: true}}], max_controllers: 1},
  "api/status": {controller: {ok: true, model: "A1210", readers: 1, inputs: 0}, mqtt: {connected: false}, controllers: [{id: 1, online: true}]},
  "api/notifications": {items: [{id: "n1", type: "denied", severity: "low", title: "Accesso Negato", text: "x", ts: now, first_ts: now, count: 1, seen: false, events: []}], types: [], levels: {}},
  "api/events": [], "api/events/count": {count: 0},
  "api/groups": {groups: [], schedules: [], categories: [{id: 1, name: "Ospite", color: "orange"}]},
  "api/persons": [{id: 1, name: "Mario", company: "", category_id: 1, cards: [{number: "1", enabled: true, access_profile: "", valid_to: ""}]}],
};
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({viewport: {width: 390, height: 900}});
  const page = await ctx.newPage();
  await page.route("**/*", (route) => {
    const url = new URL(route.request().url());
    if (url.pathname === "/") return route.fulfill({contentType: "text/html", body: HTML});
    const key = url.pathname.replace(/^\//, "");
    return route.fulfill({contentType: "application/json", body: JSON.stringify(routes[key] ?? {})});
  });
  const cs = (sel, props) => page.$eval(sel, (el, props) => Object.fromEntries(props.map((p) => [p, getComputedStyle(el)[p]]).concat([["h", el.getBoundingClientRect().height], ["w", el.getBoundingClientRect().width]])), props).catch((e) => "missing " + sel);
  await page.goto("http://app.test/#impianti"); await page.waitForTimeout(700);
  console.log("ctl-gear", await cs(".ctl-gear", ["borderTopColor", "borderTopStyle", "backgroundColor", "padding"]));
  await page.goto("http://app.test/#notifiche"); await page.waitForTimeout(700);
  console.log("btn ghost notif", await cs('a.btn.ghost', ["borderTopColor", "backgroundColor"]));
  console.log("h2 da gestire", await cs(".n-sec-head h2", ["fontSize", "fontWeight"]));
  console.log("n-sev low", await cs(".n-sev", ["color", "backgroundColor"]));
  console.log("presa visione", await cs("[data-seen]", ["fontSize"]));
  await page.goto("http://app.test/#persone"); await page.waitForTimeout(700);
  console.log("chip-btn", await cs(".chip-btn", ["fontSize"]));
  console.log("button.small", await cs("#p-sync", ["fontSize"]));
  console.log("p-sync icon", await cs("#p-sync svg", ["width"]));
  await page.goto("http://app.test/#cruscotto"); await page.waitForTimeout(700);
  console.log("top-edit", await cs("#top-edit", ["height"]));
  await browser.close();
})();

// Renders index.html with mocked API and reports computed styles for the suspected cascade problems.
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const fs = require("fs");
const path = require("path");

const HTML = fs.readFileSync("/home/user/axis-access-manager/axis_access_manager/app/static/index.html", "utf8");
const OUT = path.dirname(__filename);
const now = new Date().toISOString();

const doors = [
  {id: 1, name: "Ingresso Principale", token: "Axis-door-1", site: "Hotel Giulia", area: "Piano Terra", site_id: 1, area_id: 1, mode: "Locked", today: {granted: 12, denied: 2, alarms: 1}, last: {person: "Mario Rossi", kind: "concesso", ts: now}, camera: "camera.ingresso", intercom: "Citofono"},
  {id: 2, name: "Porta Magazzino", token: "Axis-door-2", site: "Hotel Giulia", area: "Piano Terra", site_id: 1, area_id: 1, mode: "DoubleLocked", today: {granted: 3, denied: 0, alarms: 0}, last: null},
];
const summary = {
  version: "0.21.7", configured: true, unknown_cards: 3, notifications: 5, doors,
  faults: [{id: "mqtt", type: "mqtt", severity: "crit", title: "Collegamento MQTT Perso", text: "Gli eventi non arrivano", door: "", ts: now, count: 1, seen: false},
           {id: "clock:home_assistant", type: "clock", severity: "low", title: "Orologio di Home Assistant", text: "HA indietro", door: "", ts: now, count: 1, seen: false}],
  alarms: [{id: "a1", type: "door_alarm", severity: "crit", title: "Allarme Porta", text: "Porta forzata", door: "Ingresso", ts: now, count: 1, seen: false}],
  camera_names: {},
};
const routes = {
  "api/me": {user: "Admin", username: "admin", admin: true, perms: [], version: "0.21.7", role: "Amministratore", default_category: 1},
  "api/summary": summary,
  "api/dashboard": {today: {granted: 12, remote: 1, exits: 0, reads: 0, denied: 2, unknown: 1, alarms: 1}, persons: 40, cards: 44, cards_suspended: 1,
    week: Array.from({length: 7}, (_, i) => ({day: new Date(Date.now() - (6 - i) * 86400000).toISOString().slice(0, 10), granted: 5 + i, denied: i % 3, unknown: 0})),
    recent: [], expiring: [], system: {configured: true, controller_online: true, mqtt_connected: false, casing_open: false, last_event: now},
    backup: {last: {created_at: now, name: "", kind_label: "Automatico", errors: [], summary: "x"}, auto: true, next: {kind: "notturno", at: now}, frequency: "ora", verify: {ok: true, at: now}, error: null}},
  "api/door-overview": doors,
  "api/notifications": {items: [], types: [], levels: {}},
  "api/unknown-cards": [{number: "04A1B2C3", count: 2, last_seen: now, first_seen: now}],
  "api/dashboard/layout": {widgets: [{type: "accessi_oggi", size: 1, height: 1}, {type: "negati_oggi", size: 1, height: 1}, {type: "allarmi_oggi", size: 1, height: 1}, {type: "persone", size: 1, height: 1},
    {type: "impianto", size: 2, height: 3}, {type: "backup", size: 2, height: 3}, {type: "porte", size: 4, height: 4}, {type: "da_registrare", size: 2, height: 3}]},
  "api/groups": {groups: [], schedules: [], categories: [{id: 1, name: "Dipendenti", color: "orange", default: true}]},
  "api/status": {now, controller: {ok: true, model: "A1210"}, mqtt: {connected: false, configured: true, categories: {}}, home_assistant: {integration: true, entities: ["a"], topic_prefix: "x", api: true},
    options: {event_retention_days: 365, mqtt_override: false}, database: {schema: 12, ha_copy: now, copies: [{at: now, size: 40000}]}, controllers: [], doors: [], intercoms: [], sync: {}},
  "api/installation": {controllers: [{id: 1, name: "Controller A1210", host: "192.168.1.50", doors: [], place: {site: "Hotel Giulia", area: "Piano Terra"}, health: {online: true}}], max_controllers: 1},
  "api/locations": [{id: 1, name: "Hotel Giulia", description: "", areas: [{id: 1, name: "Piano Terra", controllers: [1], doors: [1, 2]}]}],
};

async function main() {
  const browser = await chromium.launch({executablePath: undefined});
  const results = {};
  for (const scheme of ["light", "dark"]) {
    for (const width of [1280, 390, 360]) {
      const ctx = await browser.newContext({viewport: {width, height: 900}, colorScheme: scheme});
      const page = await ctx.newPage();
      await page.route("**/*", async (route) => {
        const url = new URL(route.request().url());
        if (url.pathname === "/" || url.pathname.endsWith("index.html")) return route.fulfill({contentType: "text/html", body: HTML});
        const key = url.pathname.replace(/^\//, "");
        const data = routes[key] ?? routes[key.split("?")[0]];
        return route.fulfill({contentType: "application/json", body: JSON.stringify(data ?? {})});
      });
      await page.goto("http://app.test/#cruscotto");
      await page.waitForTimeout(800);
      const tag = `${scheme}-${width}`;
      await page.screenshot({path: `${OUT}/dash-${tag}.png`, fullPage: true});
      results[tag] = await page.evaluate(() => {
        const cs = (el, props) => el ? Object.fromEntries(props.map((p) => [p, getComputedStyle(el)[p]])) : null;
        const chip = document.querySelector("#top-status .chip");
        const kpiVal = document.querySelector(".dw.kpi .dw-kpi .value");
        const sys = document.querySelector(".dw-sys");
        const sysB = sys && sys.querySelector("b"), sysRect = sys && sys.getBoundingClientRect(), bRect = sysB && sysB.getBoundingClientRect();
        const tile = document.querySelector(".tile .row");
        const tilePill = tile && tile.querySelector(".pill"), tRect = tile && tile.getBoundingClientRect(), pRect = tilePill && tilePill.getBoundingClientRect();
        const pill = document.querySelector("#offline-pill");
        return {
          chip: cs(chip, ["borderRadius", "padding", "fontSize", "backgroundColor", "height", "gap"]),
          chipIcon: cs(chip && chip.querySelector("svg"), ["width"]),
          kpiValue: cs(kpiVal, ["fontSize", "lineHeight", "marginTop"]),
          dwSysValueGapToRight: sysRect && bRect ? Math.round(sysRect.right - bRect.right) : null,
          tilePillGapToRight: tRect && pRect ? Math.round(tRect.right - pRect.right) : null,
          docOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
        };
      });
      // top pop in dark: hover feedback
      if (width === 1280) {
        await page.click("#top-status [data-pop=faults]");
        await page.waitForTimeout(200);
        const row = page.locator(".top-pop .pop-row").first();
        const before = await row.evaluate((el) => getComputedStyle(el).backgroundColor);
        const popBg = await page.locator("#top-pop").evaluate((el) => getComputedStyle(el).backgroundColor);
        await row.hover();
        await page.waitForTimeout(100);
        const after = await row.evaluate((el) => getComputedStyle(el).backgroundColor);
        const dots = await page.$$eval(".top-pop .pop-row .dot", (ds) => ds.map((d) => d.className));
        results[tag].topPop = {popBg, rowBefore: before, rowHover: after, dots};
        await page.screenshot({path: `${OUT}/pop-${tag}.png`});
      }
      // settings page: dl.props overflow
      await page.goto("http://app.test/#impostazioni");
      await page.waitForTimeout(600);
      results[tag].settings = await page.evaluate(() => {
        const out = [];
        document.querySelectorAll("dl.props").forEach((dl) => {
          const card = dl.closest(".card");
          if (dl.scrollWidth > dl.clientWidth + 1 || (card && card.scrollWidth > card.clientWidth + 1)) out.push({dl: dl.scrollWidth - dl.clientWidth, card: card ? card.scrollWidth - card.clientWidth : null, first: dl.querySelector("dt")?.textContent});
          dl.querySelectorAll("dd").forEach((dd) => { const r = dd.getBoundingClientRect(); if (r.width < 60) out.push({narrowDd: Math.round(r.width), dt: dd.previousElementSibling.textContent}); });
        });
        return {overflow: out, doc: document.documentElement.scrollWidth - document.documentElement.clientWidth};
      });
      await page.screenshot({path: `${OUT}/settings-${tag}.png`, fullPage: true});
      // strutture: chips in areas
      await page.goto("http://app.test/#impianti/strutture");
      await page.waitForTimeout(600);
      results[tag].strutture = await page.evaluate(() => {
        const ch = document.querySelector(".item .meta .chip");
        const span = document.querySelectorAll(".item .meta .chip")[1];
        return ch ? {height: getComputedStyle(ch).height, radius: getComputedStyle(ch).borderRadius, cursorSpan: span && getComputedStyle(span).cursor, weight: getComputedStyle(ch).fontWeight} : null;
      });
      await page.screenshot({path: `${OUT}/strutture-${tag}.png`, fullPage: true});
      await ctx.close();
    }
  }
  console.log(JSON.stringify(results, null, 1));
  await browser.close();
}
main().catch((e) => { console.error(e); process.exit(1); });

"""WCAG 2.x contrast for the colour pairs actually used in index.html (light and dark themes)."""

LIGHT = {
    "bg": "#f3f5f8", "surface": "#ffffff", "surface-2": "#f7f8fa", "text": "#1b1f24", "muted": "#5f6b7a",
    "border": "#dde2e8", "border-strong": "#c5ccd5",
    "accent": "#0b6bcb", "accent-soft": "#e3effc", "accent-text": "#ffffff",
    "ok": "#1a7f37", "ok-soft": "#e4f4e8", "warn": "#9a6700", "warn-soft": "#fbf0d9", "err": "#c62828", "err-soft": "#fde7e7",
    "info": "#6639ba", "info-soft": "#efe9fb",
}
DARK = {
    "bg": "#0f1216", "surface": "#181c22", "surface-2": "#1f242b", "text": "#e7eaee", "muted": "#9aa5b1",
    "border": "#2b323b", "border-strong": "#3a434e",
    "accent": "#4c9cf0", "accent-soft": "#15283d", "accent-text": "#0b1118",
    "ok": "#4ac26b", "ok-soft": "#13291b", "warn": "#e3b341", "warn-soft": "#2e2511", "err": "#ff6b6b", "err-soft": "#331617",
    "info": "#b093f5", "info-soft": "#241c3a",
}
CATS = {"blue": "#2f7de1", "green": "#2ea44f", "orange": "#e8871e", "red": "#d93f3f", "purple": "#8a5cd6",
        "teal": "#1f9e9e", "pink": "#d6519b", "gray": "#7d8894"}


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def hexs(c):
    return "#%02x%02x%02x" % tuple(round(x) for x in c)


def lum(c):
    def ch(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def mix(fg, bg, alpha):
    """fg at `alpha` over bg (color-mix(fg alpha%, transparent) on bg, or opacity)."""
    return tuple(f * alpha + b * (1 - alpha) for f, b in zip(fg, bg))


def c(theme, name):
    if name.startswith("#"):
        return rgb(name)
    return rgb(theme[name])


# (label, fg, bg, kind, css line) ; kind: text (4.5), large (3), ui (3)
PAIRS = [
    ("text su bg", "text", "bg", "text", 31),
    ("text su surface", "text", "surface", "text", 135),
    ("text su surface-2", "text", "surface-2", "text", 49),
    ("muted su bg (.muted/.hint in pagina)", "muted", "bg", "text", 337),
    ("muted su surface (.muted, .meta, .hint)", "muted", "surface", "text", 337),
    ("muted su surface-2 (.pill neutro, .n-sev, .day, .hidden-count, hover)", "muted", "surface-2", "text", 346),
    ("muted su accent-soft (riga .ev.sel: ora e luogo)", "muted", "accent-soft", "text", 159),
    ("muted su warn-soft (.alert: .hint/.muted dentro)", "muted", "warn-soft", "text", 357),
    ("muted su err-soft (.alert.err: .hint/.muted dentro)", "muted", "err-soft", "text", 358),
    ("muted su ok-soft", "muted", "ok-soft", "text", 368),
    ("accent su surface (link)", "accent", "surface", "text", 33),
    ("accent su bg (link in pagina)", "accent", "bg", "text", 33),
    ("accent su accent-soft (.pill.accent, nav attivo, .n-tab sel, avatar)", "accent", "accent-soft", "text", 351),
    ("accent su warn-soft (link dentro .alert)", "accent", "warn-soft", "text", 357),
    ("accent su err-soft (link dentro .alert.err)", "accent", "err-soft", "text", 358),
    ("accent-text su accent (button.primary)", "accent-text", "accent", "text", 121),
    ("ok su ok-soft (.pill.ok, .chip.ok, .k-ok)", "ok", "ok-soft", "text", 347),
    ("warn su warn-soft (.pill.warn, .chip.warn, .k-warn, .n-sev)", "warn", "warn-soft", "text", 348),
    ("err su err-soft (.pill.err, .chip.err, .n-unk)", "err", "err-soft", "text", 349),
    ("info su info-soft (.pill.info, .k-info)", "info", "info-soft", "text", 350),
    ("ok su surface (testo verde)", "ok", "surface", "text", 516),
    ("warn su surface (.n-state, .rs-note, testo giallo)", "warn", "surface", "text", 318),
    ("warn su surface-2 (.n-state su riga in hover)", "warn", "surface-2", "text", 313),
    ("err su surface (button.danger, .rs-note.err)", "err", "surface", "text", 123),
    ("err su surface-2 (button.danger:hover)", "err", "surface-2", "text", 120),
    ("info su surface (ul.diff .chg)", "info", "surface", "text", 516),
    ("#fff su err (.nav .count, button.danger.primary, #toast.error)", "#ffffff", "err", "text", 59),
    ("#fff su ok", "#ffffff", "ok", "text", 0),
    ("#fff su accent", "#ffffff", "accent", "text", 0),
    ("bg su text (#toast, .chip-btn.on)", "bg", "text", "text", 474),
    ("#fff su #1b1f24 (.save-bar)", "#ffffff", "#1b1f24", "text", 208),
    ("bordo #5f6b7a su #1b1f24 (.save-bar button)", "#5f6b7a", "#1b1f24", "ui", 210),
    ("save-bar #1b1f24 su bg (stacco della barra)", "#1b1f24", "bg", "ui", 208),
    ("save-bar #1b1f24 su surface", "#1b1f24", "surface", "ui", 208),
    ("border-strong su surface (bordo input/button)", "border-strong", "surface", "ui", 130),
    ("border-strong su bg", "border-strong", "bg", "ui", 130),
    ("border su surface (card)", "border", "surface", "ui", 135),
    ("accent su surface (focus outline)", "accent", "surface", "ui", 132),
    ("warn su surface (.dot.warn, barra negati)", "warn", "surface", "ui", 355),
    ("ok su surface-2 (barra grafico)", "ok", "surface-2", "ui", 426),
    ("muted su surface (.dot neutro, .sch-line.off)", "muted", "surface", "ui", 354),
    ("info su surface (filo ingresso)", "info", "surface", "ui", 201),
    ("surface-2 su surface (stacco hover/righe)", "surface-2", "surface", "ui", 120),
]


def run(theme, tname):
    print(f"\n===== Tema {tname} =====")
    for label, fg, bg, kind, line in PAIRS:
        r = ratio(c(theme, fg), c(theme, bg))
        need = 4.5 if kind == "text" else 3.0
        flag = "FAIL" if r < need else ("bordo" if r < need + 0.3 else "")
        print(f"{r:5.2f}:1  need {need}  {flag:5}  L{line:<4} {label}")
    # alpha / opacity cases
    # .chip-btn.on .muted: opacity .7 of --bg over --text
    fg = mix(c(theme, "bg"), c(theme, "text"), 0.7)
    print(f"{ratio(fg, c(theme, 'text')):5.2f}:1  need 4.5        L392  .chip-btn.on .muted (bg al 70% su text)")
    # disabled buttons opacity .5
    for name, fgn, bgn, under in [("button disabilitato", "text", "surface", "surface"),
                                  ("button.primary disabilitato", "accent-text", "accent", "surface")]:
        b = mix(c(theme, bgn), c(theme, under), 0.5)
        f = mix(c(theme, fgn), c(theme, under), 0.5)
        print(f"{ratio(f, b):5.2f}:1  (esente)      L129  {name}")
    # dashboard editing body opacity .45
    f = mix(c(theme, "muted"), c(theme, "surface"), 0.45)
    print(f"{ratio(f, c(theme, 'surface')):5.2f}:1  (info)       L253  muted a opacity .45 in modifica cruscotto")
    # chip.warn border color-mix 40%
    for k in ("warn", "err"):
        bc = mix(c(theme, k), c(theme, f"{k}-soft"), 0.4)
        print(f"{ratio(bc, c(theme, 'bg')):5.2f}:1  need 3 (ui)  L91   bordo .chip.{k} (40%) su bg")
    # categories
    print("  -- categorie (.pill.cat: --c su color-mix(--c 14%) sopra surface) --")
    for k, v in CATS.items():
        base = c(theme, "surface")
        pbg = mix(rgb(v), base, 0.14)
        r = ratio(rgb(v), pbg)
        rs = ratio(rgb(v), base)
        print(f"{r:5.2f}:1  need 4.5  {'FAIL' if r < 4.5 else '':5} L488  .pill.cat c-{k} {v} (su surface puro {rs:.2f}; swatch ui {'FAIL' if rs < 3 else 'ok'})")


run(LIGHT, "chiaro")
run(DARK, "scuro")

# placeholder UA: Chrome light #757575 (o darkGray #a9a9a9 nelle versioni vecchie), dark #a9a9a9 circa
print("\nPlaceholder (UA, nessuna regola ::placeholder):")
for t, th, ph in (("chiaro", LIGHT, "#757575"), ("chiaro-old", LIGHT, "#a9a9a9"), ("scuro", DARK, "#8e8e8e")):
    print(f"  {t}: {ratio(rgb(ph), c(th, 'surface')):.2f}:1 ({ph} su surface)")

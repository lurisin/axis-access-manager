import importlib.util, sys
spec = importlib.util.spec_from_file_location("c", "contrast.py")
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
r, rgb, mix, L, D, CATS = m.ratio, m.rgb, m.mix, m.LIGHT, m.DARK, m.CATS
print("warn #875a00 su #fbf0d9", round(r(rgb("#875a00"), rgb("#fbf0d9")),2), "su #fff", round(r(rgb("#875a00"), rgb("#ffffff")),2))
print("warn #9a6700 su #fdf5e4", round(r(rgb("#9a6700"), rgb("#fdf5e4")),2))
print("ok #17702f su #e4f4e8", round(r(rgb("#17702f"), rgb("#e4f4e8")),2))
print("ok #1a7f37 su #eef8f0", round(r(rgb("#1a7f37"), rgb("#eef8f0")),2))
print("accent #0a5fb4 su err-soft", round(r(rgb("#0a5fb4"), rgb("#fde7e7")),2), "accent-soft", round(r(rgb("#0a5fb4"), rgb("#e3effc")),2))
for fg in ("#ffffff",):
    for bgc in ("#c62828", "#d93a3a", "#e04545"):
        print(f"{fg} su {bgc}", round(r(rgb(fg), rgb(bgc)),2))
print("#1b0a0a su #ff6b6b", round(r(rgb("#1b0a0a"), rgb("#ff6b6b")),2), "#0b1118 su #ff6b6b", round(r(rgb("#0b1118"), rgb("#ff6b6b")),2))
print("#c62828 fill vs dark bg #0f1216", round(r(rgb("#c62828"), rgb("#0f1216")),2))
for nm, th in (("chiaro", L), ("scuro", D)):
    for p in (60, 70):
        out=[]
        for k, v in CATS.items():
            fg = mix(rgb(v), rgb(th["text"]), p/100)
            bg = mix(rgb(v), rgb(th["surface"]), 0.14)
            out.append(f"{k}:{r(fg,bg):.2f}")
        print(nm, f"color-mix(--c {p}%, --text)", " ".join(out))
for b in ("#8c96a3", "#949eab", "#7d8794"):
    print("bordo", b, "su #fff", round(r(rgb(b), rgb("#ffffff")),2), "su bg", round(r(rgb(b), rgb(L["bg"])),2))
for b in ("#5c6773", "#66717e"):
    print("bordo scuro", b, "su surface", round(r(rgb(b), rgb(D["surface"])),2))
print("save-bar dark se var(--text)", round(r(rgb(D["text"]), rgb(D["bg"])),2), "testo var(--bg) su text", round(r(rgb(D["bg"]), rgb(D["text"])),2))
print("muted #5f6b7a sul text chiaro (save-bar su var(--text) dark?)")
print("pop dark hover: surface-2 vs border", round(r(rgb(D["border"]), rgb(D["surface-2"])),2))

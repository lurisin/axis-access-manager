"""Ingresso programmato dall'app i cui oggetti non sono più sul controller (reset + ripristino completo da un backup
di prima, oppure tolti dalla pagina web): l'app lo mostra programmato senza avvisi, risalvarlo non lo ricrea e
togliere il ruolo fallisce, perché RemoveAccessPoint di un token che non c'è risponde NotFound."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService
from app.service import ServiceError
from app.vapix import VapixError

NOT_FOUND = 'il controller ha risposto con errore 400: {"Fault": "env:Sender", "FaultCode": "ter:NotFound"}'


class BenchController(FakeController):
    """Come il controller vero: togliere un oggetto che non c'è risponde NotFound (vedi _remove_configuration)."""

    async def remove_access_point(self, token):
        if all(a["token"] != token for a in self.access_points):
            raise VapixError(NOT_FOUND)
        await super().remove_access_point(token)

    async def remove_idpoint(self, token):
        if token not in self.idpoints:
            raise VapixError(NOT_FOUND)
        await super().remove_idpoint(token)


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = BenchController()
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    service = ProgrammingService(db, controller, cid, asyncio.Lock())
    settings = {"name": "Pulsante Portineria", "role": "rex", "door": "porta", "contact": "no", "supervised": False}
    await service.update_input("IO1", settings, "admin")
    row = db.controller_inputs(cid)["IO1"]

    # Reset del controller e ripristino da un backup fatto prima del pulsante: i suoi oggetti non ci sono più
    controller.access_points = [a for a in controller.access_points if a["token"] != row["access_point_token"]]
    controller.idpoints.pop(row["idpoint_token"])
    controller.idpoint_configs.pop(row["idpoint_token"])
    controller.io_assignments.pop("IO1")
    controller.profiles = {k: p for k, p in controller.profiles.items() if "REXOnly" not in (p.get("AuthenticationProfile") or [])}

    page = await service.read()
    io1 = {i["io"]: i for i in page["inputs"]}["IO1"]
    print("pagina:", io1["role"], io1["door"], "| assegnato sul controller:", io1["assigned"], "| rex_missing:", page["rex_missing"])

    controller.calls.clear()
    await service.update_input("IO1", settings, "admin")
    print("risalvato uguale -> chiamate al controller:", controller.calls)

    try:
        await service.update_input("IO1", {**settings, "role": ""}, "admin")
    except ServiceError as err:
        print("togliere il ruolo:", err)
    print("riga dopo:", {k: db.controller_inputs(cid)["IO1"][k] for k in ("role", "idpoint_token", "access_point_token")})
    try:
        await service.update_input("IO1", {**settings, "role": ""}, "admin")
    except ServiceError as err:
        print("secondo tentativo:", err)


asyncio.run(main())

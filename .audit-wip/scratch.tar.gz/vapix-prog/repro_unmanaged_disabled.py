"""Punto di accesso disattivato e non gestito: la pagina del controller lo dà come "la porta non si apre",
il controllo di stato (notifiche, Impianti) no."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.health import ControllerHealth, HealthMonitor
from app.programming import ProgrammingService


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    controller.access_points[0]["Enabled"] = False
    controller.access_controllers["Axis-x AccessController"]["AccessPoint"] = []
    page = await ProgrammingService(db, controller, 1, asyncio.Lock()).read()
    print("pagina del controller, unmanaged:", page["unmanaged"])
    health = HealthMonitor(db, lambda row: controller)
    state = ControllerHealth(1, "A1210")
    await health._managed(controller, state)
    print("controllo di stato, unmanaged:", state.unmanaged)


asyncio.run(main())

"""Linea Supervisionata su un Ingresso di Allarme (o Non Usato): accettata e mostrata, ma non scritta."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    service = ProgrammingService(db, controller, cid, asyncio.Lock())

    controller.calls.clear()
    saved = await service.update_input("IO1", {"name": "Allarme Vetri", "role": "alarm", "supervised": True}, "admin")
    print("risposta:", saved)
    print("chiamate al controller:", controller.calls)
    io1 = {i["io"]: i for i in (await service.read())["inputs"]}["IO1"]
    print("pagina:", io1["role"], "supervised =", io1["supervised"], "can_supervise =", io1["can_supervise"])
    print("modo dell'ingresso sul controller:", controller.io_assignments.get("IO1"))


asyncio.run(main())

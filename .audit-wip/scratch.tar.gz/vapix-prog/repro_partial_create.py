"""Creazione di un pulsante che fallisce dopo l'assegnazione dell'I/O: il database resta "Non Usato" ma l'AUX
è assegnato come REX sul controller (stato in Home Assistant al contrario) e risalvare "Non Usato" non lo libera."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService
from app.service import ServiceError
from app.vapix import VapixError


class Failing(FakeController):
    fail_ap = False

    async def create_access_point(self, access_point):
        if self.fail_ap:
            raise VapixError("il controller non risponde (ReadTimeout)")
        return await super().create_access_point(access_point)


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = Failing()
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    service = ProgrammingService(db, controller, cid, asyncio.Lock())

    controller.fail_ap = True
    try:
        await service.update_input("IO1", {"name": "Pulsante", "role": "rex", "door": "porta"}, "admin")
    except ServiceError as err:
        print("errore:", err)
    controller.fail_ap = False
    row = db.controller_inputs(cid)["IO1"]
    print("database:", row["role"], repr(row["name"]), row["idpoint_token"], repr(row["access_point_token"]))
    print("IO1 sul controller:", controller.io_assignments["IO1"])

    # L'utente rinuncia: riapre la scheda (mostra Non Usato) e salva Non Usato con il nome di serie
    controller.calls.clear()
    await service.update_input("IO1", {"name": "Ingresso AUX 1", "role": ""}, "admin")
    print("risalvato Non Usato -> chiamate:", controller.calls)
    print("IO1 sul controller:", controller.io_assignments["IO1"])
    io1 = {i["io"]: i for i in (await service.read())["inputs"]}["IO1"]
    print("pagina:", repr(io1["role"]), "assegnato:", io1["assigned"])


asyncio.run(main())

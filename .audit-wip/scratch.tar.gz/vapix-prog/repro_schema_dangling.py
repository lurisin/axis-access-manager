"""Punto di accesso rimasto su una porta tolta dal controller (ripristino completo con la riga della porta spuntata
e quella del punto no): lo schema lo include nei collegamenti (linksOf), ma set_links li rifiuta e lo schema non
si salva più, nemmeno per modifiche che non c'entrano."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService
from app.service import ServiceError


def links_of(p):
    """Stessa logica di linksOf() in index.html."""
    links = []
    for a in p["access_points"]:
        for r in a["readers"]:
            if a["door"] and not any(x["reader"] == r and x["door"] == a["door"] for x in links):
                links.append({"reader": r, "door": a["door"], "direction": a["direction"] or "", "enabled": a["enabled"]})
    return links


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    service = ProgrammingService(db, controller, 1, asyncio.Lock())
    controller.access_points.append(
        {
            "token": "ap-cantina",
            "Entity": "porta2",
            "EntityType": "axtdc:Door",
            "Name": "Cantina",
            "Enabled": True,
            "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": "u"}],
            "Attribute": [{"Name": "Direction", "Value": "in"}],
        }
    )
    await controller.remove_door("porta2")  # porta tolta, punto di accesso rimasto

    p = await service.read()
    pending = links_of(p)
    print("collegamenti mandati dallo schema:", pending)
    print("porte nello schema:", [d["token"] for d in p["doors"]])
    # L'utente cambia solo la direzione/attivazione dell'altro lettore e preme Salva
    pending[0]["enabled"] = False
    try:
        await service.set_links(pending, "admin")
    except ServiceError as err:
        print("Salva:", err)


asyncio.run(main())

"""Sensore Porta impostato a mano mentre l'app ha già una riga per DPS con ruolo "": non si toglie."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    service = ProgrammingService(db, controller, cid, asyncio.Lock())

    # 1) L'utente dà solo un nome all'ingresso contatto porta, ruolo Non Usato: nasce la riga nel database
    await service.update_input("DPS", {"name": "Contatto Ingresso", "role": ""}, "admin")
    print("riga DPS:", {k: db.controller_inputs(cid)["DPS"][k] for k in ("name", "role", "door_token", "contact")})

    # 2) L'installatore imposta il contatto porta a mano dalla pagina web del controller (come nel test del banco)
    controller.door_configs["porta"]["Configuration"] += [
        {"Name": "DoorMonitor.Type", "Value": "Standard"},
        {"Name": "DoorMonitor.ValueWhenOpen", "Value": "Input Ground"},
        {"Name": "DoorMonitor.ValueWhenClosed", "Value": "Input Open"},
    ]
    users = [
        {"Type": "doorcontrol", "token": "porta", "Usage": u, "MultiIo": False}
        for u in ("DoorOpenMonitor", "DoorClosedMonitor")
    ]
    await controller.set_io_assignment("DPS", "in:pu/gnd", users)

    dps = {i["io"]: i for i in (await service.read())["inputs"]}["DPS"]
    print("pagina mostra:", dps["role"], dps["door"], dps["contact"])

    # 3) Dalla scheda l'utente sceglie Non Usato (stesso nome, la UI manda anche porta e contatto mostrati)
    controller.calls.clear()
    saved = await service.update_input(
        "DPS", {"name": "Contatto Ingresso", "role": "", "door": "porta", "contact": "no"}, "admin"
    )
    print("risposta:", saved)
    print("chiamate al controller:", controller.calls)
    config = {c["Name"]: c["Value"] for c in controller.door_configs["porta"]["Configuration"]}
    print("DoorMonitor.Type sul controller:", config["DoorMonitor.Type"])
    print("DPS assegnato a:", [u["Usage"] for u in controller.io_assignments["DPS"]["IoUser"]])
    dps = {i["io"]: i for i in (await service.read())["inputs"]}["DPS"]
    print("pagina dopo il salvataggio:", dps["role"], dps["door"])


asyncio.run(main())

"""Annulla di una modifica vecchia: riscrive l'oggetto intero com'era, quindi annulla anche le modifiche
successive (dell'app o fatte sul controller) senza dirlo; e un oggetto tolto nel frattempo rinasce."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    service = ProgrammingService(db, controller, 1, asyncio.Lock())

    # Lunedì: si rinomina la porta. Martedì: si abbassa il tempo di apertura da 7 a 4 secondi
    await service.update_door("porta", {"name": "Portone", "description": ""}, "admin")
    await service.update_door("porta", {"name": "Portone", "description": "", "access_time": 4}, "admin")
    changes = db.list_controller_changes(1)
    print("storico:", [(c["id"], c["summary"], c["undone"]) for c in changes])
    print("sul controller:", controller.doors["porta"]["Name"], controller.doors["porta"]["AccessTime"])

    # Mercoledì: si annulla la rinomina (la riga più vecchia)
    await service.undo(changes[-1]["id"], "admin")
    print("dopo l'annullamento della rinomina:", controller.doors["porta"]["Name"], controller.doors["porta"]["AccessTime"])
    print("storico:", [(c["id"], c["summary"], c["undone"]) for c in db.list_controller_changes(1)])

    # Il tempo di apertura cambiato a mano sul controller dopo una modifica dell'app sparisce anche lui
    controller.doors["porta2"]["AccessTime"] = "PT3S"  # stato di partenza
    await service.update_door("porta2", {"name": "Cantina B", "description": ""}, "admin")
    controller.doors["porta2"]["AccessTime"] = "PT9S"  # cambiato dalla pagina web dell'A1210
    change = db.list_controller_changes(1)[0]
    await service.undo(change["id"], "admin")
    print("porta2 dopo l'annullamento della rinomina:", controller.doors["porta2"])

    # Punto di accesso tolto nel frattempo (per esempio dal ripristino completo): l'annullamento lo ricrea
    await service.set_links([{"reader": "lettore-2", "door": "porta", "direction": "in"}], "admin")
    change = db.list_controller_changes(1)[0]
    await controller.remove_access_point("ap-in")
    await service.undo(change["id"], "admin")
    print("punti di accesso dopo l'annullamento:", [a["token"] for a in controller.access_points])
    print("gestiti dal controller:", controller.managed())


asyncio.run(main())

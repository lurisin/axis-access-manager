"""Indirizzo IPv6 scritto senza parentesi (o con due ':'): passa la validazione di controller_fields, ma
httpx.AsyncClient(base_url=...) solleva InvalidURL (non HTTPError). Salvare il controller rompe il runtime e al
riavvio successivo l'add-on non parte più."""

import os
import tempfile
from pathlib import Path

from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
tmp = Path(tempfile.mkdtemp())
db_path = tmp / "aam.db"
settings = parse_options({})

app = create_app(settings, allow_any_client=True, db_path=db_path)
with TestClient(app, raise_server_exceptions=False) as client:
    data = {
        "name": "A1210",
        "host": "2001:db8::50",
        "username": "root",
        "password": "x",
        "mqtt_topic_prefix": "accessi",
    }
    response = client.post("/api/controllers", json=data)
    print("salvataggio controller:", response.status_code, response.text[:120])
    print("controller nel database:", [c["host"] for c in client.app.state.db.list_controllers()])
    response = client.get("/api/summary")
    print("/api/summary dopo:", response.status_code)

print("--- riavvio dell'add-on con lo stesso database ---")
app = create_app(settings, allow_any_client=True, db_path=db_path)
try:
    with TestClient(app, raise_server_exceptions=False) as client:
        print("avvio riuscito:", client.get("/api/summary").status_code)
except Exception as err:  # noqa: BLE001
    print("AVVIO FALLITO:", type(err).__name__, err)

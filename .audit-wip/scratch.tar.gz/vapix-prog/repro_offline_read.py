"""Controller spento: GET /api/programming fa ogni lettura in fila, ciascuna fino al timeout di 10 s.
Si contano le richieste e si stima l'attesa con il timeout vero dell'A1210Client."""

import asyncio
import tempfile
import time
from pathlib import Path

import httpx

from app.db import Database
from app.programming import ProgrammingService
from app.vapix import A1210Client, ControllerGuard

calls = []


async def handler(request):
    calls.append(request.content[:40])
    await asyncio.sleep(0.2)  # al posto dei 10 s del ConnectTimeout vero
    raise httpx.ConnectTimeout("timed out", request=request)


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    client = ControllerGuard(A1210Client("a1210.local", "u", "p", transport=httpx.MockTransport(handler)))
    print("timeout del client:", client.client._client.timeout)
    service = ProgrammingService(db, client, cid, asyncio.Lock())
    started = time.monotonic()
    data = await service.read()
    print(f"richieste in fila: {len(calls)} (qui {time.monotonic() - started:.1f} s; con 10 s ciascuna: {len(calls) * 10} s)")
    print("errori mostrati:", len(data["errors"]))
    print("lo storico (dal database) arriva solo dopo:", data["changes"])


asyncio.run(main())

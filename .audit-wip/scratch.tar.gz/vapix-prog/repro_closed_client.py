"""reload_runtime chiude il client httpx mentre la sincronizzazione periodica lo sta usando: la richiesta dopo
solleva RuntimeError (non VapixError) e il task _maintenance muore per sempre."""

import asyncio
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

import httpx
from conftest import FakeController  # noqa: F401  (solo per PYTHONPATH coerente)

from app.config import parse_options
from app.db import Database
from app.main import _maintenance
from app.service import AccessService
from app.vapix import A1210Client, ControllerGuard


async def main():
    first_page = asyncio.Event()
    release = asyncio.Event()

    async def handler(request):
        body = json.loads(request.content)
        method = next(iter(body))
        if method == "pacsaxis:GetCredentialList" and "StartReference" not in body[method]:
            first_page.set()
            await release.wait()  # il controller risponde lento (A1210 con qualche centinaio di tessere)
            return httpx.Response(200, json={"Credential": [], "NextStartReference": "300"})
        key = method.split(":")[1].replace("Get", "").replace("List", "")
        return httpx.Response(200, json={key: []})

    raw = A1210Client("a1210.local", "u", "p", transport=httpx.MockTransport(handler))
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "x"})
    service = AccessService(db, ControllerGuard(raw), settings)

    ready = asyncio.Event()
    ready.set()
    state = SimpleNamespace(
        health_ready=ready,
        controller=SimpleNamespace(paused=""),
        settings=settings,
        service=service,
        sync_wake=asyncio.Event(),
        last_sync=None,
        db=db,
        ha=SimpleNamespace(delete_snapshots=lambda files: None),
    )
    task = asyncio.create_task(_maintenance(SimpleNamespace(state=state)))
    await first_page.wait()
    # Nel frattempo un utente salva le impostazioni di una porta: reload_runtime -> _stop_runtime -> aclose()
    await raw.aclose()
    release.set()
    await asyncio.sleep(0.1)
    print("task _maintenance finito:", task.done())
    if task.done():
        print("eccezione:", repr(task.exception()))
    print("last_sync:", state.last_sync)


asyncio.run(main())

"""Errore a metà su un ingresso: il punto di accesso è già tolto, il database tiene il ruolo vecchio,
e risalvare le stesse impostazioni non ripara niente (before == values)."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService, is_rex_profile
from app.service import ServiceError


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    service = ProgrammingService(db, controller, cid, asyncio.Lock())

    settings = {"name": "Pulsante Portineria", "role": "rex", "door": "porta", "contact": "no", "supervised": False}
    await service.update_input("IO1", settings, "admin")
    row = db.controller_inputs(cid)["IO1"]
    print("prima:", row["role"], row["idpoint_token"], row["access_point_token"])
    print("  AP sul controller:", [a["token"] for a in controller.access_points])
    print("  profili REX:", [p["AccessPolicy"] for p in controller.profiles.values() if is_rex_profile(p)])

    # L'utente vuole togliere il ruolo; il controller rifiuta la liberazione dell'I/O (dopo che l'AP è già tolto)
    controller.fail_io_assignment = True
    try:
        await service.update_input("IO1", {**settings, "role": ""}, "admin")
    except ServiceError as err:
        print("errore mostrato:", err)
    controller.fail_io_assignment = False
    row = db.controller_inputs(cid)["IO1"]
    print("dopo l'errore, nel database:", row["role"], row["door_token"], repr(row["access_point_token"]))
    print("  AP sul controller:", [a["token"] for a in controller.access_points])
    print("  profili REX:", [p["AccessPolicy"] for p in controller.profiles.values() if is_rex_profile(p)])
    print("  IO1 assegnato a:", controller.io_assignments["IO1"]["IoUser"])
    page = await service.read()
    io1 = {i["io"]: i for i in page["inputs"]}["IO1"]
    print("  pagina:", io1["role"], io1["door"], "rex_missing =", page["rex_missing"])

    # L'utente ci ripensa e risalva il pulsante come prima: nessuna scrittura, il pulsante resta senza AP
    controller.calls.clear()
    print("risalvato:", await service.update_input("IO1", settings, "admin"))
    print("  chiamate al controller:", controller.calls)
    print("  AP sul controller:", [a["token"] for a in controller.access_points])
    print("  profili REX:", [p["AccessPolicy"] for p in controller.profiles.values() if is_rex_profile(p)])


asyncio.run(main())

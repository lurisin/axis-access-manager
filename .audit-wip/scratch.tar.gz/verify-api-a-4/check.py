import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    db = app.state.db
    print("categories at start:", [(x["id"], x["name"], x["group_token"]) for x in db.list_categories()])
    door = app.state.doors[0]["id"]
    # Two categories sharing the same profile (post-0.10 migration), created via API then forced to share
    r1 = c.post("/api/categories", json={"name": "Ospiti", "color": "blue", "rules": [{"target": "door", "target_id": door, "schedule": "standard_always"}]}).json()
    r2 = c.post("/api/categories", json={"name": "Fornitori", "color": "blue", "rules": [{"target": "door", "target_id": door, "schedule": "standard_always"}]}).json()
    print("created", r1, r2)
    db.save_category(r2["id"], {**db.get_category(r2["id"]), "group_token": r1["token"]})
    ids = []
    for i, n in enumerate(["Anna", "Bruno", "Carla"]):
        p = c.post("/api/persons", json={"name": n, "card": f"04a{i}", "category_id": r1["id"]}).json()
        ids.append(p["id"])
    print("profiles:", [c.get(f"/api/persons/{i}").json()["cards"][0]["access_profile"] for i in ids])
    orig = ctrl.set_credential
    n = {"k": 0}
    async def flaky(cred):
        n["k"] += 1
        if n["k"] == 2:
            raise VapixError("il controller non risponde (ReadTimeout)")
        return await orig(cred)
    ctrl.set_credential = flaky
    body = {"name": "Ospiti", "color": "blue", "rules": [{"target": "door", "target_id": door, "schedule": "standard_office_hours"}]}
    r = c.put(f"/api/categories/{r1['id']}", json=body)
    print("first try:", r.status_code, r.json())
    r = c.put(f"/api/categories/{r1['id']}", json=body)
    print("retry:", r.status_code, r.json())
    cats = {x["id"]: x for x in c.get("/api/categories").json()}
    print("Ospiti token:", cats[r1["id"]]["group_token"], "custom:", cats[r1["id"]]["custom"], "Fornitori token:", cats[r2["id"]]["group_token"])
    print("profiles:", [c.get(f"/api/persons/{i}").json()["cards"][0]["access_profile"] for i in ids])
    profs = {p["token"]: p for p in ctrl.profiles.values()} if hasattr(ctrl, "profiles") else None
    old = [p for p in (ctrl.access_profiles if hasattr(ctrl,'access_profiles') else [])]

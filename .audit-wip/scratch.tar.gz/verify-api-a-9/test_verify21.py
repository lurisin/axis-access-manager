pytest_plugins = ["conftest"]
import pytest
from app.events import EventMonitor
from app.service import AccessService


@pytest.fixture
def service(db, controller, settings):
    return AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))


async def test_add_card_to_userless_person(service, controller, db):
    tok = controller.add_existing("x", "Ospite X", "04aa")
    controller.credentials[tok].pop("UserToken")
    controller.users.clear()
    await service.sync_from_controller()
    [person] = db.all_persons()
    print("person token:", person["axis_user_token"])
    await service.add_card(person["id"], "04bb", "admin")
    new = [c for c in controller.credentials.values() if c["IdData"][0]["Value"] == "04bb"][0]
    print("UserToken sent:", new["UserToken"], "users on controller:", list(controller.users))
    print("person token after:", db.get_person(person["id"])["axis_user_token"])
    # compare restore_person path

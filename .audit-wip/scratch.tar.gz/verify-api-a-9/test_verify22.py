pytest_plugins = ["conftest"]
import pytest
from app.events import EventMonitor
from app.service import AccessService
from app.transfer import import_persons


@pytest.fixture
def service(db, controller, settings):
    return AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))


async def test_import_new_card_existing_person(service, controller, db):
    controller.access_profiles = getattr(controller, "access_profiles", {})
    p = await service.create_person("Mario Rossi", "04AA", "admin", group="profilo_sempre")
    groups = [{"token": "profilo_sempre", "name": "Sempre"}]
    text = "nome;tessera;gruppo;valida_dal;valida_al;ditta;note;tipologia\nMario Rossi;04bb;;01/11/2026;30/11/2026;ACME;nota;\n"
    prev = await import_persons(service, text, groups, "admin", False)
    print("preview:", prev["righe"])
    res = await import_persons(service, text, groups, "admin", True)
    print("apply:", res["righe"])
    for c in db.get_person(p["id"])["cards"]:
        print(c["number"], c["access_profile"], c["valid_from"], c["valid_to"])
    print("company:", db.get_person(p["id"])["company"])

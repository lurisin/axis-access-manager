pytest_plugins = ["conftest"]
from fastapi.testclient import TestClient
from app.main import create_app


def test_rex_profile_via_groups(settings, controller, tmp_path, monkeypatch):
    monkeypatch.delenv("SUPERVISOR_TOKEN", raising=False)
    controller.profiles["rex-1"] = {
        "token": "rex-1", "Name": "Uscite e Citofono",
        "Description": "Pulsanti di uscita e relè del citofono (Axis Access Manager)",
        "Enabled": True, "Schedule": ["standard_always"], "AuthenticationProfile": ["REXOnly"],
        "AccessPolicy": [{"AccessPoint": "ap-rex", "AuthorizationProfile": [], "Attribute": [], "Schedule": ["standard_always"]}],
    }
    app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp_path / "x.db")
    with TestClient(app) as client:
        groups = client.get("/api/groups").json()["groups"]
        print("listed:", [g["token"] for g in groups])
        sched = next(iter(controller.schedules), None)
        print("schedules:", list(controller.schedules))
        if sched:
            r = client.put("/api/groups/rex-1", json={"name": "X", "description": "", "schedule": sched})
            print("PUT", r.status_code, r.text[:200], controller.profiles.get("rex-1", {}).get("Schedule"))
        r = client.delete("/api/groups/rex-1")
        print("DELETE", r.status_code, r.text[:200], "rex-1" in controller.profiles)

pytest_plugins = ["conftest"]
from app.rules_service import RulesService
from app.service import AccessService
from app.programming import rex_uncovered


async def test_rex_profile_direct(db, controller, settings):
    rules = RulesService(AccessService(db, controller, settings))
    controller.profiles["rex-1"] = {
        "token": "rex-1", "Name": "Uscite e Citofono",
        "Description": "Pulsanti di uscita e relè del citofono (Axis Access Manager)",
        "Enabled": True, "Schedule": ["standard_always"], "AuthenticationProfile": ["REXOnly"],
        "AccessPolicy": [{"AccessPoint": "ap-rex", "AuthorizationProfile": [], "Attribute": [], "Schedule": ["standard_always"]}],
    }
    await rules.update_group("rex-1", "X", "", "standard_office_hours", "u")
    p = controller.profiles["rex-1"]
    print("after PUT:", p["Name"], p["Schedule"], p["AccessPolicy"][0]["Schedule"])
    await rules.delete_group("rex-1", "u")
    print("after DELETE present:", "rex-1" in controller.profiles, rex_uncovered(list(controller.profiles.values()), ["ap-rex"]))

import asyncio, json, tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from conftest import FakeController
from app import main
from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService

P = "accessi/x"

def log_entry(rowid, ts, cred):
    return {"rowid": rowid, "UtcTime": ts.strftime("%Y-%m-%dT%H:%M:%S.000000Z"), "KeyValues": [
        {"Key": "topic0", "Value": "AccessControl"}, {"Key": "topic1", "Value": "AccessGranted"},
        {"Key": "topic2", "Value": "Card"}, {"Key": "AccessPointToken", "Value": "ap-in"},
        {"Key": "CredentialToken", "Value": cred}]}

def mqtt(monitor, ts, cred):
    body = {"timestamp": int(ts.timestamp() * 1000), "message": {"data": {"CredentialToken": cred, "AccessPointToken": "ap-in"}}}
    monitor.handle(f"{P}/eventi/AccessControl/AccessGranted/Card/", json.dumps(body).encode())

async def scenario(live_before_tick: bool):
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    controller = FakeController()
    settings = parse_options({"a1210_host": "a", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": P})
    monitor = EventMonitor(prefix=P, door_token="porta")
    service = AccessService(db, controller, settings, monitor)
    monitor.on_event = service.record_event
    mario = await service.create_person("Mario", "04aa", "admin")
    anna = await service.create_person("Anna", "04bb", "admin")
    cm, ca = mario["cards"][0]["axis_credential_token"], anna["cards"][0]["axis_credential_token"]
    now = datetime.now(tz=UTC).replace(microsecond=0)
    t0, tlost, tlive = now - timedelta(minutes=40), now - timedelta(minutes=20), now - timedelta(seconds=15)
    monitor.connected = True
    monitor.handle(f"{P}/stato", b"online")
    mqtt(monitor, t0, cm)
    state = SimpleNamespace(monitor=monitor, recover_pending=False, recover_outages=0,
        installation=SimpleNamespace(primary={"id": 1}), health=SimpleNamespace(states={1: SimpleNamespace(online=True)}),
        controller=SimpleNamespace(paused=""), mqtt=object(), db=db, service=service, last_recovery=None)
    # controller goes offline (LWT) -> outage; tick while offline does nothing
    monitor.handle(f"{P}/stato", b"offline")
    await main._recover_if_needed(state)
    controller.log_events = [log_entry(1, t0, cm), log_entry(2, tlost, ca), log_entry(3, tlive, cm)]
    monitor.handle(f"{P}/stato", b"online")
    if live_before_tick:
        mqtt(monitor, tlive, cm)
    await main._recover_if_needed(state)
    if not live_before_tick:
        mqtt(monitor, tlive, cm)
    names = sorted((e["ts"][11:19], e["person_name"], bool(e["recovered"])) for e in db.list_events())
    print("live before tick" if live_before_tick else "no live before tick", "->", state.last_recovery["since"][11:19], state.last_recovery["events"], names, "pending:", state.recover_pending)
    # later ticks
    await main._recover_if_needed(state)
    print("   after another tick, events:", len(db.list_events()))

asyncio.run(scenario(False))
asyncio.run(scenario(True))

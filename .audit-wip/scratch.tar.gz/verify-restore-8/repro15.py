import os, tempfile
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from conftest import FakeController
from fastapi.testclient import TestClient
from harness import settings
from app.main import create_app

tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings(), allow_any_client=True, controller=controller, db_path=tmp / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    p = client.post("/api/persons", json={"name": "Anna", "card": "04aa"}, headers=admin).json()
    old = client.post("/api/backups", json={"name": "Prima"}, headers=admin).json()
    client.delete(f"/api/persons/{p['id']}", headers=admin)
    preview = client.post(f"/api/backups/{old['id']}/preview", json={"sections": ["persone"]}, headers=admin).json()
    keys = [i["key"] for i in preview["items"] if i["default"]]
    print("keys:", keys)
    controller.fail_set_credential = True
    r = client.post(f"/api/backups/{old['id']}/restore", json={"sections": ["persone"], "keys": keys}, headers=admin)
    res = r.json()
    print(r.status_code, res)
    # same expression as index.html:3737
    print("titolo UI:", "Ripristino Parziale" if len(res["failed"]) else "Ripristino Fatto")

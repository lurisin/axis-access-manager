from harness import make_plant, preview, restore, run

FULL = ["dispositivo", "controller", "tessere"]

async def main():
    plant, db, controller = make_plant()
    db._execute("UPDATE doors SET name = 'Porta Scala'")
    print("doors db:", [(d["name"], d["door_token"]) for d in db.list_doors()])
    print("readers:", {t: r["Name"] for t, r in controller.idpoints.items()})
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()
    controller.factory_reset()
    items = await preview(plant, backup["id"], FULL)
    for i in items:
        if i["section"] == "controller":
            print(" ", i["key"], "|", i["label"], "|", i.get("blocked") or "")
    items, result = await restore(plant, backup["id"], FULL, password="x")
    print("applied:", [a.get("label") if isinstance(a, dict) else a for a in result["applied"]][:20])

run(main())

// Nome e Tempi: un campo tempo lasciato vuoto diventa 0 (Number("")) e il Preallarme si scrive PT0S
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";

(async () => {
  console.log("prima:", JSON.stringify((await (await fetch(BASE + "debug/doors")).json()).porta));
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  await page.goto(BASE + "#impianti/c1/porte");
  await page.waitForSelector('[data-pd="porta"]');
  await page.click('[data-pd="porta"]');
  await page.waitForSelector('#modal[open] [name="pre_alarm_time"]');
  await page.fill('#modal [name="pre_alarm_time"]', "");
  await page.fill('#modal [name="name"]', "Ingresso scala B");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(1500);
  console.log("toast:", await page.textContent("#toast"));
  console.log("dopo:", JSON.stringify((await (await fetch(BASE + "debug/doors")).json()).porta));
  await browser.close();
})();

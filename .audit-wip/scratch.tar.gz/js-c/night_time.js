// Impostazioni → Backup: digitare l'orario notturno; ogni "change" salva e ridisegna la pagina
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const puts = [];
  page.on("request", (r) => { if (r.url().includes("api/backups/policy")) puts.push(r.postData()); });
  await page.goto(BASE + "#impostazioni/backup");
  await page.waitForSelector('[data-bp="night"]');
  console.log("prima:", await page.$eval('[data-bp="night"]', (i) => i.value));
  await page.focus('[data-bp="night"]');
  await page.keyboard.type("0415", {delay: 150});
  await page.waitForTimeout(1500);
  console.log("PUT inviati:", puts);
  console.log("valore mostrato:", await page.$eval('[data-bp="night"]', (i) => i.value));
  const policy = (await (await fetch(BASE + "api/backups")).json()).policy;
  console.log("salvato:", policy.night);
  await browser.close();
})();

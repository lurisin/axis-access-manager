// Connessione del controller: se api/locations non risponde l'area diventa "Nessuna Area" e Salva la toglie,
// con le tipologie per area che perdono le porte del controller
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";
const j = async (path, method = "GET", body) => (await fetch(BASE + path, {method, headers: {"Content-Type": "application/json"}, body: body && JSON.stringify(body)})).json();

(async () => {
  const before = (await j("api/installation")).controllers[0];
  const cat = await j("api/categories", "POST", {name: "Dipendenti", color: "blue", rules: [{target: "area", target_id: before.area_id, schedule: "standard_always"}]});
  const cats = await j("api/categories");
  const token = (cats.find((c) => c.name === "Dipendenti") || cat).group_token;
  const profile = async () => (await j("api/groups")).groups.find((g) => g.token === token);
  console.log("area del controller:", before.area_id, "| tipologia:", token, JSON.stringify(cat).slice(0, 120));

  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  // Un errore di rete passeggero proprio su api/locations
  await page.route("**/api/locations", (route) => route.abort());
  await page.goto(BASE + "#impianti/c1/connessione");
  await page.waitForSelector("#conn-form");
  console.log("area mostrata:", await page.$eval('#conn-form select[name="area_id"]', (s) => s.options[s.selectedIndex].textContent));
  // Si cambia solo la descrizione e si salva
  await page.fill('#conn-form [name="description"]', "quadro sotto la scala");
  await page.fill('#conn-form [name="username"]', "root");
  await page.fill('#conn-form [name="password"]', "pass");
  await page.click('#conn-form button[type="submit"]');
  await page.waitForTimeout(2000);
  console.log("toast:", await page.textContent("#toast"));
  const after = (await j("api/installation")).controllers[0];
  console.log("area dopo Salva:", after.area_id, "| place:", JSON.stringify(after.place));
  console.log("profili:", JSON.stringify((await j("api/groups")).groups.map((g) => [g.token, g.name])).slice(0, 300));
  await browser.close();
})();

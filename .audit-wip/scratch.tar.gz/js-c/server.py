"""Avvia l'app con il FakeController dei test, per provare la pagina con un browser vero.

Uso (dalla radice del repo):
  PYTHONPATH=axis_access_manager:tests python3 .../server.py PORT DBPATH [scenario]
"""

import copy
import os
import sys

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

import uvicorn  # noqa: E402
from conftest import FakeController  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

port = int(sys.argv[1])
db_path = sys.argv[2]
scenario = sys.argv[3] if len(sys.argv) > 3 else ""

settings = parse_options(
    {
        "a1210_host": "a1210.local",
        "door_token": "porta",
        "access_profile": "profilo_sempre",
        "mqtt_topic_prefix": "accessi/x",
    }
)
ctrl = FakeController()
if scenario == "schema":
    # Porta con due punti di accesso: ingresso attivo con lettore-1, uscita DISATTIVATA con lettore-2
    ctrl.access_points[0]["IdPointDevice"] = [{"IdPoint": "lettore-1", "DeviceUUID": "uuid-a1210"}]
    ctrl.access_points.append(
        {
            "token": "ap-out",
            "Entity": "porta",
            "EntityType": "axtdc:Door",
            "Name": "Uscita",
            "Enabled": False,
            "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": "uuid-a1210"}],
            "Attribute": [{"Name": "Direction", "Value": "out"}],
        }
    )
    ctrl.access_controllers["Axis-x AccessController"]["AccessPoint"].append("ap-out")

app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=db_path)


@app.get("/debug/access-points")
async def debug_aps() -> list:
    return copy.deepcopy(ctrl.access_points)


@app.get("/debug/doors")
async def debug_doors() -> dict:
    return copy.deepcopy(ctrl.doors)


uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")

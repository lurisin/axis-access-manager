"""Nuovo controller dalla pagina: area_id 0 (Nessuna Area preselezionata) invece di None, la struttura predefinita
del backend non si crea; al riavvio ensure_default_site lo sposta da solo."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options({"a1210_host": "", "mqtt_topic_prefix": "accessi/x"})
body = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "verify_ssl": False,
        "mqtt_topic_prefix": "accessi/x", "description": ""}
for label, area in (("come la pagina (area_id 0)", 0), ("senza area_id (default del backend)", None)):
    db_path = Path(tempfile.mkdtemp()) / "n.db"
    payload = {**body, **({"area_id": area} if area is not None else {})}
    with TestClient(create_app(settings, allow_any_client=True, controller=FakeController(), db_path=db_path)) as c:
        print(label, "-> sites prima:", [s["name"] for s in c.get("/api/locations").json()])
        c.post("/api/controllers", json=payload)
        ctrl = c.get("/api/installation").json()["controllers"][0]
        print("   place:", ctrl["place"])
    # Riavvio dell'add-on
    with TestClient(create_app(settings, allow_any_client=True, controller=FakeController(), db_path=db_path)) as c:
        ctrl = c.get("/api/installation").json()["controllers"][0]
        print("   dopo il riavvio:", ctrl["place"])

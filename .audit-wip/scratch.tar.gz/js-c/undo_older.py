"""Storico Modifiche: annullare una modifica vecchia cancella in silenzio quelle successive sullo stesso oggetto."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController

from app.db import Database
from app.programming import ProgrammingService


async def main() -> None:
    db = Database(Path(tempfile.mkdtemp()) / "u.db")
    ctrl = FakeController()
    ctrl.access_points[0]["IdPointDevice"] = [{"IdPoint": "lettore-1", "DeviceUUID": "uuid-a1210"}]
    service = ProgrammingService(db, ctrl, 1, asyncio.Lock())

    # Modifica A: si collega anche il lettore interno all'ingresso
    await service.set_links(
        [
            {"reader": "lettore-1", "door": "porta", "direction": "in"},
            {"reader": "lettore-2", "door": "porta", "direction": "in"},
        ],
        "admin",
    )
    # Modifica B (dopo): l'ingresso viene DISATTIVATO
    await service.set_links(
        [
            {"reader": "lettore-1", "door": "porta", "direction": "in", "enabled": False},
            {"reader": "lettore-2", "door": "porta", "direction": "in", "enabled": False},
        ],
        "admin",
    )
    ap = ctrl.access_points[0]
    print("dopo A e B:", ap["Enabled"], [d["IdPoint"] for d in ap["IdPointDevice"]])
    changes = db.list_controller_changes(1)
    print("storico (dal più recente):", [(c["id"], c["summary"], c["undone"]) for c in changes])
    older = changes[-1]
    # L'utente annulla solo A ("togli il lettore interno")
    await service.undo(older["id"], "admin")
    ap = ctrl.access_points[0]
    print("dopo l'annullamento di A:", "Enabled =", ap["Enabled"], [d["IdPoint"] for d in ap["IdPointDevice"]])
    print("storico:", [(c["id"], c["undone"]) for c in db.list_controller_changes(1)])

    # Stessa cosa sui tempi della porta
    await service.update_door("porta", {"name": "Ingresso A"}, "admin")
    await service.update_door("porta", {"name": "Ingresso A", "access_time": 3}, "admin")
    changes = db.list_controller_changes(1)
    rename = next(c for c in changes if c["summary"] == "porta Ingresso A" and not c["undone"])
    await service.undo(changes[1]["id"], "admin")
    print("porta dopo l'annullamento del nome:", ctrl.doors["porta"]["Name"], ctrl.doors["porta"]["AccessTime"], rename["id"])
    db.close()


asyncio.run(main())

// Telecamera spostata su un'altra porta: se la seconda scrittura fallisce, la prima porta l'ha già persa
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";
const j = async (path, method = "GET", body) => (await fetch(BASE + path, {method, headers: {"Content-Type": "application/json"}, body: body && JSON.stringify(body)})).json();

(async () => {
  // Preparazione: telecamera sulla porta 1, seconda porta nell'app
  const inst = await j("api/installation");
  const door = inst.controllers[0].doors[0];
  await j(`api/doors/${door.id}`, "PUT", {...door, snapshot_camera: "camera.ingresso", snapshot_on_granted: true});
  if (inst.controllers[0].doors.length < 2) await j("api/controllers/1/doors", "POST", {door_token: "porta2", name: "Cantina"});
  console.log("prima:", (await j("api/installation")).controllers[0].doors.map((d) => [d.name, d.snapshot_camera, d.snapshot_on_granted]));

  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  await page.goto(BASE + "#impianti/c1/telecamere");
  await page.waitForSelector(`[data-cam-edit="${door.id}"]`);
  await page.click(`[data-cam-edit="${door.id}"]`);
  await page.waitForSelector('#modal[open] [name="camera"]');
  // Home Assistant non ha dato telecamere: campo di testo. Si sposta sulla Cantina con un refuso nell'entità
  const other = (await j("api/installation")).controllers[0].doors.find((d) => d.door_token === "porta2");
  await page.selectOption('#modal select[name="door"]', String(other.id));
  await page.fill('#modal [name="camera"]', "ingresso");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(1500);
  console.log("toast:", await page.textContent("#toast"));
  console.log("finestra ancora aperta:", await page.$eval("#modal", (d) => d.open));
  await page.click("#modal .dlg-foot button:not(.primary)"); // Annulla
  await page.waitForTimeout(300);
  console.log("dopo Annulla:", (await j("api/installation")).controllers[0].doors.map((d) => [d.name, d.snapshot_camera, d.snapshot_on_granted]));
  await browser.close();
})();

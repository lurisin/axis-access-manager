// Confronta: una risposta lenta arrivata dopo quella della scelta più recente la sovrascrive
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";
const j = async (path, method = "GET", body) => (await fetch(BASE + path, {method, headers: {"Content-Type": "application/json"}, body: body && JSON.stringify(body)})).json();

(async () => {
  await j("api/backups", "POST", {name: "Uno"});
  await j("api/persons", "POST", {name: "Anna", card: "04aa"});
  await j("api/backups", "POST", {name: "Due"});
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  // Lettura dello stato attuale lenta (controller lento o che non risponde)
  await page.route("**/compare?other=attuale*", async (route) => { await new Promise((r) => setTimeout(r, 2500)); await route.continue(); });
  await page.goto(BASE + "#impianti/backup");
  await page.waitForSelector("#bk-list [data-cmp]");
  await page.click("#bk-list .bk-row:first-child [data-cmp]");
  await page.waitForSelector('#modal[open] select[name="other"]');
  await page.waitForTimeout(500);
  await page.selectOption('#modal select[name="other"]', "attuale");
  await page.waitForTimeout(200);
  await page.selectOption('#modal select[name="other"]', "precedente");
  await page.waitForTimeout(800);
  console.log("scelto:", await page.$eval('#modal select[name="other"]', (s) => s.value), "| mostrato:", (await page.textContent("#cmp-body p")).trim());
  await page.waitForTimeout(3000);
  console.log("scelto:", await page.$eval('#modal select[name="other"]', (s) => s.value), "| mostrato:", (await page.textContent("#cmp-body p")).trim());
  await browser.close();
})();

// Schema lettori → porte: spostare un lettore nella direzione di un punto di accesso DISATTIVATO lo riattiva
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  console.log("prima:", JSON.stringify((await (await fetch(BASE + "debug/access-points")).json()).map((p) => [p.token, p.Enabled, p.IdPointDevice.map((d) => d.IdPoint)])));
  await page.goto(BASE + "#impianti/c1");
  await page.waitForSelector("#schema [data-link]");
  console.log("meta lettori:", await page.$$eval("[data-reader-meta]", (els) => els.map((e) => e.textContent)));
  // Ingranaggio del filo lettore-1 → porta (in, attivo)
  const gears = await page.$$("[data-link]");
  for (const g of gears) console.log("gear:", await g.getAttribute("title"));
  await page.click('[data-link][title^="Lettore esterno"]');
  await page.waitForSelector('#modal[open] select[name="direction"]');
  console.log("hint nella finestra:", await page.textContent("#modal .dlg-body p.hint"));
  console.log("Collegamento Attivo (spunta iniziale):", await page.isChecked("#f-le"));
  await page.selectOption('#modal select[name="direction"]', "out");
  await page.click('#modal .dlg-foot button.primary');
  await page.waitForTimeout(300);
  console.log("barra modifiche:", await page.textContent("#sch-changes"));
  console.log("elenco completo:", JSON.stringify(await page.getAttribute("#sch-changes", "title")));
  await page.click("#sch-save");
  await page.waitForSelector("#modal[open] .dlg-body");
  console.log("conferma:", (await page.textContent("#modal .dlg-body")).replace(/\s+/g, " "));
  await page.click('#modal .dlg-foot button.primary');
  await page.waitForTimeout(1500);
  console.log("dopo:", JSON.stringify((await (await fetch(BASE + "debug/access-points")).json()).map((p) => [p.token, p.Enabled, p.IdPointDevice.map((d) => d.IdPoint)])));
  await browser.close();
})();

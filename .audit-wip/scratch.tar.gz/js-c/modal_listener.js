// "Cosa Cambierà" aggiunge un listener "change" al <dialog id="modal"> condiviso e non lo toglie mai:
// nelle finestre aperte dopo, ogni change riscrive il pulsante principale in "Ripristina Selezionati (0)"
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  page.on("console", (m) => { if (m.type() === "error") console.log("CONSOLE", m.text()); });
  await page.goto(BASE + "#impianti/backup");
  await page.waitForSelector("#bk-list [data-restore]");
  // Ripristina il backup più vecchio ("Uno"): c'è almeno una differenza (la persona aggiunta dopo)
  const rows = await page.$$("#bk-list .bk-row");
  await (await rows[rows.length - 1].$("[data-restore]")).click();
  await page.waitForSelector("#modal[open] .dlg-foot button.primary");
  await page.click("#modal .dlg-foot button.primary"); // Mostra Cosa Cambierà
  await page.waitForSelector("#modal[open] .rs-list");
  console.log("Cosa Cambierà aperta:", await page.textContent("#modal .dlg-foot button.primary"));
  await page.click("#modal .dlg-foot button:not(.primary)"); // Annulla
  await page.waitForTimeout(300);

  // Più tardi: permessi di un utente
  await page.goto(BASE + "#impostazioni/utenti");
  await page.waitForSelector("#u-new");
  await page.click("#u-new");
  await page.waitForSelector('#modal[open] select[name="role"]');
  console.log("pulsante prima:", await page.textContent("#modal .dlg-foot button.primary"));
  await page.selectOption('#modal select[name="role"]', "operatore");
  await page.waitForTimeout(200);
  console.log("pulsante dopo aver scelto il ruolo:", await page.textContent("#modal .dlg-foot button.primary"));
  await page.click("#modal .dlg-foot button:not(.primary)");
  await browser.close();
})();

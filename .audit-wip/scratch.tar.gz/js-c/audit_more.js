// Attività: doppio clic su Carica Altre aggiunge due volte le stesse righe
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";
const j = async (path, method = "GET", body) => (await fetch(BASE + path, {method, headers: {"Content-Type": "application/json"}, body: body && JSON.stringify(body)})).json();

(async () => {
  for (let i = 0; i < 120; i++) await j("api/sites", "POST", {name: `Struttura ${i}`});
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(BASE + "#impostazioni/attivita");
  await page.waitForSelector("#audit tr");
  await page.waitForSelector("#audit-more-box:not([hidden])");
  console.log("righe iniziali:", await page.$$eval("#audit tr", (r) => r.length));
  await page.dblclick("#audit-more");
  await page.waitForTimeout(1500);
  const texts = await page.$$eval("#audit tr", (rows) => rows.map((r) => r.textContent));
  console.log("righe dopo doppio clic:", texts.length, "| doppioni:", texts.length - new Set(texts).size);
  await browser.close();
})();

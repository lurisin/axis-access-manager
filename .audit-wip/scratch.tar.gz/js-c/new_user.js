// Nuovo Utente: il ruolo mostrato non corrisponde ai permessi spuntati, e si salva quello delle spunte
const { chromium } = require("/opt/node22/lib/node_modules/playwright");
const BASE = process.argv[2] || "http://127.0.0.1:8765/";

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
  await page.goto(BASE + "#impostazioni/utenti");
  await page.waitForSelector("#u-new");
  await page.click("#u-new");
  await page.waitForSelector('#modal[open] select[name="role"]');
  const role = await page.$eval('#modal select[name="role"]', (s) => s.options[s.selectedIndex].textContent);
  const perms = await page.$$eval('#modal [name="perm"]:checked', (els) => els.map((e) => e.value));
  console.log("ruolo mostrato:", role, "| permessi spuntati:", perms);
  await page.fill('#modal input[name="username"]', "mario");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(800);
  const users = await (await fetch(BASE + "api/users")).json();
  const mario = users.users.find((u) => u.username === "mario");
  console.log("salvato:", mario.role, mario.perms);
  await browser.close();
})();

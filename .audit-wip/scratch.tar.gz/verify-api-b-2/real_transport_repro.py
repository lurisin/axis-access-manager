"""reload_runtime() durante la sincronizzazione periodica, con il trasporto httpx VERO (httpcore + socket).

Un server HTTP locale (uvicorn in un thread) risponde come un A1210; il metodo indicato in argv[1] tarda 0,5 s.
Mentre _maintenance aspetta quella risposta si chiama reload_runtime (salvataggio di una porta).
"""

import asyncio
import json
import logging
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

import httpx
import uvicorn

os.environ.pop("SUPERVISOR_TOKEN", None)

import app.main as main  # noqa: E402
from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.vapix import A1210Client  # noqa: E402

SLOW = sys.argv[1] if len(sys.argv) > 1 else "pacsaxis:GetCredentialList"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8817
logging.basicConfig(level=logging.WARNING)
entered = threading.Event()
calls: list[str] = []


async def server_app(scope, receive, send):
    if scope["type"] == "lifespan":
        while True:
            msg = await receive()
            if msg["type"] == "lifespan.startup":
                await send({"type": "lifespan.startup.complete"})
            elif msg["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return
    body = b""
    while True:
        msg = await receive()
        body += msg.get("body", b"")
        if not msg.get("more_body"):
            break
    data = json.loads(body or b"{}")
    path = scope["path"]
    method = next(iter(data), "") if path.startswith("/vapix") else data.get("method", "")
    calls.append(method)
    if method == SLOW and not entered.is_set():
        entered.set()
        await asyncio.sleep(0.5)
    if path.endswith("basicdeviceinfo.cgi"):
        out = {"data": {"propertyList": {"ProdNbr": "A1210", "SerialNumber": "X", "Version": "1"}}}
    elif path.endswith(".cgi"):
        out = {"data": {}}
    else:
        out = {
            "pacsaxis:GetCredentialList": {"Credential": []},
            "axudb:GetUserList": {"User": []},
            "pacsaxis:GetAccessPointList": {"AccessPoint": []},
            "pacsaxis:GetAccessProfileList": {"AccessProfile": []},
            "pacsaxis:GetAccessControllerList": {"AccessController": []},
            "tdc:GetDoorInfoList": {"DoorInfo": [{"token": "porta", "Name": "Porta"}]},
            "tdc:GetDoorState": {"DoorState": {"DoorMode": "Locked", "DoorPhysicalState": "Closed"}},
            "axlog:FetchEvents": {"Event": [], "More": False},
            "axsch:GetScheduleList": {"Schedule": []},
        }.get(method, {})
    raw = json.dumps(out).encode()
    await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"application/json")]})
    await send({"type": "http.response.body", "body": raw})


server = uvicorn.Server(uvicorn.Config(server_app, host="127.0.0.1", port=PORT, log_level="error"))
thread = threading.Thread(target=server.run, daemon=True)
thread.start()
while not server.started:
    time.sleep(0.05)


class RealClient(A1210Client):
    def __init__(self, host, username, password, verify_ssl=False):
        super().__init__(host, username, password, verify_ssl)
        # stesso client httpx, ma in chiaro verso il server locale (trasporto reale httpcore/anyio)
        self._client = httpx.AsyncClient(base_url=f"http://127.0.0.1:{PORT}", timeout=10)


main.A1210Client = RealClient


async def scenario():
    settings = parse_options(
        {
            "a1210_host": "127.0.0.1:9",
            "a1210_username": "root",
            "a1210_password": "x",
            "door_token": "porta",
            "access_profile": "",
            "mqtt_topic_prefix": "accessi/x",
        }
    )
    tmp = tempfile.mkdtemp()
    app = main.create_app(
        settings,
        allow_any_client=True,
        db_path=os.path.join(tmp, "a.db"),
        home_assistant=HomeAssistant(token="", snapshot_dir=Path(tmp)),
        scheduled_backups=False,
    )
    try:
        async with app.router.lifespan_context(app):
            await asyncio.wait_for(asyncio.to_thread(entered.wait, 40), 45)
            task = next(t for t in asyncio.all_tasks() if t.get_coro().__name__ == "_maintenance")
            print(f"[{SLOW}] in corso: reload_runtime")
            await main.reload_runtime(app)
            await asyncio.sleep(1.5)
            print("_maintenance terminato:", task.done())
            if task.done():
                print("eccezione:", repr(task.exception()))
            print("last_sync:", {k: app.state.last_sync.get(k) for k in ("ok", "error")})
            calls.clear()
            app.state.sync_wake.set()
            await asyncio.sleep(1.0)
            print("GetCredentialList dopo sync_wake:", calls.count("pacsaxis:GetCredentialList"))
        print("spegnimento pulito")
    except Exception as err:  # noqa: BLE001
        print("spegnimento interrotto da:", repr(err))
    finally:
        server.should_exit = True


asyncio.run(scenario())
thread.join(5)

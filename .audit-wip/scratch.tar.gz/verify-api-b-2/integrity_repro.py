"""Trigger deterministico, senza corse: sul sito del controller la tessera 04BB passa da Bianchi a Rossi.

Nel DB restano Rossi(04AA, token A) e Bianchi(04BB, token B). Sul controller: B rimossa e A ora ha 04BB.
sync_from_controller -> update_card(A, number=04BB) -> UNIQUE(cards.number) -> sqlite3.IntegrityError,
che non e' VapixError/ServiceError: il task _maintenance termina.
"""

import asyncio
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

import app.main as main  # noqa: E402
from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from conftest import FakeController  # noqa: E402


async def scenario():
    controller = FakeController()
    a = controller.add_existing("utente_rossi", "Mario Rossi", "04AA")
    b = controller.add_existing("utente_bianchi", "Luca Bianchi", "04BB")
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "", "mqtt_topic_prefix": "accessi/x"}
    )
    tmp = tempfile.mkdtemp()
    app = main.create_app(
        settings,
        allow_any_client=True,
        controller=controller,
        db_path=os.path.join(tmp, "a.db"),
        home_assistant=HomeAssistant(token="", snapshot_dir=Path(tmp)),
        scheduled_backups=False,
    )
    try:
        async with app.router.lifespan_context(app):
            for _ in range(100):
                if app.state.last_sync.get("ok"):
                    break
                await asyncio.sleep(0.1)
            print("prima sincronizzazione:", app.state.last_sync.get("ok"), app.state.last_sync.get("result"))
            task = next(t for t in asyncio.all_tasks() if t.get_coro().__name__ == "_maintenance")
            # Sul controller: 04BB tolta a Bianchi e data a Rossi
            controller.credentials.pop(b)
            for item in controller.credentials[a]["IdData"]:
                if item["Name"] == "Card":
                    item["Value"] = "04BB"
            app.state.sync_wake.set()  # come quando il controller torna raggiungibile
            await asyncio.sleep(0.5)
            print("_maintenance terminato:", task.done())
            if task.done():
                print("eccezione:", repr(task.exception()))
            print("last_sync.ok:", app.state.last_sync.get("ok"))
            # Da qui niente piu' sincronizzazione: nuova tessera creata dal sito del controller
            controller.add_existing("utente_verdi", "Anna Verdi", "04CC")
            app.state.sync_wake.set()
            await asyncio.sleep(0.5)
            names = [p["name"] for p in app.state.db.list_persons()]
            print("persone nell'app dopo sync_wake:", names)
        print("spegnimento pulito")
    except Exception as err:  # noqa: BLE001
        print("spegnimento interrotto da:", repr(err))


asyncio.run(scenario())

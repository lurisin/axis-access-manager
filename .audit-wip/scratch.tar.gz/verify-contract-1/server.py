"""Server di verifica: app reale su FakeController, porta 9200. POST /__v/offline rende irraggiungibile il controller
per profili/credenziali; POST /__v/reset svuota il controller (simula reset) e risincronizza."""
import os, sys, tempfile, threading, time
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
sys.path[:0] = ["/home/user/axis-access-manager/tests", "/home/user/axis-access-manager/axis_access_manager"]
import httpx, uvicorn
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

controller = FakeController()
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x", "access_profile": "profilo_sempre"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")

async def offline(*a, **k):
    raise VapixError("il controller non risponde (ConnectTimeout)")

async def go_offline():
    for n in ("list_access_profiles", "get_credentials", "get_access_profiles", "list_schedules", "set_credential"):
        setattr(controller, n, offline)
    return {"ok": True}

async def reset():
    controller.factory_reset()
    r = await app.state.service.sync_from_controller()
    return r

app.add_api_route("/__v/offline", go_offline, methods=["POST"])
app.add_api_route("/__v/reset", reset, methods=["POST"])
H = {"X-Remote-User-Name": "luca", "X-Remote-User-Display-Name": "Luca"}

def seed():
    base = "http://127.0.0.1:9200/"
    for _ in range(50):
        try:
            httpx.get(base + "api/me", headers=H); break
        except Exception:
            time.sleep(0.3)
    time.sleep(1.5)
    c = httpx.Client(base_url=base, headers=H, timeout=20)
    doors = {d["token"]: d["id"] for d in c.get("api/door-overview").json()}
    cat = c.post("api/categories", json={"name": "Dipendenti", "rules": [{"target": "door", "target_id": doors["porta"], "schedule": "standard_always"}]}).json()
    for i, name in enumerate(["Anna", "Luca", "Marta", "Paolo"]):
        c.post("api/persons", json={"name": name, "card": f"04a{i}", "category_id": cat["id"]})
    anna = next(p for p in c.get("api/persons").json() if p["name"] == "Anna")
    controller.credentials.pop(anna["cards"][0]["axis_credential_token"])
    c.post("api/sync")
    print("SEEDED", flush=True)

threading.Thread(target=seed, daemon=True).start()
uvicorn.run(app, host="127.0.0.1", port=9200, log_level="warning")

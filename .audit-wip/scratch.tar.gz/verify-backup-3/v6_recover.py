"""backup-6: recover() sposta il database prima di copiare; un errore (o un'interruzione) a metà lascia il posto vuoto."""
import os, signal, sqlite3, subprocess, sys, tempfile, time
from pathlib import Path
from app import backup_copy
from app.db import Database

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="rc_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")
db.add_person("Anna", None)
db.close()
backup_copy.consistent_copy(path, backup_copy.ha_copy_path(path))
data = bytearray(path.read_bytes())
data[4096 * 3: 4096 * 3 + 64] = b"\xff" * 64
path.write_bytes(bytes(data))
print("vivo sano:", backup_copy.is_healthy(path), "copia sana:", backup_copy.is_healthy(backup_copy.ha_copy_path(path)))

# 1) la copia fallisce come con disco pieno (sqlite3 solleva dentro backup())
real_connect = sqlite3.connect
def fake_connect(target, *a, **k):
    if str(target).endswith(".parziale"):
        raise sqlite3.OperationalError("database or disk is full")
    return real_connect(target, *a, **k)
backup_copy.sqlite3.connect = fake_connect
try:
    Database(path, "0.21.7")
    print("primo avvio riuscito")
except sqlite3.Error as e:
    print("primo avvio fallito:", e)
backup_copy.sqlite3.connect = real_connect
print("file:", sorted(p.name for p in work.iterdir()))
db = Database(path, "0.21.7")
print("secondo avvio: recovered=%r persone=%d" % (db.recovered, len(db.list_persons())))

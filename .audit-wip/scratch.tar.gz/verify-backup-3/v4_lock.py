"""backup-4: durata del lock della copia di backup_pre e effetto su una scrittura dell'app."""
import os, subprocess, sys, tempfile, time, json
from pathlib import Path
from app.db import Database

SIZE_MB = int(sys.argv[1])
work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="lk_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")
raw = json.dumps({"Card": "04aabbccdd", "CredentialHolderName": "abc", "IdPointToken": "lettore_x", "Reason": "x" * 300})
with db._lock:
    db._conn.executemany("INSERT INTO events (ts, kind, raw) VALUES ('2026-01-01T00:00:00+00:00','concesso',?)",
                         ((raw,) for _ in range(SIZE_MB * 2000)))
    db._conn.commit()
print(f"db {path.stat().st_size/1e6:.0f} MB")
env = {**os.environ, "AAM_DB_PATH": str(path)}
t_start = time.monotonic()
hook = subprocess.Popen([sys.executable, "/home/user/axis-access-manager/axis_access_manager/app/backup_copy.py"], env=env, stdout=subprocess.PIPE)
time.sleep(0.12)
t0 = time.monotonic()
try:
    db.add_event(ts="2026-10-28T04:45:00+00:00", kind="concesso", card="04aa")
    print(f"scrittura riuscita dopo {time.monotonic()-t0:.2f} s")
except Exception as e:
    print(f"scrittura fallita dopo {time.monotonic()-t0:.2f} s: {e}; in_transaction={db._conn.in_transaction}")
hook.wait()
print(f"hook {time.monotonic()-t_start:.2f} s exit {hook.returncode}")
db.add_audit("admin", "x", "")
print("eventi 04aa nel db dopo commit successivo:", db._conn.execute("select count(*) from events where card='04aa'").fetchone()[0])
import shutil; shutil.rmtree(work)

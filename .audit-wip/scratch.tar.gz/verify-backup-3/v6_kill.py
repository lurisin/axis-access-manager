"""backup-6 variante: add-on fermato (SIGKILL, mancanza di corrente) durante la copia del ripristino."""
import json, os, signal, subprocess, sys, tempfile, time
from pathlib import Path
from app import backup_copy
from app.db import Database

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="kl_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")
db.add_person("Anna", None)
raw = json.dumps({"Reason": "x" * 400})
with db._lock:
    db._conn.executemany("INSERT INTO events (ts, kind, raw) VALUES ('2026-01-01T00:00:00+00:00','concesso',?)", ((raw,) for _ in range(800000)))
    db._conn.commit()
db.close()
backup_copy.consistent_copy(path, backup_copy.ha_copy_path(path))
data = bytearray(path.read_bytes()); data[4096 * 3: 4096 * 3 + 64] = b"\xff" * 64; path.write_bytes(bytes(data))
print(f"db {path.stat().st_size/1e6:.0f} MB; vivo sano: {backup_copy.is_healthy(path)}")
code = f"import sys; sys.path[:0]=['/home/user/axis-access-manager/axis_access_manager']; from app.db import Database; Database({str(path)!r}, '0.21.7')"
p = subprocess.Popen([sys.executable, "-c", code])
deadline = time.monotonic() + 60
while time.monotonic() < deadline:
    if any(work.glob("*.parziale")) and any(work.glob("*_danneggiato_*")):
        break
    time.sleep(0.02)
time.sleep(0.3)
p.send_signal(signal.SIGKILL); p.wait()
print("dopo il kill:", sorted(x.name for x in work.iterdir()))
db = Database(path, "0.21.7")
print("riavvio: recovered=%r persone=%d eventi=%d" % (db.recovered, len(db.list_persons()), db._conn.execute("select count(*) from events").fetchone()[0]))
db.close()
import shutil; shutil.rmtree(work)

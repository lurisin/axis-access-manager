"""backup-3: backup_pre sovrascrive la copia sana con quella di un database rovinato; recover() tace."""
import logging
import sqlite3
import tempfile
from pathlib import Path

from app import backup_copy
from app.db import Database

logging.basicConfig(level=logging.DEBUG)
work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="ov_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")
for i in range(400):
    db.add_person(f"Persona {i} " + "x" * 100, None)
db.close()
import os
os.environ["AAM_DB_PATH"] = str(path)
backup_copy.main()
print("copia sana prima:", backup_copy.is_healthy(backup_copy.ha_copy_path(path)))
data = bytearray(path.read_bytes())
data[4096 * 5 : 4096 * 5 + 64] = b"\xff" * 64
path.write_bytes(bytes(data))
print("vivo sano:", backup_copy.is_healthy(path))
print("exit:", backup_copy.main(), "copia sana dopo:", backup_copy.is_healthy(backup_copy.ha_copy_path(path)))
db = Database(path, "0.21.7")
print("recovered:", repr(db.recovered))
try:
    print("persone:", len(db.list_persons()))
except sqlite3.DatabaseError as e:
    print("errore lettura:", e)

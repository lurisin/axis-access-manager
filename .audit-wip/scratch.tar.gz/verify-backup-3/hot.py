import os, sqlite3, subprocess, sys, tempfile
from pathlib import Path
sys.path[:0] = ['/home/user/axis-access-manager/axis_access_manager']
from app.backup_copy import is_healthy
work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="hj_"))
path = work / "a.db"
c = sqlite3.connect(path); c.execute("create table t(x)"); c.executemany("insert into t values (?)", (("y"*500,) for _ in range(20000))); c.commit(); c.close()
code = f"""
import sqlite3, os
c = sqlite3.connect({str(path)!r}); c.execute('PRAGMA cache_size=10')
c.execute('update t set x = x || "z"')
os._exit(0)
"""
subprocess.run([sys.executable, "-c", code])
print("files:", sorted(p.name for p in work.iterdir()), "journal size:", (work/"a.db-journal").stat().st_size if (work/"a.db-journal").exists() else None)
print("is_healthy (hot journal):", is_healthy(path))
c = sqlite3.connect(path); print("quick_check rw:", c.execute("pragma quick_check").fetchone()[0]); c.close()

"""Verifica: DoorMode "Accessed" ottimistico non corretto dopo un'interruzione del controller verso il broker."""
import asyncio, json, os, tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController
from app import main as m
from app.config import MqttSettings, parse_options
from app.ha import HomeAssistant
from app.service import ServiceError

P = "accessi/x"
DOOR = f"{P}/eventi/Door/State/DoorMode/$source/DoorToken/porta"

def pl(data):
    return json.dumps({"timestamp": 1729800000000, "message": {"data": data}}).encode()

async def main():
    tmp = Path(tempfile.mkdtemp())
    controller = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": P})
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        st = app.state
        await asyncio.wait_for(st.health_ready.wait(), 10)
        mon = st.monitor
        st.mqtt = MqttSettings("broker")
        mon.connected = True
        mon.handle(f"{P}/stato", b"online")
        mon.handle(DOOR, pl({"State": "Locked"}))
        await m._read_door_states(st, force=True)
        print("iniziale:", mon.door_modes, "outages", mon.outages)
        await st.service.open_door(False, "HA", "porta")
        controller.door = "Accessed"
        mon.handle(DOOR, pl({"State": "Accessed"}))  # arriva via MQTT
        print("dopo apertura:", mon.door_modes)
        # Il controller perde il broker durante i 7 s: LWT offline, "Locked" pubblicato mentre era scollegato va perso
        mon.handle(f"{P}/stato", b"offline")
        controller.door = "Locked"
        mon.handle(f"{P}/stato", b"online")
        print("outages", mon.outages, "online", mon.controller_online)
        # giro del controllo di stato
        await m._recover_if_needed(st)
        await m._read_door_states(st)
        print("dopo rilettura:", mon.door_modes, "| controller:", controller.door)
        print("HA state porte/serrature:", st.bridge.state()["porte"], st.bridge.state()["serrature"])
        try:
            await st.service.open_door(False, "Citofono", "porta")
            print("seconda apertura: eseguita")
        except ServiceError as e:
            print("seconda apertura RIFIUTATA:", e)
        # Molti giri del controllo di stato dopo: resta?
        for _ in range(3):
            await m._read_door_states(st)
        print("dopo altri giri:", mon.door_modes)
        # Una tessera: il controller manda Accessed/Locked -> si corregge
        mon.handle(DOOR, pl({"State": "Accessed"})); mon.handle(DOOR, pl({"State": "Locked"}))
        print("dopo tessera:", mon.door_modes)

asyncio.run(main())

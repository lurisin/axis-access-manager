import re, sys, collections
src = open(sys.argv[1], encoding="utf-8").read()
start = src.index("<script>")
js = src[start:]
# strip line comments
js = "\n".join(l for l in js.splitlines() if not l.strip().startswith("//"))
strings = re.findall(r'"((?:[^"\\\n]|\\.)*)"|\'((?:[^\'\\\n]|\\.)*)\'|`((?:[^`\\]|\\.)*)`', js)
text = " ".join("".join(s) for s in strings)
text = re.sub(r"<[^>]+>", " ", text)
text = re.sub(r"\$\{[^}]*\}", " ", text)
words = re.findall(r"[A-Za-zÀ-ÿ']+", text)
c = collections.Counter(w.lower().strip("'") for w in words if len(w) > 3)
for w, n in sorted(c.items()):
    if n <= 2:
        print(n, w)

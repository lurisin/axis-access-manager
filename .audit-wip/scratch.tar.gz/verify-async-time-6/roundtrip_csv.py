import os, tempfile
from pathlib import Path
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
from conftest import FakeController

os.environ.pop("SUPERVISOR_TOKEN", None)
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "x.db")
with TestClient(app) as c:
    r = c.post("/api/persons", json={"name": "Ospite", "card": "04aa", "valid_from": "2026-10-01T08:00", "valid_to": "2026-12-31T23:59"})
    print("create", r.status_code, r.json().get("cards", [{}])[0].get("valid_to") if r.status_code == 200 else r.text)
    c.post("/api/persons", json={"name": "Anna", "card": "04bb"})
    csv = c.get("/api/export/persons.csv").text
    print(csv)
    # Change company only via text editor
    csv2 = csv.replace(";;;", ";;;")  # unchanged
    preview = c.post("/api/import/persons", json={"csv": csv2, "apply": False}).json()
    print(preview)

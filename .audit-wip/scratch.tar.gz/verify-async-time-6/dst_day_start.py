from datetime import datetime, UTC, timedelta, time as dtime
from zoneinfo import ZoneInfo
from app.db import local_day_start
rome = ZoneInfo("Europe/Rome")
def true_start(now, days):
    d = now.astimezone(rome).date() - timedelta(days=days)
    return datetime.combine(d, dtime.min, tzinfo=rome).astimezone(UTC).isoformat(timespec="seconds")
for now, days in [(datetime(2026,10,25,9,0,tzinfo=UTC),0),(datetime(2026,3,29,8,0,tzinfo=UTC),0),(datetime(2026,10,28,9,0,tzinfo=UTC),6),(datetime(2026,10,27,9,0,tzinfo=UTC),0)]:
    print(now, days, "code:", local_day_start(days, now), "true:", true_start(now, days))

"""Percorso solo-UI: unica area Hotel > Reception con il controller, tipologia Hotel Staff (struttura Hotel).
L'utente sceglie 'Nessuna Area' nella Connessione: Hotel Staff perde la porta. Al riavvio il controller torna in Reception."""
import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController  # noqa
from fastapi.testclient import TestClient  # noqa
from app.config import parse_options  # noqa
from app.main import create_app  # noqa

controller = FakeController()
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
def app():
    return create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)

with TestClient(app()) as client:
    hotel = client.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    reception = client.post(f"/api/sites/{hotel}/areas", json={"name": "Reception"}).json()["id"]
    cid = client.post("/api/controllers", json={**CTRL, "area_id": reception}).json()["id"]
    ingresso = client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"}).json()
    r = client.post("/api/categories", json={"name": "Hotel Staff", "rules": [{"target": "site", "target_id": hotel, "schedule": "standard_always"}]})
    token = r.json()["token"]
    print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    r = client.put(f"/api/controllers/{cid}", json={**CTRL, "area_id": 0})
    print("PUT Nessuna Area:", r.status_code, r.json())
    print("area ctrl:", client.app.state.db.get_controller(cid)["area_id"])
    print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
print("--- riavvio ---")
with TestClient(app()) as client:
    print("area ctrl:", client.app.state.db.get_controller(cid)["area_id"], "Reception =", reception)
    print("Hotel Staff apre (subito dopo il riavvio):", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    client.put(f"/api/doors/{ingresso['id']}", json={"door_token": "porta", "name": "Ingresso 2"})
    print("Hotel Staff apre (dopo modifica porta):", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    print("audit:", [(a["user"], a["action"]) for a in client.get("/api/audit").json()][:4])

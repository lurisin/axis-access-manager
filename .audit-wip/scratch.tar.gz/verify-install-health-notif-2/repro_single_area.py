"""Una sola porta: controller in Teatro > Scala; Hotel > Reception senza porte con tipologia Hotel Staff.
Si elimina Teatro: al riavvio il controller finisce nell'unica area rimasta."""
import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController  # noqa
from fastapi.testclient import TestClient  # noqa
from app.config import parse_options  # noqa
from app.main import create_app  # noqa

controller = FakeController()
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
def app():
    return create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)

with TestClient(app()) as client:
    teatro = client.post("/api/sites", json={"name": "Teatro"}).json()["id"]
    scala = client.post(f"/api/sites/{teatro}/areas", json={"name": "Scala"}).json()["id"]
    hotel = client.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    reception = client.post(f"/api/sites/{hotel}/areas", json={"name": "Reception"}).json()["id"]
    cid = client.post("/api/controllers", json={**CTRL, "area_id": scala}).json()["id"]
    ingresso = client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso Teatro"}).json()
    r = client.post("/api/categories", json={"name": "Hotel Staff", "rules": [{"target": "site", "target_id": hotel, "schedule": "standard_always"}]})
    print("categoria:", r.status_code, r.json())
    token = r.json().get("token")
    if token:
        print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    print("DELETE Teatro ->", client.delete(f"/api/sites/{teatro}").json())
    print("area ctrl:", client.app.state.db.get_controller(cid)["area_id"])
    audits_before = len(client.app.state.db.conn.execute("select * from audit").fetchall()) if hasattr(client.app.state.db, "conn") else None
print("--- riavvio ---")
with TestClient(app()) as client:
    print("area ctrl:", client.app.state.db.get_controller(cid)["area_id"], "Reception =", reception)
    client.put(f"/api/doors/{ingresso['id']}", json={"door_token": "porta", "name": "Ingresso Teatro 2"})
    if token:
        print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    act = client.get("/api/audit").json() if client.get("/api/audit").status_code == 200 else None
    print("audit:", str(act)[:600])

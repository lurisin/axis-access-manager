import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController  # noqa
from fastapi.testclient import TestClient  # noqa
from app.config import parse_options  # noqa
from app.main import create_app  # noqa
controller = FakeController()
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
def app():
    return create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)
with TestClient(app()) as client:
    teatro = client.post("/api/sites", json={"name": "Teatro"}).json()["id"]
    scala = client.post(f"/api/sites/{teatro}/areas", json={"name": "Scala"}).json()["id"]
    cid = client.post("/api/controllers", json={**CTRL, "area_id": scala}).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"})
    print("DELETE area Scala:", client.delete(f"/api/areas/{scala}").json())
    print("luoghi:", [(s["name"], [a["name"] for a in s["areas"]]) for s in client.get("/api/locations").json()])
print("--- riavvio ---")
with TestClient(app()) as client:
    print("luoghi:", [(s["name"], [(a["name"], a["controllers"]) for a in s["areas"]]) for s in client.get("/api/locations").json()])
    print("audit:", [(a["user"], a["action"], a["detail"]) for a in client.get("/api/audit").json()][:3])

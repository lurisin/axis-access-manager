"""End to end: HA copy taken, more persons added, writer killed mid small commit -> Database() restart."""
import os, random, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path
from app.backup_copy import consistent_copy, ha_copy_path
from app.db import Database

child = r"""
import sys
from app.db import Database
db = Database(sys.argv[1], "0.21.7")
while True:
    db._conn.execute("INSERT INTO events (ts, kind, raw) VALUES ('2026-10-28T08:00:00+00:00', 'concesso', 'x')")
    db._conn.commit()
"""
for attempt in range(30):
    work = Path(tempfile.mkdtemp()); p = work / "axis_access_manager.db"
    db = Database(p, "0.21.7"); db.add_person("Prima del backup", "a"); db.close()
    consistent_copy(p, ha_copy_path(p))
    db = Database(p, "0.21.7")
    for i in range(10):
        db.add_person(f"Dopo {i}", f"b{i}")
    db.close()
    proc = subprocess.Popen([sys.executable, "-c", child, str(p)])
    time.sleep(0.6 + random.random() * 0.3); proc.send_signal(signal.SIGKILL); proc.wait()
    j = Path(str(p) + "-journal")
    if j.exists() and j.read_bytes()[:8] != b"\0" * 8:
        db = Database(p, "0.21.7")
        print("attempt", attempt, "recovered:", repr(db.recovered))
        print("persons after restart:", len(db.all_persons()), [x["name"] for x in db.all_persons()])
        db.close()
        print("files:", sorted(x.name for x in work.iterdir()))
        break

"""Small commits (one event each, like the app) killed with SIGKILL at random times: how often is the journal hot
and is_healthy() false while a read-write open is fine?"""
import os, random, shutil, signal, sqlite3, subprocess, sys, tempfile, time
from pathlib import Path
from app.backup_copy import is_healthy, consistent_copy, ha_copy_path, recover
from app.db import Database

child = r"""
import sys, sqlite3
from app.db import Database
db = Database(sys.argv[1], "0.21.7")
i = 0
while True:
    db._conn.execute("INSERT INTO events (ts, kind, raw) VALUES ('2026-10-28T08:00:00+00:00', 'concesso', ?)", ("x"*50,))
    db._conn.commit()
    i += 1
"""
base = Path(tempfile.mkdtemp())
seed = base / "seed.db"
db = Database(seed, "0.21.7")
for i in range(20):
    db.add_person(f"P{i}", f"u{i}")
db.close()
trials, hot, unhealthy, rw_ok = 60, 0, 0, 0
errs = set()
for t in range(trials):
    work = base / f"t{t}"; work.mkdir()
    p = work / "axis_access_manager.db"
    shutil.copy(seed, p)
    proc = subprocess.Popen([sys.executable, "-c", child, str(p)], env={**os.environ})
    time.sleep(0.6 + random.random() * 0.3)
    proc.send_signal(signal.SIGKILL); proc.wait()
    j = Path(str(p) + "-journal")
    if j.exists() and j.stat().st_size > 0:
        if j.read_bytes()[:8] != b"\0" * 8:
            hot += 1
            try:
                c = sqlite3.connect(f"file:{p}?mode=ro", uri=True); c.execute("PRAGMA quick_check").fetchone(); c.close()
            except sqlite3.DatabaseError as e:
                errs.add((type(e).__name__, str(e), getattr(e, "sqlite_errorname", "")))
            if not is_healthy(p):
                unhealthy += 1
                probe = work / "probe.db"; shutil.copy(p, probe); shutil.copy(j, str(probe) + "-journal")
                c = sqlite3.connect(probe)
                if c.execute("PRAGMA quick_check").fetchone()[0] == "ok":
                    rw_ok += 1
                c.close()
print(f"trials={trials} hot_journal={hot} is_healthy_false={unhealthy} rw_open_quick_check_ok={rw_ok}")
print("errors:", errs)

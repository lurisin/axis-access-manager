"""Variante: la porta tolta e' l'unica (id riusato). Conta solo l'ordine tipologie -> porte."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-axis-access-manager/a9d7407e-af26-5ce9-9e95-9f7c1abd8eb4/scratchpad/audit/restore")
from harness import make_plant, restore, run


async def main():
    plant, db, controller = make_plant()
    rule = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    category = await plant.rules.save_category(None, {"name": "Pulizie", "rules": [rule]}, "admin")
    backup = await plant.backup()
    db.set_door_area(plant.scala, plant.area)
    area_rule = {"target": "area", "target_id": plant.area, "schedule": "standard_always"}
    await plant.rules.save_category(category["id"], {"name": "Pulizie", "rules": [area_rule]}, "admin")
    plant.db.delete_door(plant.scala)
    for attempt in (1, 2):
        items, result = await restore(plant, backup["id"], ["tipologie", "porte"])
        print(attempt, "failed:", result["failed"], "| porte:", [(d["id"], d["door_token"]) for d in db.list_doors()],
              "| regole:", db.category_rules(category["id"]))

run(main())

"""Linea supervisionata attivata dall'app (update_input) dopo il backup: cosa mostra l'anteprima completa."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-axis-access-manager/a9d7407e-af26-5ce9-9e95-9f7c1abd8eb4/scratchpad/audit/restore")
from harness import make_plant, restore, run, show

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    await plant.access.create_person("Anna", "04aa", "admin")
    await plant.programming.update_input("REX", {"role": "rex", "door": "porta", "contact": "no"}, "admin")
    print("prima:", controller.io_assignments.get("REX"))
    backup = await plant.backup()
    await plant.programming.update_input("REX", {"role": "rex", "door": "porta", "contact": "no", "supervised": True}, "admin")
    print("dopo:", controller.io_assignments.get("REX"))
    items, result = await restore(plant, backup["id"], FULL, keys=[])
    show([i for i in items if i["key"].startswith(("prog-io", "prog-lettore"))])

run(main())

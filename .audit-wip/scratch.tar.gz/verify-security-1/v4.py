import asyncio, os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
import httpx
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
from app.ha import HomeAssistant, CORE_API
from conftest import FakeController

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "t.db", scheduled_backups=False)
with TestClient(app) as client:
    admin = {"X-Remote-User-Name": "rising"}
    client.get("/api/me", headers=admin)
    client.post("/api/users", json={"username": "inst", "perms": ["impianti"]}, headers=admin)
    inst = {"X-Remote-User-Name": "inst"}
    ctrls = app.state.db.list_controllers()
    cid = ctrls[0]["id"]
    r = client.put(f"/api/controllers/{cid}/camera", json={"camera": "camera.x/../../error_log"}, headers=inst)
    print("PUT camera ->", r.status_code, r.text[:100])
    cam = app.state.controller_camera
    print("controller_camera:", cam)
    seen = []
    def handler(req):
        seen.append(str(req.url)); return httpx.Response(200, content=b"LOG CONTENT")
    ha = HomeAssistant(token="t", snapshot_dir=tmp / "snap")
    ha._client = httpx.AsyncClient(base_url=CORE_API, transport=httpx.MockTransport(handler))
    print(asyncio.run(ha.save_snapshot(cam, "1_x")), seen, (tmp / "snap" / "1_x.jpg").read_bytes())

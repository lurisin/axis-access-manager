import os, tempfile
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "api.db")
with TestClient(app) as c:
    # come fa l'interfaccia: fromLocalInput -> ISO UTC
    r = c.post("/api/persons", json={"name": "Ospite Uno", "card": "04aa", "valid_from": "2026-10-28T07:00:00.000Z", "valid_to": "2026-11-30T17:00:00.000Z"})
    print("create", r.status_code)
    c.post("/api/persons", json={"name": "Anna", "card": "04bb"})
    # persona creata via import con solo data (end_of_day -> 23:59:59)
    r = c.post("/api/import/persons", json={"csv": "nome;tessera;valida_al\nLuca;04cc;31/12/2026", "apply": True})
    print("import Luca", r.json()["riepilogo"])
    csv_text = c.get("/api/export/persons.csv").text
    print(repr(csv_text))
    r = c.post("/api/import/persons", json={"csv": csv_text, "apply": False})
    import json; print(json.dumps(r.json(), ensure_ascii=False, indent=1))

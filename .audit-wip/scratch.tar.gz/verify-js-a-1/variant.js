const { chromium } = require("playwright");
(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  let groupsCalls = 0;
  page.on("request", (r) => { if (r.url().includes("api/groups")) groupsCalls++; });
  const api = async (method, path, data) => { const r = await page.request.fetch(base + path, { method, data }); return [r.status(), await r.json()]; };
  await ctl({ delay: {}, offline: [] });
  const [, cats] = await api("GET", "/api/categories");
  console.log("tipologie nel DB:", cats.map((c) => `${c.id}:${c.name}`));
  // Prima visita con controller offline
  await ctl({ offline: ["list_access_profiles"] });
  await page.goto(base + "/#persone");
  await page.waitForSelector("#p-new");
  await page.waitForTimeout(500);
  console.log("offline: chips=", JSON.stringify(await page.$eval("#p-cats", (e) => e.textContent.trim())), "groupsCalls", groupsCalls);
  // Controller torna; si naviga altrove e di nuovo su Persone
  await ctl({ offline: [] });
  await page.goto(base + "/#registro"); await page.waitForTimeout(500);
  await page.goto(base + "/#persone"); await page.waitForSelector("#p-new"); await page.waitForTimeout(500);
  console.log("online di nuovo: chips=", JSON.stringify(await page.$eval("#p-cats", (e) => e.textContent.trim())), "groupsCalls", groupsCalls);
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=category]");
  console.log("Nuova Persona opzioni:", await page.$$eval("#modal [name=category] option", (o) => o.map((x) => `${x.value}:${x.textContent}`)));
  await page.fill("#modal [name=name]", "Nuovo Senza");
  await page.fill("#modal [name=card]", "04CC00DD");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(1500);
  const [, persons] = await api("GET", "/api/persons");
  const np = persons.find((p) => p.name === "Nuovo Senza");
  console.log("persona creata:", np && np.category_id, np && np.cards[0].access_profile);
  // Apertura scheda di una persona con tessera quando online: si autoripara?
  await page.goto(base + "/#persone/1"); await page.waitForSelector("#sheet[open] [data-edit-access]"); await page.waitForTimeout(500);
  console.log("scheda persona 1 dopo ritorno online:", await page.$eval("#sheet dl.props dd", (e) => e.textContent.trim()), "groupsCalls", groupsCalls);
  await browser.close();
})();

import os, tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
from conftest import FakeController

settings = parse_options({"a1210_host": "a1210.local","door_token": "porta","access_profile": "profilo_sempre","mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db")
with TestClient(app) as c:
    db = app.state.db
    start = datetime(2025, 11, 1, tzinfo=UTC)
    rows = []
    N = 50100
    for i in range(N):
        ts = (start + timedelta(minutes=10 * i)).isoformat(timespec="seconds")
        rows.append((ts, "concesso", "04aa", None, "Anna", "", "mqtt", "", "porta", 0, ""))
    with db._lock:
        db._conn.executemany("INSERT INTO events (ts, kind, card, person_id, person_name, detail, source, raw, door, recovered, ref) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
        db._conn.commit()
    r = c.get("/api/export/events.csv")
    lines = r.text.strip().splitlines()
    print("status", r.status_code, "lines incl header", len(lines), "inserted", N)
    print("header", lines[0][:200])
    print("last", lines[-1][:200])
    print("oldest inserted", rows[0][0])
    print("headers", {k: v for k, v in r.headers.items() if k.lower().startswith(("x-", "content-disp"))})

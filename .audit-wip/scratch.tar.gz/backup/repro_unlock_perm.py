"""Un utente con il solo permesso Backup (eliminare è solo degli amministratori) sblocca un backup bloccato
dall'amministratore e, creando un backup, lo fa eliminare dalla ritenzione."""

import json
import os
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

SCRATCH = Path(__file__).parent
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="perm_"))
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=work / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
mario = {"X-Remote-User-Name": "mario"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    client.post("/api/users", json={"username": "mario", "perms": ["backup"]}, headers=admin)
    first = client.post("/api/backups", json={"name": "base"}, headers=admin).json()
    root = work / "backup"
    base = json.loads((root / f"{first['id']}.json").read_text())
    now = datetime.now(tz=UTC).replace(hour=2, minute=0, second=0, microsecond=0)
    # Storico realistico: un notturno al giorno negli ultimi 80 giorni (stesse parti, nessuna modifica)
    for days in range(1, 81):
        at = now - timedelta(days=days)
        ident = at.astimezone().strftime("%Y%m%d-%H%M%S")
        manifest = {**base, "id": ident, "created_at": at.isoformat(timespec="seconds"), "kind": "notturno", "name": ""}
        if days == 75:
            # Quello di 75 giorni fa l'amministratore lo ha chiamato e bloccato
            manifest |= {"kind": "manuale", "name": "Impianto collaudato", "locked": True}
            kept = manifest
        (root / f"{ident}.json").write_text(json.dumps(manifest))
    (root / f"{first['id']}.json").unlink()
    listing = client.get("/api/backups", headers=admin).json()["backups"]
    print("backup:", len(listing), "| motivi del bloccato:", next(b["keep"] for b in listing if b["name"] == "Impianto collaudato"))
    print("mario elimina:", client.delete(f"/api/backups/{kept['id']}", headers=mario).status_code)
    print("mario sblocca:", client.put(f"/api/backups/{kept['id']}/lock", json={"locked": False}, headers=mario).status_code)
    client.post("/api/backups", json={"name": "di mario"}, headers=mario)
    names = [b["name"] for b in client.get("/api/backups", headers=admin).json()["backups"]]
    print("dopo il backup di mario:", len(names), "backup | bloccato ancora presente:", "Impianto collaudato" in names)
    print([a["action"] + ": " + a["detail"] for a in client.get("/api/audit", headers=admin).json()[:4]])

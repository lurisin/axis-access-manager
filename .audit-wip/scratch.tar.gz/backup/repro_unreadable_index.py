"""Indice di backup illeggibile: la verifica lo conta tra i rovinati, ma non compare nell'elenco e l'API non lo
elimina, quindi il guasto "Backup Rovinati" non si può più togliere dall'app."""

import os
import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

SCRATCH = Path(__file__).parent
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="idx_"))
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
     "mqtt_topic_prefix": "accessi/x"}
)
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=work / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    client.post("/api/backups", json={"name": "buono"}, headers=admin)
    # Indice rimasto a 0 byte dopo una mancanza di corrente (scritto e rinominato, dati mai sul disco)
    root = work / "backup"
    broken = sorted(root.glob("*.json"))[0].stem.split("-")[0] + "-000001"
    (root / f"{broken}.json").write_bytes(b"")
    verify = client.post("/api/backups/verify", headers=admin).json()
    print("verifica:", verify["ok"], verify["damaged"], verify["errors"])
    listing = client.get("/api/backups", headers=admin).json()
    print("backup nell'elenco:", [b["id"] for b in listing["backups"]])
    answer = client.delete(f"/api/backups/{broken}", headers=admin)
    print("DELETE dell'indice rovinato:", answer.status_code, answer.json())
    notes = client.get("/api/notifications", headers=admin)
    print("notifiche:", notes.status_code, [n.get("title") for n in (notes.json().get("items") if notes.status_code == 200 else [])])

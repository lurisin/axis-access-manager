"""Una parte rovinata (per esempio lunga 0 byte dopo una mancanza di corrente) viene riusata da ogni backup nuovo
con lo stesso contenuto; e con l'ultimo backup illeggibile ogni controllo orario crea un backup "Primo backup"."""

import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.backup import BackupError
from app.config import parse_options
from app.db import Database

SCRATCH = Path(__file__).parent


async def main():
    work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="part_"))
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
         "mqtt_topic_prefix": "accessi/x"}
    )
    db = Database(work / "test.db")
    plant = Plant(db, FakeController(), settings, work / "backup")
    key = f"controller:{plant.controller_id}"

    first = await plant.backup()
    await plant.access.create_person("Anna", "04aa", "admin")
    second = await plant.backup()
    print("parti del controller uguali tra primo e secondo:", first["parts"][key]["hash"] == second["parts"][key]["hash"])
    part = plant.backups.store.parts / f"{second['parts'][key]['hash']}.json.gz"
    # Mancanza di corrente subito dopo la scrittura: file creato e rinominato, dati mai arrivati sul disco
    part.write_bytes(b"")

    now = datetime.now(tz=UTC)
    made = []
    for hour in range(1, 6):
        m = await plant.backups.run_scheduled(plant.clients, now=now + timedelta(minutes=61 * hour))
        made.append(m and (m["kind"], m["summary"], m["parts"][key]["hash"] == second["parts"][key]["hash"]))
    print("controlli orari senza nessuna modifica ->", made)
    print("dimensione della parte del controller dopo 5 backup nuovi:", part.stat().st_size, "byte")
    result = plant.backups.verify()
    print("verifica:", result["ok"], "backup rovinati:", result["damaged"], "su", result["backups"])

    # Il flusso di /api/backups/{id}/restore: prima il backup "Prima del Ripristino", poi lo si rilegge
    before = await plant.backups.create("prima_ripristino", "Prima del ripristino", "admin", plant.clients)
    try:
        plant.backups.load(before["id"])
        print("load(prima_ripristino) riuscito")
    except BackupError as err:
        print("restore interrotto:", err)


asyncio.run(main())

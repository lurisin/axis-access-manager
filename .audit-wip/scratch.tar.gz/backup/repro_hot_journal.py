"""recover(): un journal "caldo" lasciato da un processo ucciso a metà scrittura viene scambiato per database
danneggiato e il database vivo viene sostituito con la copia (vecchia) del backup di Home Assistant."""

import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

from app.backup_copy import consistent_copy, ha_copy_path, is_healthy, recover

SCRATCH = Path(__file__).parent
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="hot_"))
db = work / "axis_access_manager.db"

conn = sqlite3.connect(db)
conn.execute("CREATE TABLE persons (id INTEGER PRIMARY KEY, name TEXT)")
conn.execute("INSERT INTO persons (name) VALUES ('Mario (prima del backup HA)')")
conn.commit()
conn.close()

# backup_pre di Home Assistant: copia coerente in copia_backup/
consistent_copy(db, ha_copy_path(db))

# Lavoro fatto dopo il backup di HA, regolarmente salvato (commit)
conn = sqlite3.connect(db)
conn.execute("INSERT INTO persons (name) VALUES ('Anna (creata dopo il backup HA, commit fatto)')")
conn.commit()
conn.close()

# L'add-on viene ucciso (OOM, SIGKILL, mancanza di corrente) mentre una scrittura è in corso
subprocess.run(
    [
        sys.executable,
        "-c",
        "import sqlite3, os\n"
        f"c = sqlite3.connect({str(db)!r})\n"
        "c.execute('PRAGMA cache_size = 10')\n"
        "c.executemany('INSERT INTO persons (name) VALUES (?)', [('riga %d ' % i + 'x' * 200,) for i in range(20000)])\n"
        "os._exit(9)\n",
    ],
    check=False,
)
journal = Path(str(db) + "-journal")
print("journal rimasto:", journal.exists(), journal.stat().st_size if journal.exists() else 0, "byte")

# Cosa farebbe SQLite da solo all'apertura normale (su una copia dei file): rollback del journal, dati intatti
probe = work / "probe"
probe.mkdir()
shutil.copy(db, probe / db.name)
shutil.copy(journal, probe / journal.name)
pc = sqlite3.connect(probe / db.name)
print("apertura normale di SQLite:", pc.execute("PRAGMA quick_check").fetchone()[0], [r[0] for r in pc.execute("SELECT name FROM persons")])
pc.close()

print("is_healthy(db) =", is_healthy(db))
message = recover(db)
print("recover():", message)
names = [r[0] for r in sqlite3.connect(db).execute("SELECT name FROM persons")]
print("persone nel database usato dall'app dopo recover():", names)
moved = next(work.glob("axis_access_manager_danneggiato_*.db"))
print("journal del file spostato ancora presente:", Path(str(moved) + "-journal").exists(), "| journal originale:", journal.exists())

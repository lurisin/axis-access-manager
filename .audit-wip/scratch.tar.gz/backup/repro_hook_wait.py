"""consistent_copy() con un writer che tiene il lock esclusivo per 45 s: errore dopo 30 s o attesa infinita?"""
import sqlite3
import tempfile
import threading
import time
from pathlib import Path

from app.backup_copy import consistent_copy

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="wait_"))
path = work / "axis_access_manager.db"
c = sqlite3.connect(path)
c.execute("CREATE TABLE t (x)")
c.commit()
c.close()
holder = sqlite3.connect(path, isolation_level=None)
holder.execute("BEGIN EXCLUSIVE")
holder.execute("INSERT INTO t VALUES (1)")
release_at = time.monotonic() + 45
result = {}


def copy():
    t0 = time.monotonic()
    try:
        consistent_copy(path, work / "copia" / path.name)
        result["ok"] = time.monotonic() - t0
    except Exception as err:  # noqa: BLE001
        result["err"] = (time.monotonic() - t0, repr(err))


th = threading.Thread(target=copy)
th.start()
while time.monotonic() < release_at and th.is_alive():
    time.sleep(1)
print("dopo 45 s la copia è ancora in attesa:", th.is_alive(), result)
holder.execute("COMMIT")
th.join()
print("dopo il rilascio:", result)

"""Il backup "Prima del Ripristino" fa girare la ritenzione, che può eliminare proprio il backup da cui si ripristina."""

import asyncio
import json
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.backup import BackupError
from app.config import parse_options
from app.db import Database

SCRATCH = Path(__file__).parent


async def main():
    work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="src_"))
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
         "mqtt_topic_prefix": "accessi/x"}
    )
    plant = Plant(Database(work / "t.db"), FakeController(), settings, work / "backup")
    first = await plant.backup()
    root = plant.backups.store.root
    base = json.loads((root / f"{first['id']}.json").read_text())
    (root / f"{first['id']}.json").unlink()
    now = datetime.now(tz=UTC).replace(second=0, microsecond=0)
    # Giornata di lavori: un backup ogni 10 minuti (prima delle modifiche e automatici), stesse parti
    ids = []
    for n in range(30, 0, -1):
        at = now - timedelta(minutes=10 * n)
        ident = at.astimezone().strftime("%Y%m%d-%H%M%S")
        (root / f"{ident}.json").write_text(json.dumps({**base, "id": ident, "created_at": at.isoformat(), "name": f"n{n}"}))
        ids.append(ident)
    listing = plant.backups.listing()["backups"]
    chosen = listing[23]
    print("backup scelto per il ripristino:", chosen["name"], chosen["keep"])
    # main.restore_backup: load del backup scelto, poi il backup "Prima del Ripristino"
    plant.backups.load(chosen["id"])
    await plant.backups.create("prima_ripristino", "Prima del ripristino", "admin", plant.clients)
    try:
        plant.backups.load(chosen["id"])
        print("il backup scelto c'è ancora")
    except BackupError as err:
        print("dopo il ripristino il backup scelto:", err)


asyncio.run(main())

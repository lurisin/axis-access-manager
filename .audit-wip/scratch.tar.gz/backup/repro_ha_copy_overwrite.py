"""backup_pre: la copia per il backup di HA sovrascrive l'ultima copia sana anche se il database è già rovinato;
all'avvio recover() non ha più niente da cui ripartire e lo fa in silenzio."""

import sqlite3
import tempfile
from pathlib import Path

from app import backup_copy
from app.db import Database

SCRATCH = Path(__file__).parent
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="hacopy_"))
path = work / "axis_access_manager.db"
backup_copy.DB_PATH = path

db = Database(path, "0.21.7")
for i in range(400):
    db.add_person(f"Persona {i} " + "x" * 100, None)
db.close()
backup_copy.main()  # backup di HA di ieri: copia sana
print("copia di ieri sana:", backup_copy.is_healthy(backup_copy.ha_copy_path(path)))

# Settore rovinato nel database mentre l'add-on gira (pagine della tabella persons)
data = bytearray(path.read_bytes())
data[4096 * 5 : 4096 * 5 + 64] = b"\xff" * 64
path.write_bytes(bytes(data))
print("database vivo sano:", backup_copy.is_healthy(path))

code = backup_copy.main()  # backup di HA di oggi
print("backup_pre exit code:", code, "| copia ora sana:", backup_copy.is_healthy(backup_copy.ha_copy_path(path)))

db = Database(path, "0.21.7")  # riavvio dell'add-on
print("Database.recovered:", repr(db.recovered))
try:
    print("persone:", len(db.list_persons()))
except sqlite3.DatabaseError as err:
    print("lettura delle persone:", err)

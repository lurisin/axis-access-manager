"""next_run() con il cambio dell'ora (Europe/Rome, 25/10/2026 alle 03:00 CEST si torna alle 02:00 CET)."""

import os
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

os.environ["TZ"] = "Europe/Rome"
time.tzset()

from app.backup import BackupService  # noqa: E402
from app.db import Database  # noqa: E402

SCRATCH = Path(__file__).parent
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="dst_"))
service = BackupService(Database(work / "t.db"), work / "backup", "0.21.7")


def show(label, now, items):
    due = service.next_run(now, items)
    at = datetime.fromisoformat(due["at"])
    print(f"{label}: ora locale {now.astimezone():%d/%m %H:%M %Z} -> prossimo {due['kind']} {at.astimezone():%d/%m %H:%M %Z}"
          f"{'  (GIA SCADUTO: parte subito)' if at <= now else ''}")


# Notturno di sabato 24/10 alle 03:00 CEST = 01:00 UTC; giornata tranquilla, controllo orario alle 00:30 UTC
nightly = {"id": "20261024-030000", "created_at": "2026-10-24T01:00:00+00:00"}
service.checked_at = datetime(2026, 10, 25, 0, 30, tzinfo=UTC)
show("prima del cambio", datetime(2026, 10, 25, 0, 59, 30, tzinfo=UTC), [nightly])
show("dopo il cambio  ", datetime(2026, 10, 25, 1, 0, 30, tzinfo=UTC), [nightly])
# Il backup creato alle 02:00 CET e il notturno vero alle 03:00 CET
extra = {"id": "20261025-020030", "created_at": "2026-10-25T01:00:30+00:00"}
show("dopo il backup in più", datetime(2026, 10, 25, 1, 1, tzinfo=UTC), [extra, nightly])
# Primavera: 29/03/2027, alle 02:00 CET si passa alle 03:00 CEST
spring = {"id": "20270327-030000", "created_at": "2027-03-27T02:00:00+00:00"}
service.checked_at = datetime(2027, 3, 28, 0, 30, tzinfo=UTC)
show("primavera prima ", datetime(2027, 3, 28, 0, 59, tzinfo=UTC), [spring])
show("primavera dopo  ", datetime(2027, 3, 28, 1, 0, 30, tzinfo=UTC), [spring])
print(timedelta(0))

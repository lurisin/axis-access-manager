"""backup_pre: src.backup(dst) copia tutto in un passo tenendo il lock condiviso sul database dell'app per tutta la
durata della copia. Il commit dell'app (timeout di serie 5 s) aspetta, bloccando il loop, e oltre i 5 s fallisce."""

import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from app.db import Database

SCRATCH = Path(__file__).parent
SIZE_MB = int(sys.argv[1]) if len(sys.argv) > 1 else 300
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="lock_"))
path = work / "axis_access_manager.db"

db = Database(path, "0.21.7")
row = "x" * 900  # un evento con il suo messaggio MQTT originale
with db._lock:
    db._conn.executemany(
        "INSERT INTO events (ts, kind, raw) VALUES ('2026-01-01T00:00:00+00:00', 'concesso', ?)",
        ((row,) for _ in range(SIZE_MB * 1100)),
    )
    db._conn.commit()
print(f"database: {path.stat().st_size / 1e6:.0f} MB")

env = {**os.environ, "AAM_DB_PATH": str(path)}
start = time.monotonic()
hook = subprocess.Popen([sys.executable, "axis_access_manager/app/backup_copy.py"], env=env, stdout=subprocess.PIPE)
time.sleep(0.3)  # la copia è partita
t0 = time.monotonic()
try:
    db.add_event(ts="2026-10-28T10:00:00+00:00", kind="concesso", card="04aa", detail="durante il backup HA")
    print(f"scrittura dell'app riuscita dopo {time.monotonic() - t0:.1f} s (loop fermo per tutto questo tempo)")
except Exception as err:  # noqa: BLE001
    print(f"scrittura dell'app fallita dopo {time.monotonic() - t0:.1f} s: {type(err).__name__}: {err}")
hook.wait()
print(f"copia del hook durata {time.monotonic() - start:.1f} s, exit {hook.returncode}")

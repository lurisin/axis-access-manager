"""Una sezione del controller non letta (errore temporaneo) finisce nel riassunto come porte tolte."""
import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.config import parse_options
from app.db import Database
from app.vapix import VapixError


async def main():
    work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="pr_"))
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                              "mqtt_topic_prefix": "accessi/x"})
    controller = FakeController()
    plant = Plant(Database(work / "t.db"), controller, settings, work / "backup")
    await plant.backup()
    real = controller.list_doors

    async def busy():
        raise VapixError("il controller ha risposto con errore 503")

    controller.list_doors = busy
    now = datetime.now(tz=UTC)
    made = await plant.backups.run_scheduled(plant.clients, now=now + timedelta(minutes=61))
    print("controllo orario con una lettura fallita:", made and (made["summary"], made["errors"]))
    controller.list_doors = real
    made = await plant.backups.run_scheduled(plant.clients, now=now + timedelta(minutes=123))
    print("controllo successivo:", made and made["summary"])


asyncio.run(main())

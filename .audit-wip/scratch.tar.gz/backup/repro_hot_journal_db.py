"""Effetto all'avvio dell'add-on: Database() dopo un'interruzione con journal caldo torna alla copia del backup HA."""

import subprocess
import sys
import tempfile
from pathlib import Path

from app import backup_copy
from app.db import Database

SCRATCH = Path(__file__).parent
work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="hotdb_"))
path = work / "axis_access_manager.db"

db = Database(path, "0.21.7")
db.add_person("Mario (prima del backup HA)", None)
db.close()
# Home Assistant fa un backup: backup_pre prepara la copia coerente
backup_copy.DB_PATH = path
backup_copy.main()

db = Database(path, "0.21.7")
anna = db.add_person("Anna (dopo il backup HA)", None)
db.add_audit("admin", "persona creata", "Anna")
db.close()

# Interruzione brusca durante una scrittura grossa (pulizia del registro, importazione...) che ha già
# riversato pagine nel file: il journal è "caldo" e SQLite all'apertura lo annullerebbe da solo
child = (
    "import sqlite3, os\n"
    f"c = sqlite3.connect({str(path)!r})\n"
    "c.execute('PRAGMA cache_size = 10')\n"
    "c.executemany(\"INSERT INTO audit (ts, user, action, detail) VALUES ('2026-10-28', 's', 'x', ?)\", "
    "[('y' * 300,) for _ in range(5000)])\n"
    "os._exit(9)\n"
)
subprocess.run([sys.executable, "-c", child], check=False)
print("journal caldo:", Path(str(path) + "-journal").exists())

db = Database(path, "0.21.7")
print("Database.recovered:", db.recovered)
print("persone dopo il riavvio:", [p["name"] for p in db.list_persons()])
print("file nella cartella:", sorted(p.name for p in work.iterdir()))

"""Testo privacy delle impostazioni (retentionSpan in index.html) contro la ritenzione vera di retention()."""
from datetime import UTC, datetime, timedelta

from app.backup import DEFAULT_POLICY, retention

now = datetime(2026, 10, 28, 2, 0, tzinfo=UTC)
# Un notturno al giorno (Solo Notturno, o impianto senza modifiche) per 60 giorni
items = [{"id": f"b{d}", "created_at": (now - timedelta(days=d)).isoformat(), "locked": False} for d in range(60)]
# Consiglio di DOCS.md per una scadenza più breve: abbassare giorni, settimane, mesi e anni
policy = DEFAULT_POLICY | {"keep_daily": 7, "keep_weekly": 0, "keep_monthly": 0, "keep_yearly": 0}
reasons = retention(items, policy)
kept = [int(m["id"][1:]) for m in items if reasons[m["id"]]]
print("index.html: 'al massimo 7 giorni' | retention() tiene backup fino a", max(kept), "giorni fa")

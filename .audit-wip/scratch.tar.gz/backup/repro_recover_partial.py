"""recover(): sposta il database prima di aver copiato la copia sana; se la copia fallisce, al riavvio dopo
il database non c'è più e l'app ne crea uno vuoto."""
import sqlite3
import tempfile
from pathlib import Path

from app import backup_copy
from app.db import Database

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="rec_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")
db.add_person("Anna", None)
db.close()
backup_copy.consistent_copy(path, backup_copy.ha_copy_path(path))
data = bytearray(path.read_bytes())
data[4096 * 3 : 4096 * 3 + 64] = b"\xff" * 64  # database rovinato
path.write_bytes(bytes(data))

real = backup_copy.consistent_copy


def full_disk(source, target):
    raise sqlite3.OperationalError("database or disk is full")


backup_copy.consistent_copy = full_disk
try:
    Database(path, "0.21.7")
except sqlite3.Error as err:
    print("primo avvio:", err)
backup_copy.consistent_copy = real
db = Database(path, "0.21.7")
print("secondo avvio: recovered=%r, persone=%d" % (db.recovered, len(db.list_persons())))
print(sorted(p.name for p in work.iterdir()))

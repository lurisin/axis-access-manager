"""Confronto con lo Stato Attuale con il controller che non risponde: tutto risulta tolto."""

import asyncio
import tempfile
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.config import parse_options
from app.db import Database

SCRATCH = Path(__file__).parent


async def main():
    work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="cmp_"))
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
         "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    plant = Plant(Database(work / "t.db"), controller, settings, work / "backup")
    made = await plant.backup()
    controller.offline = True
    diff = await plant.backups.compare(made["id"], "attuale", plant.clients, f"controller:{plant.controller_id}")
    for group in diff["groups"]:
        print(group["title"], "| nota:", group["note"])
        for section in group["sections"]:
            print("  ", section["title"], "tolti:", [i["label"] for i in section["removed"]])
    print("chiavi della risposta:", sorted(diff))


asyncio.run(main())

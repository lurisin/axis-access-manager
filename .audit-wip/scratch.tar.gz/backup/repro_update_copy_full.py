"""Copia prima dell'aggiornamento senza spazio: Database() solleva e l'add-on non parte (a ogni riavvio)."""
import sqlite3
import tempfile
from pathlib import Path

from app import backup_copy, db as dbmod
from app.db import Database

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="upd_"))
path = work / "axis_access_manager.db"
Database(path, "0.21.6").close()


def full_disk(source, target):
    raise sqlite3.OperationalError("database or disk is full")


backup_copy.consistent_copy = full_disk
dbmod.update_copy.__globals__["consistent_copy"] = full_disk
for attempt in (1, 2):
    try:
        Database(path, "0.21.7")
        print("avvio", attempt, "riuscito")
    except sqlite3.Error as err:
        print("avvio", attempt, "fallito:", type(err).__name__, err)

"""Scrittura dell'app mentre un lettore (come la copia di backup_pre) tiene il lock condiviso oltre 5 s."""
import sqlite3
import tempfile
import threading
import time
from pathlib import Path

from app.db import Database

work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="lw_"))
path = work / "axis_access_manager.db"
db = Database(path, "0.21.7")


def reader():
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, isolation_level=None)
    conn.execute("BEGIN")
    conn.execute("SELECT count(*) FROM events").fetchone()  # lock condiviso, come backup_step(-1)
    time.sleep(7)
    conn.execute("COMMIT")
    conn.close()


threading.Thread(target=reader).start()
time.sleep(0.3)
t0 = time.monotonic()
try:
    db.add_event(ts="2026-10-28T10:00:00+00:00", kind="concesso", card="04aa")
except sqlite3.OperationalError as err:
    print(f"add_event fallito dopo {time.monotonic() - t0:.1f} s: {err}; transazione aperta: {db._conn.in_transaction}")
time.sleep(7)
other = sqlite3.connect(path, timeout=0.5)
try:
    other.execute("SELECT count(*) FROM events").fetchone()
except sqlite3.OperationalError as err:
    print("altri lettori dopo il commit fallito:", err)
db.add_audit("admin", "altro", "")
print("dopo il commit successivo:", other.execute("SELECT count(*) FROM events").fetchone()[0])

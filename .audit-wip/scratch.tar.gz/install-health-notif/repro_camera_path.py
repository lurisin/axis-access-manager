"""La telecamera della porta è controllata solo con startswith("camera."): "camera.x/../../error_log" fa leggere
all'add-on, con il token del Supervisor, il log degli errori di Home Assistant (solo per amministratori di HA),
che finisce come "istantanea" scaricabile dal registro."""

import os
import tempfile
import time
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

import httpx  # noqa: E402
from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import CORE_API, HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

requested = []


def handler(request: httpx.Request) -> httpx.Response:
    requested.append(str(request.url))
    if request.url.path == "/core/api/error_log":
        return httpx.Response(200, content=b"2026-10-28 ERROR ... token=SEGRETO ...")
    return httpx.Response(404)


ha = HomeAssistant(token="supervisor-token", snapshot_dir=Path(tempfile.mkdtemp()))
ha._client = httpx.AsyncClient(
    base_url=CORE_API, headers={"Authorization": "Bearer supervisor-token"}, transport=httpx.MockTransport(handler)
)
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
app = create_app(
    settings, allow_any_client=True, controller=FakeController(), db_path=Path(tempfile.mkdtemp()) / "c.db", home_assistant=ha
)
with TestClient(app) as client:
    door = client.app.state.db.list_doors()[0]
    body = {"door_token": "porta", "name": door["name"], "snapshot_camera": "camera.x/../../error_log"}
    print("PUT porta con la 'telecamera' ->", client.put(f"/api/doors/{door['id']}", json=body).status_code)
    # Un passaggio negato qualsiasi alla porta: l'add-on scatta l'"istantanea"
    import asyncio

    async def deny():
        row = client.app.state.service.log_event(ts="2026-10-28T08:00:00+00:00", kind="negato", card="0A1B", door="porta")
        await asyncio.sleep(0.3)
        return row

    row = client.portal.call(deny)
    print("richieste a Home Assistant:", requested)
    r = client.get(f"/api/events/{row['id']}/snapshot")
    print("GET istantanea ->", r.status_code, r.headers.get("content-type"), r.content[:60])

import asyncio, os, tempfile, time
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from app import main
from app.config import parse_options
main.HEALTH_INTERVAL = 3
main.SYNC_RETRY = 2
main.SYNC_INTERVAL = 3
T0 = time.monotonic()
controller = FakeController()
controller.add_existing("utente_mario", "Mario Rossi", "0A0001")
orig_list = controller.list_credentials
orig_info = controller.device_info
async def list_credentials():
    print(f"{time.monotonic()-T0:5.1f} sync: list_credentials serial={controller.serial} offline={controller.offline} paused={bool(app.state.controller.paused)}")
    if controller.offline:
        raise main.VapixError("offline")
    return await orig_list()
async def device_info():
    print(f"{time.monotonic()-T0:5.1f} health: device_info serial={controller.serial} offline={controller.offline}")
    return await orig_info()
controller.list_credentials = list_credentials
controller.device_info = device_info
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
app = main.create_app(settings, allow_any_client=True, controller=controller, db_path=Path(tempfile.mkdtemp()) / "r.db")
async def scenario():
    async with app.router.lifespan_context(app):
        await asyncio.sleep(4)
        controller.offline = True
        print(f"{time.monotonic()-T0:5.1f} --- offline")
        await asyncio.sleep(5.3)
        controller.serial, controller.fingerprint = "NUOVO", "CC:DD"
        controller.credentials, controller.users = {}, {}
        controller.offline = False
        print(f"{time.monotonic()-T0:5.1f} --- nuovo apparecchio online")
        await asyncio.sleep(5)
        print("mancanti:", len(app.state.db.missing_cards()))
asyncio.run(scenario())

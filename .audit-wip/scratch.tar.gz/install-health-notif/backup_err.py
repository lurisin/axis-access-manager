import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
controller = FakeController()
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
with TestClient(create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"})
    print("prima:", client.app.state.backups.last_error())
    print(client.delete(f"/api/controllers/{cid}").json())
    print("dopo DELETE:", client.app.state.backups.last_error())
    print([ (i["title"], i["text"]) for i in client.get("/api/notifications").json()["items"]])

import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
controller = FakeController()
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
with TestClient(create_app(settings, allow_any_client=True, controller=controller, db_path=Path(tempfile.mkdtemp()) / "x.db")) as client:
    controller.offline = True
    for _ in range(2):
        client.portal.call(client.app.state.health.check_all)
    items = client.get("/api/notifications").json()["items"]
    print("notifiche:", [(i["title"], i["seen"]) for i in items])
    client.post("/api/notifications/seen", json={"ids": [i["id"] for i in items]})
    s = client.get("/api/summary").json()
    n = client.get("/api/notifications").json()
    print("barra in alto, guasti:", [f["title"] for f in s["faults"]], "| campanella:", s["notifications"])
    print("pagina Notifiche, Da Gestire (non viste):", [i["title"] for i in n["items"] if not i["seen"]])
    print("controller ancora irraggiungibile:", client.app.state.health.states[1].unreachable)

"""Un utente senza il permesso Registro (non vede gli allarmi) può segnarli come visti per tutti, senza traccia."""

import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=Path(tempfile.mkdtemp()) / "s.db")
ADMIN = {"X-Remote-User-Name": "admin"}
GUARD = {"X-Remote-User-Name": "portiere"}

with TestClient(app) as client:
    client.get("/api/me", headers=ADMIN)  # il primo utente diventa amministratore
    # Il portiere: solo "stato" (ruolo Solo Stato, quello predefinito per i nuovi utenti)
    print("me portiere:", client.get("/api/me", headers=GUARD).json()["perms"])
    db = client.app.state.db
    event_id = db.add_event(ts=datetime.now(tz=UTC).isoformat(), kind="allarme", door="porta", detail="porta forzata")

    admin_view = client.get("/api/summary", headers=ADMIN).json()
    print("admin, barra in alto:", admin_view["alarms"], "campanella:", admin_view["notifications"])
    guard_items = client.get("/api/notifications", headers=GUARD).json()["items"]
    print("portiere vede:", [i["type"] for i in guard_items])

    audit_before = len(db.list_audit(limit=1000))
    # Il portiere manda l'id (indovinabile: g<primo evento>-<ultimo evento>)
    r = client.post("/api/notifications/seen", headers=GUARD, json={"ids": [f"g{event_id}-{event_id}"]})
    print("POST seen dal portiere:", r.status_code, r.json())
    admin_view = client.get("/api/summary", headers=ADMIN).json()
    print("admin, barra in alto dopo:", admin_view["alarms"], "campanella:", admin_view["notifications"])
    print("righe nuove nel Registro Attività:", len(db.list_audit(limit=1000)) - audit_before)

"""Un gruppo di allarmi già visto torna "da gestire" quando il suo primo evento esce dalla finestra delle 24 ore."""

import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from app.db import Database
from app.notifications import NotificationService

db = Database(Path(tempfile.mkdtemp()) / "n.db")
service = NotificationService(db)
base = datetime(2026, 10, 27, 10, 0, tzinfo=UTC)
# Porta forzata tre volte di fila ieri alle 10:00, 10:02, 10:04
for minutes in (0, 2, 4):
    db.add_event(ts=(base + timedelta(minutes=minutes)).isoformat(), kind="allarme", door="porta", detail="porta forzata")


def collect(now):
    return service.collect(
        mqtt_configured=True,
        mqtt_connected=True,
        controller_configured=True,
        controller_online=True,
        sync={"ok": True},
        door_names={"porta": "Ingresso"},
        controllers=[{"id": 1, "name": "A1210", "unreachable": False}],
        now=now,
    )


now = base + timedelta(minutes=10)
items = collect(now)
print("ieri 10:10:", [(i["id"], i["title"]) for i in items])
service.mark_seen([i["id"] for i in items], items)
listing = service.listing(items)
print("  dopo Presa Visione: da gestire =", listing["open"])

for later in (timedelta(hours=24, minutes=1), timedelta(hours=24, minutes=3)):
    items = collect(base + later)
    listing = service.listing(items)
    alarms = [i for i in listing["items"] if i["type"] == "door_alarm" and not i["seen"]]
    print(
        f"oggi {(base + later):%H:%M}: da gestire = {listing['open']}, Allarmi nella barra in alto =",
        [(i["id"], i["title"], i["seen"]) for i in alarms],
    )

"""Eliminare il controller cancella le porte (CASCADE) senza check_place_unused; gli id delle porte si riusano
e le righe di accesso delle tipologie finiscono su porte diverse."""

import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

controller = FakeController()
# Un punto di accesso con lettore anche per la cantina, per poter dare le porte alle tipologie
controller.access_points.append(
    {
        "token": "ap-cantina",
        "Entity": "porta2",
        "EntityType": "axtdc:Door",
        "Name": "Cantina",
        "Enabled": True,
        "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
        "Attribute": [{"Name": "Direction", "Value": "in"}],
    }
)
controller.access_controllers["Axis-x AccessController"]["AccessPoint"].append("ap-cantina")

tmp = Path(tempfile.mkdtemp())
app = create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=tmp / "x.db")
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}

with TestClient(app) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    ingresso = client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"}).json()["id"]
    cantina = client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina"}).json()["id"]
    print("porte:", {"Ingresso": ingresso, "Cantina": cantina})
    # Tipologia Pulizie: solo la Cantina
    r = client.post(
        "/api/categories",
        json={"name": "Pulizie", "rules": [{"target": "door", "target_id": cantina, "schedule": "standard_always"}]},
    )
    print("tipologia:", r.status_code, r.json())
    token = r.json()["token"]
    print("profilo Pulizie prima:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])

    # La Cantina non si può eliminare: è usata dalla tipologia
    print("DELETE porta Cantina ->", client.delete(f"/api/doors/{cantina}").status_code)

    # ...ma eliminando il controller sparisce lo stesso (CASCADE), senza nessun controllo
    print("DELETE controller ->", client.delete(f"/api/controllers/{cid}").json())
    print("righe della tipologia rimaste:", client.app.state.db.all_category_rules())

    # Si rimette il controller (stesso apparecchio) e le porte, in un altro ordine
    cid2 = client.post("/api/controllers", json=CTRL).json()["id"]
    a = client.post(f"/api/controllers/{cid2}/doors", json={"door_token": "porta2", "name": "Cantina"}).json()["id"]
    b = client.post(f"/api/controllers/{cid2}/doors", json={"door_token": "porta", "name": "Ingresso"}).json()["id"]
    print("controller di nuovo con id", cid2, "porte:", {"Cantina": a, "Ingresso": b})
    print("profilo Pulizie dopo:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    cats = client.get("/api/categories").json()
    print("tipologia vista dall'app:", [(c["name"], c.get("rules")) for c in cats])

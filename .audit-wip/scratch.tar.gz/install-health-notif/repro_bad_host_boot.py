"""Un indirizzo che passa la validazione di controller_fields ma che httpx rifiuta (IPv6 senza parentesi, porta
con un refuso) viene salvato; reload_runtime fallisce a metà e al riavvio l'add-on non parte più."""

import os
import tempfile
import traceback
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "127.0.0.1:9", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}

# Nessun controller iniettato: il client vero, come in produzione
app = create_app(parse_options({}), allow_any_client=True, db_path=db_path)
with TestClient(app, raise_server_exceptions=False) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    r = client.post("/api/controllers/test", json={**CTRL, "host": "fe80::1"})
    print("Prova Collegamento con fe80::1 ->", r.status_code, r.text[:80])
    r = client.put(f"/api/controllers/{cid}", json={**CTRL, "host": "fe80::1", "password": ""})
    print("Salva con host fe80::1 ->", r.status_code, r.text[:80])
    print("host nel database:", client.app.state.db.get_controller(cid)["host"])
    print("summary dopo:", client.get("/api/summary").status_code)

print("--- riavvio dell'add-on ---")
try:
    with TestClient(create_app(parse_options({}), allow_any_client=True, db_path=db_path)) as client:
        print("avviato:", client.get("/api/summary").status_code)
except Exception as err:  # noqa: BLE001
    print("AVVIO FALLITO:", type(err).__name__, err)
    traceback.print_exc()

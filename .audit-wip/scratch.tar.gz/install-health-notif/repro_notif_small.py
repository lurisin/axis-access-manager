import tempfile
from pathlib import Path

from app.db import Database
from app.notifications import NotificationService

db = Database(Path(tempfile.mkdtemp()) / "n.db")
service = NotificationService(db)


def collect(controllers, controller_online=True, mqtt_connected=True):
    return service.collect(
        mqtt_configured=True,
        mqtt_connected=mqtt_connected,
        controller_configured=True,
        controller_online=controller_online,
        sync={"ok": True},
        door_names={"porta": "Ingresso"},
        controllers=controllers,
    )


# 1) Controller che si riavvia: manda "offline" su MQTT e non risponde al primo controllo (online False, 1 errore)
rebooting = {"id": 1, "name": "A1210", "online": False, "failures": 1, "unreachable": False, "error": "non risponde"}
print("1)", [(i["title"], i["text"]) for i in collect([rebooting], controller_online=False)])

# 2) Presa visione dell'orologio di Home Assistant, poi riavvio dell'add-on: il primo controllo non è ancora finito
synced = {"id": 1, "name": "A1210", "unreachable": False, "clock_fault": "home_assistant", "clock_offset": 96.0}
items = collect([synced])
service.mark_seen([i["id"] for i in items], items)
print("2) prima del riavvio, da gestire:", service.listing(items)["open"])
# subito dopo l'avvio: stato del controller ancora vuoto (setdefault in check(), nessuna lettura dell'ora)
fresh = {"id": 1, "name": "A1210", "online": None, "unreachable": False, "clock_fault": ""}
print("   richiesta durante il primo controllo, da gestire:", service.listing(collect([fresh]))["open"])
print("   dopo il primo controllo, da gestire:", service.listing(collect([synced]))["open"])

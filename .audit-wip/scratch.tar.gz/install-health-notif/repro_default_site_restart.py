"""Controller lasciato senza area (struttura eliminata o "Nessuna Area"): al riavvio ensure_default_site() lo sposta
nell'area di una sua porta (o nell'unica area), e le tipologie di quella struttura prendono le sue porte."""

import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402

controller = FakeController()
controller.access_points.append(
    {
        "token": "ap-cantina",
        "Entity": "porta2",
        "EntityType": "axtdc:Door",
        "Name": "Cantina",
        "Enabled": True,
        "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
        "Attribute": [{"Name": "Direction", "Value": "in"}],
    }
)
controller.access_controllers["Axis-x AccessController"]["AccessPoint"].append("ap-cantina")
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}


def app():
    return create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)


with TestClient(app()) as client:
    teatro = client.post("/api/sites", json={"name": "Teatro"}).json()["id"]
    scala = client.post(f"/api/sites/{teatro}/areas", json={"name": "Scala"}).json()["id"]
    hotel = client.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    reception = client.post(f"/api/sites/{hotel}/areas", json={"name": "Reception"}).json()["id"]
    cid = client.post("/api/controllers", json={**CTRL, "area_id": scala}).json()["id"]
    ingresso = client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso Teatro"}).json()
    cantina = client.post(
        f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina", "area_id": reception}
    ).json()
    r = client.post(
        "/api/categories",
        json={"name": "Hotel Staff", "rules": [{"target": "site", "target_id": hotel, "schedule": "standard_always"}]},
    ).json()
    token = r["token"]
    print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])
    # Il Teatro chiude: si elimina la struttura. La pagina dice "1 controller resterà senza area"
    print("DELETE Teatro ->", client.delete(f"/api/sites/{teatro}").json())
    print("area del controller:", client.app.state.db.get_controller(cid)["area_id"])
    print("luoghi:", [(s["name"], [(a["name"], a["doors"]) for a in s["areas"]]) for s in client.get("/api/locations").json()])

print("--- riavvio dell'add-on ---")
with TestClient(app()) as client:
    print("area del controller:", client.app.state.db.get_controller(cid)["area_id"], "(Reception =", reception, ")")
    print("luoghi:", [(s["name"], [(a["name"], a["doors"]) for a in s["areas"]]) for s in client.get("/api/locations").json()])
    # Una modifica qualsiasi alle porte (qui: rinomina) aggiorna i profili delle tipologie
    client.put(f"/api/doors/{ingresso['id']}", json={"door_token": "porta", "name": "Ingresso Teatro (chiuso)"})
    print("Hotel Staff apre:", [p["AccessPoint"] for p in controller.profiles[token]["AccessPolicy"]])

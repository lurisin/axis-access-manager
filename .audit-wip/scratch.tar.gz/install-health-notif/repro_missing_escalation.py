"""Tessere non presenti: dopo la presa visione di 1 tessera mancante, il reset del controller (tutte sparite, guasto
critico) tiene lo stesso id e resta "vista": non torna in Da Gestire né sulla campanella."""

import tempfile
from pathlib import Path

from app.db import Database
from app.main import _missing_summary
from app.notifications import NotificationService

db = Database(Path(tempfile.mkdtemp()) / "m.db")
service = NotificationService(db)
cards = []
for i in range(40):
    pid = db.add_person(f"Persona {i}", f"utente_{i}")
    db.add_card(pid, f"0A{i:04X}", f"cred-{i}", True, {"access_profile": "p", "valid_from": "", "valid_to": ""})
cards = [c["id"] for c in db.all_cards()]


def collect():
    return service.collect(
        mqtt_configured=True,
        mqtt_connected=True,
        controller_configured=True,
        controller_online=True,
        sync={"ok": True},
        door_names={},
        controllers=[{"id": 1, "name": "A1210", "unreachable": False}],
        missing=_missing_summary(db),
    )


# Una tessera tolta dal sito del controller: guasto medio, l'amministratore prende visione
db.mark_cards_missing(cards[:1], "2026-10-27T10:00:00+00:00")
items = collect()
print("prima:", [(i["id"], i["severity"], i["text"]) for i in items])
service.mark_seen([i["id"] for i in items], items)

# Il giorno dopo il controller viene resettato: spariscono tutte le 40 tessere
db.mark_cards_missing(cards, "2026-10-28T09:00:00+00:00")
listing = service.listing(collect())
print("dopo il reset:", [(i["id"], i["severity"], i["seen"], i["text"]) for i in listing["items"]])
print("campanella (da gestire):", listing["open"])

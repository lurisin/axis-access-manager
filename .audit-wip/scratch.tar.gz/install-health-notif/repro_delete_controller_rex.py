"""Rimuovi Controller cancella anche gli ingressi dell'app (CASCADE); il controller tiene pulsante e profilo.
Rimesso il controller, al riavvio repair_rex_profile toglie il profilo "Uscite e Citofono": il pulsante non apre."""

import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402
from app.programming import is_rex_profile  # noqa: E402

controller = FakeController()
db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}


def app():
    return create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=db_path)


def rex():
    return [(p["Name"], [a["AccessPoint"] for a in p["AccessPolicy"]]) for p in controller.profiles.values() if is_rex_profile(p)]


with TestClient(app()) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"})
    body = {"name": "Pulsante Portineria", "role": "rex", "door": "porta"}
    print("pulsante:", client.put("/api/programming/inputs/REX", json=body).status_code)
    print("profilo pulsanti sul controller:", rex())
    # "Rimuovi Controller": la finestra dice che sul controller non cambia niente
    print("DELETE controller ->", client.delete(f"/api/controllers/{cid}").json())
    print("profilo pulsanti sul controller:", rex())
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    client.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta", "name": "Ingresso"})
    print("controller rimesso; ingressi nell'app:", client.app.state.db.controller_inputs(cid))

print("--- riavvio dell'add-on (aggiornamento) ---")
with TestClient(app()) as client:
    import time

    time.sleep(1)
    print("profilo pulsanti sul controller:", rex())
    print("chiamate:", [c for c in controller.calls if "profile" in c[0]][-3:])
    prog = client.get("/api/programming").json()
    print("avviso pulsanti senza permesso:", prog["rex_missing"])
    items = client.get("/api/notifications").json()["items"]
    print("notifiche:", [i["title"] for i in items])
    print("attività:", [(a["action"], a["detail"]) for a in client.app.state.db.list_audit(limit=5)])

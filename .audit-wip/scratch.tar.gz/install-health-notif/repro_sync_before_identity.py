"""Controller sostituito durante un'interruzione: il nuovo tentativo di sincronizzazione (ogni SYNC_RETRY) può
rileggere le tessere dal nuovo apparecchio prima che il controllo di stato si accorga del cambio e sospenda."""

import asyncio
import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402

from app import main  # noqa: E402
from app.config import parse_options  # noqa: E402

# Tempi accorciati: controllo ogni 3 s, nuovo tentativo di sincronizzazione ogni 2 s (in produzione 30 s e 60 s)
main.HEALTH_INTERVAL = 3
main.SYNC_RETRY = 2
main.SYNC_INTERVAL = 3

controller = FakeController()
controller.add_existing("utente_mario", "Mario Rossi", "0A0001")
reads = []
original = controller.list_credentials


async def list_credentials():
    reads.append((controller.serial, app.state.controller.paused or "-"))
    return await original()


controller.list_credentials = list_credentials
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
app = main.create_app(settings, allow_any_client=True, controller=controller, db_path=Path(tempfile.mkdtemp()) / "r.db")


async def scenario():
    async with app.router.lifespan_context(app):
        await asyncio.sleep(4)
        print("persone all'inizio:", [p["name"] for p in app.state.db.list_persons()])
        # Il controller si spegne: lo si sostituisce con uno nuovo (vuoto, altro numero di serie)
        controller.offline = True
        controller.list_credentials = None  # non usato finché è spento

        async def offline_list():
            reads.append((controller.serial, app.state.controller.paused or "-"))
            raise main.VapixError("il controller non risponde (ConnectTimeout)")

        controller.list_credentials = offline_list
        await asyncio.sleep(7)
        controller.serial, controller.fingerprint = "NUOVO", "CC:DD"
        controller.credentials, controller.users = {}, {}
        controller.offline = False
        controller.list_credentials = list_credentials
        await asyncio.sleep(7)
        print("letture delle tessere (serie, sospensione):", reads)
        missing = app.state.db.missing_cards()
        print("tessere segnate non presenti:", [(c["number"], c["missing_since"]) for c in missing])
        print("sospese ora:", bool(app.state.controller.paused))


asyncio.run(scenario())

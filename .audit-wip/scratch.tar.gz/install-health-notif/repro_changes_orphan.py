import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
controller = FakeController()
CTRL = {"name": "A1210", "host": "10.0.0.5", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
with TestClient(create_app(parse_options({}), allow_any_client=True, controller=controller, db_path=Path(tempfile.mkdtemp()) / "x.db")) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    client.put("/api/programming/doors/porta", json={"name": "Portone", "access_time": 9})
    client.delete(f"/api/controllers/{cid}")
    cid2 = client.post("/api/controllers", json={**CTRL, "name": "Altro A1210", "host": "10.0.0.9"}).json()["id"]
    print("nuovo controller id:", cid2, "storico:", [(c["summary"], c["user"]) for c in client.get("/api/programming").json()["changes"]])

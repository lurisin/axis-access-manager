import os, tempfile, asyncio
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
import aiomqtt
from app.config import parse_options
from app.ha import HomeAssistant
from app.main import create_app

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    body = {k: door[k] for k in ("name","door_token","ha_buttons","snapshot_camera","snapshot_on_granted","intercom_name","intercom_relay","intercom_open_door","intercom_mqtt_prefix","area_id")}
    r1 = client.put(f"/api/doors/{door['id']}", json={**body, "name": "Cancello", "intercom_name": "Ingresso", "intercom_relay": 1, "intercom_open_door": True}, headers=admin)
    r2 = client.post("/api/controllers/1/doors", json={"door_token": "porta2", "name": "Portone", "intercom_name": "Ingresso", "intercom_relay": 2, "intercom_open_door": True}, headers=admin)
    print("salvataggi:", r1.status_code, r2.status_code)
    st = app.state
    print("bridge:", [(i.door["name"], i.settings.relay, i.call_topic) for i in st.intercoms])
    mon = st.monitor
    def send(topic, payload):
        async def go():
            mon._dispatch_extra(aiomqtt.Topic(topic), payload.encode(), False)
        client.portal.call(go)
    send("hmd/sensor/Ingresso/Call-state/state", "ringing")
    send("hmd/switch/Ingresso/Door-1-relay/attributes", '{"unlock_type":"CENTER_PLATFORM"}')
    send("hmd/switch/Ingresso/Door-1-relay/state", "ON")
    send("hmd/sensor/Ingresso/Call-state/state", "idle")
    evs = [(e.get("door"), e["kind"], e["detail"], e.get("source")) for e in st.db.list_events() if e["kind"] in ("citofono","apertura_remota")]
    for e in evs: print(e)
    print("call_state:", [(i.door["name"], i.call_state) for i in st.intercoms])

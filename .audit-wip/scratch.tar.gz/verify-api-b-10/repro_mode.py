import asyncio, os, tempfile
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app, _read_door_states
from conftest import FakeController

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    st = app.state
    print("mqtt:", st.mqtt)
    import time
    for _ in range(50):
        if st.health_ready.is_set(): break
        time.sleep(0.1)
    print("doors:", [d["door_token"] for d in st.installation.doors()])
    print("mode dopo avvio:", st.monitor.door_modes, "/api door mode:", [d.get("mode") for d in c.get("/api/doors").json()] if c.get("/api/doors").status_code==200 else c.get("/api/doors").status_code)
    ctrl.door = "Unlocked"
    # simula altri giri del controllo di stato e una lettura forzata
    c.portal.call(_read_door_states, st)
    c.portal.call(lambda: _read_door_states(st, force=True))
    print("controller ora:", ctrl.door, "app mostra:", st.monitor.door_modes)

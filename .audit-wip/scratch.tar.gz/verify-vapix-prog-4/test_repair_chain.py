import time

from fastapi.testclient import TestClient

from app.main import create_app
from app.programming import ProgrammingService
from app.rules_service import RulesService
from app.vapix import VapixError


def test_repair_chain(settings, controller, tmp_path, monkeypatch):
    monkeypatch.delenv("SUPERVISOR_TOKEN", raising=False)
    calls = []

    async def boom(self):
        calls.append("repair_group_schedules")
        raise VapixError("timeout simulato")

    async def rex(self, user="sistema"):
        calls.append("repair_rex_profile")
        return 0

    monkeypatch.setattr(RulesService, "repair_group_schedules", boom)
    monkeypatch.setattr(ProgrammingService, "repair_rex_profile", rex)
    app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp_path / "m.db")
    with TestClient(app) as client:
        app.state.health_ready.set()
        for _ in range(50):
            if calls:
                break
            time.sleep(0.1)
        time.sleep(0.3)
        sync = client.get("/api/status").json()["sync"]
        print("\nchiamate:", calls)
        print("last_sync:", sync)
        # secondo giro
        app.state.sync_wake.set()
        time.sleep(1.0)
        print("chiamate dopo il secondo giro:", calls)
        print("last_sync dopo il secondo giro:", client.get("/api/status").json()["sync"])

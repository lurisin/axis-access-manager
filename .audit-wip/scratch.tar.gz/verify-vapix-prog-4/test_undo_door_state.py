import time

from fastapi.testclient import TestClient

from app.main import create_app


def test_undo_door_state(settings, controller, tmp_path, monkeypatch):
    monkeypatch.delenv("SUPERVISOR_TOKEN", raising=False)
    app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp_path / "u.db")
    with TestClient(app) as client:
        for _ in range(50):
            if app.state.health_ready.is_set():
                break
            time.sleep(0.1)
        st = app.state
        print("\nmqtt:", bool(st.mqtt), "primary:", bool(st.installation.primary), "doors:", st.installation.doors())
        mon = st.monitor
        mon.connected, mon.controller_online = True, True
        r = client.put("/api/programming/inputs/DPS", json={"name": "", "role": "door_monitor", "door": "porta", "contact": "no"})
        print("programma sensore:", r.status_code, "door_physical:", dict(mon.door_physical))
        # Tolgo il sensore: il controller ora risponde Unknown
        controller.door_physical = "Unknown"
        r = client.put("/api/programming/inputs/DPS", json={"name": "", "role": "", "contact": "no"})
        print("tolgo sensore:", r.status_code, "door_physical:", dict(mon.door_physical))
        changes = client.get("/api/programming").json()["changes"]
        last = changes[0]
        print("ultima modifica:", last["id"], last["summary"])
        # Annullo: sul controller il sensore torna, la porta è chiusa
        controller.door_physical = "Closed"
        r = client.post(f"/api/programming/changes/{last['id']}/undo")
        print("annulla:", r.status_code, r.json(), "door_physical:", dict(mon.door_physical))
        from app.main import _read_door_states
        import asyncio
        # giro del controllo di stato (senza force)
        client.portal.call(_read_door_states, st)
        print("dopo il giro di controllo:", dict(mon.door_physical))

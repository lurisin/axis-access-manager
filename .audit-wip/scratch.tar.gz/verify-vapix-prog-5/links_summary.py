"""Riepilogo di set_links con token come quelli dell'A1210 (Axis-<serie>:<numero>)."""
import asyncio, tempfile
from pathlib import Path
from conftest import FakeController
from app.db import Database
from app.programming import ProgrammingService

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = FakeController()
    print("lettori:", await c.list_idpoints())
    ap = c.access_points[0]
    out = {"token": "Axis-b8a44fe6a074:1550808050.595140000", "Entity": "porta", "EntityType": "axtdc:Door",
           "Name": "Uscita", "Enabled": True, "IdPointDevice": [],
           "Attribute": [{"Name": "Direction", "Value": "out"}]}
    ap["IdPointDevice"] = [{"IdPoint": "lettore-1", "DeviceUUID": "uuid-a1210"}]
    c.access_points.append(out)
    s = ProgrammingService(db, c, 1, asyncio.Lock())
    await s.set_links([{"reader": "lettore-1", "door": "porta", "direction": "out"}], "admin")
    for ch in db.list_controller_changes(1):
        print("storico:", ch["summary"])

asyncio.run(main())

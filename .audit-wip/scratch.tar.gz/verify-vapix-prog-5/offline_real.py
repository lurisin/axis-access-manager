"""Controller che accetta la connessione TCP ma non risponde (appeso): tempo reale di ProgrammingService.read()."""
import asyncio, tempfile, time
from pathlib import Path
from app.db import Database
from app.programming import ProgrammingService
from app.vapix import A1210Client, ControllerGuard

conns = 0
async def blackhole(reader, writer):
    global conns
    conns += 1
    await asyncio.sleep(3600)

async def main():
    server = await asyncio.start_server(blackhole, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    client = ControllerGuard(A1210Client(f"127.0.0.1:{port}", "u", "p"))
    service = ProgrammingService(db, client, cid, asyncio.Lock())
    t = time.monotonic()
    data = await service.read()
    print(f"read() durata {time.monotonic()-t:.1f} s, connessioni {conns}, errori {len(data['errors'])}")
    for e in data["errors"]:
        print(" ", e)
    server.close()

asyncio.run(main())

import re, httpx
from app.config import normalize_host
from app.vapix import A1210Client
for raw in ["fe80::1","2001:db8::10","192.168.1.50:44e","192.168.1.50:","192.168.1.50:99999","192.168.1.50:443:5","[fe80::1","fe80::1]","192.168.1.50.","a1210:8o43","192.168.1.50::443","192.168.1.5O","https://[2001:db8::10]/","192.168.1.50:-1","1.2.3.4:0"]:
    host = normalize_host(raw)
    ok = len(host) <= 253 and re.match(r"^[A-Za-z0-9.\-:\[\]]+$", host)
    try:
        A1210Client(host,"u","p"); res="ok"
    except Exception as e:
        res=f"{type(e).__name__}: {e}"
    print(repr(raw), "regex", bool(ok), "->", res)

import os, tempfile, json, logging
from pathlib import Path
logging.basicConfig(level=logging.WARNING)
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

controller = FakeController()
controller.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Attribute": [{"Name": "Direction", "Value": "in"}]})
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as c:
    inst = c.get("/api/installation").json()
    doors = inst["controllers"][0]["doors"]
    print("doors:", [(d["id"], d["door_token"], d["name"], d.get("area_id")) for d in doors])
    site = c.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    rooms = c.post(f"/api/sites/{site}/areas", json={"name": "Camere"}).json()["id"]
    tech = c.post(f"/api/sites/{site}/areas", json={"name": "Locali Tecnici"}).json()["id"]
    cid = inst["controllers"][0]["id"]
    print("add cantina:", c.post(f"/api/controllers/{cid}/doors", json={"door_token": "porta2", "name": "Cantina"}).status_code)
    doors = c.get("/api/installation").json()["controllers"][0]["doors"]
    cantina = next(d for d in doors if d["door_token"] == "porta2")
    scala = next(d for d in doors if d["door_token"] == "porta")
    body = {k: cantina[k] for k in ("door_token", "name") } | {"area_id": tech}
    print("move cantina to tech:", c.put(f"/api/doors/{cantina['id']}", json=body).status_code)
    body2 = {k: scala[k] for k in ("door_token", "name") } | {"area_id": rooms}
    print("move scala to rooms:", c.put(f"/api/doors/{scala['id']}", json=body2).status_code)
    cat = c.post("/api/categories", json={"name": "Pulizie", "rules": [{"target": "area", "target_id": tech, "schedule": "standard_always"}]})
    print("category:", cat.status_code, cat.json())
    tok = cat.json()["token"]
    print("before:", [p["AccessPoint"] for p in controller.profiles[tok]["AccessPolicy"]])
    body = {k: cantina[k] for k in ("door_token", "name") } | {"area_id": rooms}
    r = c.put(f"/api/doors/{cantina['id']}", json=body)
    print("move cantina to rooms:", r.status_code, r.json())
    print("after:", [p["AccessPoint"] for p in controller.profiles[tok]["AccessPolicy"]])
    print("categories list:", json.dumps(c.get("/api/categories").json()[0], ensure_ascii=False)[:600])
    d = c.get(f"/api/doors/{cantina['id']}").json()
    print("door detail categories:", d.get("categories"))

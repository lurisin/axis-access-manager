import asyncio, os, tempfile, time
from datetime import UTC, datetime
from pathlib import Path
os.environ["TZ"] = "Europe/Rome"; time.tzset()
from app.backup import BackupService
from app.db import Database
work = Path(tempfile.mkdtemp(dir=Path(__file__).parent, prefix="dst_"))
s = BackupService(Database(work / "t.db"), work / "backup", "0.21.7")
items = [{"id": "20261024-030000", "created_at": "2026-10-24T01:00:00+00:00"}]
s.store.list = lambda: items
calls = []
async def fake_create(kind, name, user, clients, skip_unchanged=False, offline=None):
    calls.append((kind, skip_unchanged))
    m = {"id": "x", "created_at": now.isoformat(), "kind": kind}
    items.insert(0, m); return m
s.create = fake_create
s.checked_at = datetime(2026, 10, 25, 0, 30, tzinfo=UTC)
for now in [datetime(2026,10,25,0,59,tzinfo=UTC), datetime(2026,10,25,1,0,30,tzinfo=UTC), datetime(2026,10,25,1,1,30,tzinfo=UTC), datetime(2026,10,25,2,0,30,tzinfo=UTC)]:
    asyncio.run(s.run_scheduled({}, now=now))
    print(now.astimezone().strftime("%H:%M %Z"), calls[-1] if calls else None, len(calls))

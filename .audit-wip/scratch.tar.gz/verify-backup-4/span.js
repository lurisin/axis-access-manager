const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

function retentionSpan(p) {
  const rule = [[p.keep_yearly, "anno", "anni"], [p.keep_monthly, "mese", "mesi"], [p.keep_weekly, "settimana", "settimane"], [p.keep_daily, "giorno", "giorni"]].find(([n]) => n);
  return rule ? plural(rule[0], rule[1], rule[2]) : `gli ultimi ${p.keep_last} backup`;
}

console.log(retentionSpan({keep_last:24,keep_daily:7,keep_weekly:0,keep_monthly:0,keep_yearly:0}))

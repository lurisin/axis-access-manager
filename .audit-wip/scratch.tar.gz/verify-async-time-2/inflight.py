"""Cosa solleva una richiesta in corso quando il client httpx viene chiuso (trasporto reale, TLS)."""
import asyncio, sys
sys.path.insert(0, "/home/user/axis-access-manager/axis_access_manager")
from app.vapix import A1210Client, VapixError

async def main():
    c = A1210Client("127.0.0.1:8911", "root", "x", False)
    async def call():
        try:
            r = await c.list_users()
            return ("ok", r)
        except BaseException as e:
            return ("exc", repr(e))
    t = asyncio.create_task(call())
    await asyncio.sleep(0.3)
    await c.aclose()
    print("in volo:", await t)
    try:
        await c.list_access_points()
    except BaseException as e:
        print("successiva:", repr(e), isinstance(e, VapixError))
asyncio.run(main())

"""Server HTTPS minimale che imita il controller, con risposte lente per alcuni metodi."""
import asyncio, json, ssl, sys

SLOW = {"axudb:GetUserList": 1.0, "pacsaxis:GetCredentialList": 0.3}
KEYS = {
    "pacsaxis:GetCredentialList": "Credential",
    "axudb:GetUserList": "User",
    "pacsaxis:GetAccessPointList": "AccessPoint",
    "pacsaxis:GetAccessProfileList": "AccessProfile",
    "axsch:GetScheduleList": "Schedule",
    "pacsaxis:GetAccessControllerList": "AccessController",
}

async def handle(reader, writer):
    try:
        while True:
            head = await reader.readuntil(b"\r\n\r\n")
            lines = head.decode().split("\r\n")
            path = lines[0].split()[1]
            length = 0
            for l in lines[1:]:
                if l.lower().startswith("content-length:"):
                    length = int(l.split(":")[1])
            body = await reader.readexactly(length) if length else b""
            try:
                data = json.loads(body or b"{}")
            except ValueError:
                data = {}
            if path.endswith("basicdeviceinfo.cgi"):
                out = {"data": {"propertyList": {"ProdNbr": "A1210", "SerialNumber": "X"}}}
            elif path.startswith("/axis-cgi/"):
                out = {"data": {}}
            else:
                method = next(iter(data), "")
                await asyncio.sleep(SLOW.get(method, 0))
                key = KEYS.get(method)
                if method == "pacsaxis:GetCredentialList":
                    out = {"Credential": [{"token": "c1", "UserToken": "u1", "Enabled": True, "Description": "Mario", "IdData": [{"Name": "CardNr", "Value": "1234"}]}]}
                else:
                    out = {key: []} if key else {}
            payload = json.dumps(out).encode()
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: %d\r\n\r\n" % len(payload) + payload)
            await writer.drain()
    except Exception:
        pass
    finally:
        writer.close()

async def main(port):
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.load_cert_chain("cert.pem", "key.pem")
    srv = await asyncio.start_server(handle, "127.0.0.1", port, ssl=ctx)
    async with srv:
        await srv.serve_forever()

if __name__ == "__main__":
    asyncio.run(main(int(sys.argv[1])))

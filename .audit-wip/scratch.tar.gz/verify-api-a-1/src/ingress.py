"""Supervisor App ingress service."""

import asyncio
from ipaddress import ip_address
import logging
from typing import Any

import aiohttp
from aiohttp import ClientTimeout, ClientWSTimeout, WSCloseCode, hdrs, web
from aiohttp.web_exceptions import (
    HTTPBadGateway,
    HTTPForbidden,
    HTTPServiceUnavailable,
    HTTPUnauthorized,
)
from multidict import CIMultiDict
import voluptuous as vol

from ..apps.app import App
from ..const import (
    ATTR_ADMIN,
    ATTR_ENABLE,
    ATTR_ICON,
    ATTR_PANELS,
    ATTR_SESSION,
    ATTR_SESSION_DATA_USER_ID,
    ATTR_TITLE,
    HEADER_REMOTE_USER_DISPLAY_NAME,
    HEADER_REMOTE_USER_GROUPS,
    HEADER_REMOTE_USER_ID,
    HEADER_REMOTE_USER_NAME,
    HEADER_TOKEN,
    HEADER_TOKEN_OLD,
    STOPPING_STATES,
    WEBSOCKET_CLOSE_TIMEOUT,
    HomeAssistantUser,
    IngressSessionData,
)
from ..coresys import CoreSysAttributes
from ..exceptions import APIError, APIUnauthorized, HomeAssistantAPIError
from .const import COOKIE_INGRESS, WEBSOCKETS
from .utils import api_process, api_validate, require_home_assistant, stop_on_disconnect

_LOGGER: logging.Logger = logging.getLogger(__name__)

# Header name comparisons must be case-insensitive, istr equality is not
_REQUEST_HEADERS_FILTER = frozenset(
    name.lower()
    for name in (
        hdrs.CONTENT_LENGTH,
        hdrs.CONTENT_ENCODING,
        hdrs.TRANSFER_ENCODING,
        hdrs.SEC_WEBSOCKET_EXTENSIONS,
        hdrs.SEC_WEBSOCKET_PROTOCOL,
        hdrs.SEC_WEBSOCKET_VERSION,
        hdrs.SEC_WEBSOCKET_KEY,
        HEADER_TOKEN,
        HEADER_TOKEN_OLD,
        HEADER_REMOTE_USER_ID,
        HEADER_REMOTE_USER_NAME,
        HEADER_REMOTE_USER_DISPLAY_NAME,
        HEADER_REMOTE_USER_GROUPS,
    )
)
_RESPONSE_HEADERS_FILTER = frozenset(
    name.lower()
    for name in (
        hdrs.TRANSFER_ENCODING,
        hdrs.CONTENT_LENGTH,
        hdrs.CONTENT_TYPE,
        hdrs.CONTENT_ENCODING,
    )
)

MAX_WEBSOCKET_MESSAGE_SIZE = 16 * 1024 * 1024  # 16 MiB

VALIDATE_SESSION_DATA = vol.Schema({ATTR_SESSION: str})

"""Expected optional payload of create session request"""
SCHEMA_INGRESS_CREATE_SESSION_DATA = vol.Schema(
    {
        vol.Required(ATTR_SESSION_DATA_USER_ID): str,
    }
)


# from https://github.com/aio-libs/aiohttp/blob/8ae650bee4add9f131d49b96a0a150311ea58cd1/aiohttp/helpers.py#L1059C1-L1079C1
def must_be_empty_body(method: str, code: int) -> bool:
    """Check if a request must return an empty body."""
    return (
        status_code_must_be_empty_body(code)
        or method_must_be_empty_body(method)
        or (200 <= code < 300 and method.upper() == hdrs.METH_CONNECT)
    )


def method_must_be_empty_body(method: str) -> bool:
    """Check if a method must return an empty body."""
    # https://datatracker.ietf.org/doc/html/rfc9112#section-6.3-2.1
    # https://datatracker.ietf.org/doc/html/rfc9112#section-6.3-2.2
    return method.upper() == hdrs.METH_HEAD


def status_code_must_be_empty_body(code: int) -> bool:
    """Check if a status code must return an empty body."""
    # https://datatracker.ietf.org/doc/html/rfc9112#section-6.3-2.1
    return code in {204, 304} or 100 <= code < 200


class APIIngress(CoreSysAttributes):
    """Ingress view to handle app webui routing."""

    def _extract_app(self, request: web.Request) -> App:
        """Return app, throw an exception it it doesn't exist."""
        token = request.match_info["token"]

        # Find correct app
        app = self.sys_ingress.get(token)
        if not app:
            _LOGGER.warning("Ingress for %s not available", token)
            raise HTTPServiceUnavailable

        return app

    def _create_url(self, app: App, path: str) -> str:
        """Create URL to container."""
        return f"http://{app.ip_address}:{app.ingress_port}/{path}"

    @api_process
    async def panels(self, request: web.Request) -> dict[str, Any]:
        """Create a list of panel data."""
        apps = {}
        for app in self.sys_ingress.apps:
            apps[app.slug] = {
                ATTR_TITLE: app.panel_title,
                ATTR_ICON: app.panel_icon,
                ATTR_ADMIN: app.panel_admin,
                ATTR_ENABLE: app.ingress_panel,
            }

        return {ATTR_PANELS: apps}

    @api_process
    @require_home_assistant
    async def create_session(self, request: web.Request) -> dict[str, Any]:
        """Create a new session."""
        body = await api_validate(SCHEMA_INGRESS_CREATE_SESSION_DATA, request)
        user_id = body[ATTR_SESSION_DATA_USER_ID]

        try:
            user = await self._find_user_by_id(user_id)
        except HomeAssistantAPIError as err:
            _LOGGER.warning("Could not fetch list of users: %s", err)
            # Keep the ID so the user can be resolved on first use
            user = HomeAssistantUser(user_id)
        else:
            if user is None or not user.is_active:
                raise APIError(f"User {user_id} does not exist or is inactive")
            self.sys_ingress.users[user.id] = user

        session = self.sys_ingress.create_session(IngressSessionData(user))
        return {ATTR_SESSION: session}

    @api_process
    @require_home_assistant
    async def validate_session(self, request: web.Request) -> None:
        """Validate session and extending how long it's valid for."""
        data = await api_validate(VALIDATE_SESSION_DATA, request)

        # Check Ingress Session
        if not self.sys_ingress.validate_session(data[ATTR_SESSION]):
            _LOGGER.warning("No valid ingress session %s", data[ATTR_SESSION])
            raise APIUnauthorized("Ingress session is not valid")

    async def handler(
        self, request: web.Request
    ) -> web.Response | web.StreamResponse | web.WebSocketResponse:
        """Route data to Supervisor ingress service."""

        # Check Ingress Session
        session = request.cookies.get(COOKIE_INGRESS, "")
        if not self.sys_ingress.validate_session(session):
            _LOGGER.warning("No valid ingress session %s", session)
            raise HTTPUnauthorized

        # Process requests
        app = self._extract_app(request)
        path = request.match_info.get("path", "")
        session_data = self.sys_ingress.get_session_data(session)
        user = await self._get_user(session, session_data) if session_data else None
        if app.panel_admin and (user is None or not user.is_admin):
            _LOGGER.warning(
                "Ingress access to %s denied for non-admin user %s",
                app.slug,
                user.id if user else None,
            )
            raise HTTPForbidden
        try:
            # Websocket
            if _is_websocket(request):
                return await self._handle_websocket(request, app, path, user)

            # Request
            return await self._handle_request(request, app, path, user)

        except aiohttp.ClientError as err:
            _LOGGER.error("Ingress error: %s", err)

        raise HTTPBadGateway

    async def _handle_websocket(
        self,
        request: web.Request,
        app: App,
        path: str,
        user: HomeAssistantUser | None,
    ) -> web.WebSocketResponse:
        """Ingress route for websocket."""
        if hdrs.SEC_WEBSOCKET_PROTOCOL in request.headers:
            req_protocols = [
                str(proto.strip())
                for proto in request.headers[hdrs.SEC_WEBSOCKET_PROTOCOL].split(",")
            ]
        else:
            req_protocols = []

        ws_server = web.WebSocketResponse(
            protocols=req_protocols,
            autoclose=False,
            autoping=False,
            max_msg_size=MAX_WEBSOCKET_MESSAGE_SIZE,
        )
        await ws_server.prepare(request)
        request.config_dict[WEBSOCKETS].add(ws_server)
        # The upgrade may complete after API stop closed the tracked websockets
        if self.sys_core.state in STOPPING_STATES:
            await ws_server.close(code=WSCloseCode.GOING_AWAY)
            return ws_server

        # Preparing
        url = self._create_url(app, path)
        source_header = _init_header(request, app, user)

        # Support GET query
        if request.query_string:
            url = f"{url}?{request.query_string}"

        # Start proxy
        try:
            _LOGGER.debug("Proxing WebSocket to %s, upstream url: %s", app.slug, url)
            async with self.sys_websession.ws_connect(
                url,
                headers=source_header,
                protocols=req_protocols,
                autoclose=False,
                autoping=False,
                max_msg_size=MAX_WEBSOCKET_MESSAGE_SIZE,
                timeout=ClientWSTimeout(ws_close=WEBSOCKET_CLOSE_TIMEOUT),
            ) as ws_client:
                # Proxy requests
                await asyncio.wait(
                    [
                        self.sys_create_background_task(
                            _websocket_forward(ws_server, ws_client)
                        ),
                        self.sys_create_background_task(
                            _websocket_forward(ws_client, ws_server)
                        ),
                    ],
                    return_when=asyncio.FIRST_COMPLETED,
                )
        except TimeoutError:
            _LOGGER.warning("WebSocket proxy to %s timed out", app.slug)

        return ws_server

    async def _handle_request(
        self,
        request: web.Request,
        app: App,
        path: str,
        user: HomeAssistantUser | None,
    ) -> web.Response | web.StreamResponse:
        """Ingress route for request."""
        url = self._create_url(app, path)
        source_header = _init_header(request, app, user)

        # Passing the raw stream breaks requests for some webservers
        # since we just need it for POST requests really, for all other methods
        # we read the bytes and pass that to the request to the app
        # apps needs to add support with that in the configuration
        data = (
            request.content
            if request.method == "POST" and app.ingress_stream
            else await request.read()
        )

        async with self.sys_websession.request(
            request.method,
            url,
            headers=source_header,
            params=request.query,
            allow_redirects=False,
            data=data,
            timeout=ClientTimeout(total=None),
            skip_auto_headers={hdrs.CONTENT_TYPE},
        ) as result:
            headers = _response_header(result)

            # Avoid parsing content_type in simple cases for better performance
            if maybe_content_type := result.headers.get(hdrs.CONTENT_TYPE):
                content_type = (maybe_content_type.partition(";"))[0].strip()
            else:
                content_type = result.content_type

            # Empty body responses (304, 204, HEAD, etc.) should not be streamed,
            # otherwise aiohttp < 3.9.0 may generate an invalid "0\r\n\r\n" chunk
            # This also avoids setting content_type for empty responses.
            if must_be_empty_body(request.method, result.status):
                # If upstream contains content-type, preserve it (e.g. for HEAD requests)
                if maybe_content_type:
                    headers[hdrs.CONTENT_TYPE] = content_type
                return web.Response(
                    headers=headers,
                    status=result.status,
                )

            # Simple request
            if (
                hdrs.CONTENT_LENGTH in result.headers
                and int(result.headers.get(hdrs.CONTENT_LENGTH, 0)) < 4_194_000
            ):
                # Return Response
                body = await result.read()
                return web.Response(
                    headers=headers,
                    status=result.status,
                    content_type=content_type,
                    body=body,
                )

            # Stream response
            response = web.StreamResponse(status=result.status, headers=headers)
            response.content_type = content_type

            async with stop_on_disconnect(request):
                try:
                    response.headers["X-Accel-Buffering"] = "no"
                    await response.prepare(request)
                    async for data, _ in result.content.iter_chunks():
                        await response.write(data)

                except (
                    aiohttp.ClientError,
                    aiohttp.ClientPayloadError,
                    ConnectionResetError,
                    ConnectionError,
                ) as err:
                    _LOGGER.error("Stream error with %s: %s", url, err)

            return response

    async def _find_user_by_id(self, user_id: str) -> HomeAssistantUser | None:
        """Find user object by the user's ID.

        Raises HomeAssistantAPIError if the user list cannot be fetched.
        """
        users = await self.sys_homeassistant.list_users()
        return next((user for user in users if user.id == user_id), None)

    async def _get_user(
        self, session: str, session_data: IngressSessionData
    ) -> HomeAssistantUser:
        """Return the user record of a session, resolved from Core once.

        While Core is unreachable the record stored with the session is
        returned, which denies admin access without caching. Sessions of
        removed or deactivated users are invalidated.
        """
        if user := self.sys_ingress.users.get(session_data.user.id):
            return user

        try:
            user = await self._find_user_by_id(session_data.user.id)
        except HomeAssistantAPIError as err:
            _LOGGER.warning("Could not fetch list of users: %s", err)
            return session_data.user

        if user is None or not user.is_active:
            _LOGGER.warning(
                "Ingress session of removed or inactive user %s", session_data.user.id
            )
            self.sys_ingress.remove_session(session)
            raise HTTPUnauthorized

        self.sys_ingress.users[user.id] = user
        return user


def _init_header(
    request: web.Request, app: App, user: HomeAssistantUser | None
) -> CIMultiDict[str]:
    """Create initial header."""
    headers = CIMultiDict[str]()

    for name, value in request.headers.items():
        if name.lower() in _REQUEST_HEADERS_FILTER:
            continue
        headers.add(name, value)

    # Set after copying so a client cannot smuggle these in any letter case
    if user is not None:
        headers[HEADER_REMOTE_USER_ID] = user.id
        if user.username is not None:
            headers[HEADER_REMOTE_USER_NAME] = user.username
        if user.name is not None:
            headers[HEADER_REMOTE_USER_DISPLAY_NAME] = user.name
        if groups := user.effective_group_ids:
            headers[HEADER_REMOTE_USER_GROUPS] = ",".join(groups)

    # Update X-Forwarded-For, a Unix socket peer has no address to append
    if request.transport and (peername := request.transport.get_extra_info("peername")):
        forward_for = request.headers.get(hdrs.X_FORWARDED_FOR)
        connected_ip = ip_address(peername[0])
        headers[hdrs.X_FORWARDED_FOR] = f"{forward_for}, {connected_ip!s}"

    return headers


def _response_header(response: aiohttp.ClientResponse) -> CIMultiDict[str]:
    """Create response header."""
    headers = CIMultiDict[str]()

    for name, value in response.headers.items():
        if name.lower() in _RESPONSE_HEADERS_FILTER:
            continue
        headers.add(name, value)

    return headers


def _is_websocket(request: web.Request) -> bool:
    """Return True if request is a websocket."""
    headers = request.headers

    if (
        "upgrade" in headers.get(hdrs.CONNECTION, "").lower()
        and headers.get(hdrs.UPGRADE, "").lower() == "websocket"
    ):
        return True
    return False


async def _websocket_forward(ws_from, ws_to):
    """Handle websocket message directly."""
    try:
        async for msg in ws_from:
            if msg.type == aiohttp.WSMsgType.TEXT:
                await ws_to.send_str(msg.data)
            elif msg.type == aiohttp.WSMsgType.BINARY:
                await ws_to.send_bytes(msg.data)
            elif msg.type == aiohttp.WSMsgType.PING:
                await ws_to.ping(msg.data)
            elif msg.type == aiohttp.WSMsgType.PONG:
                await ws_to.pong(msg.data)
            elif ws_to.closed:
                await ws_to.close(code=ws_to.close_code, message=msg.extra)
    except RuntimeError:
        _LOGGER.warning("Ingress Websocket runtime error")

import tempfile, os
from pathlib import Path
from fastapi.testclient import TestClient
os.environ.pop("SUPERVISOR_TOKEN", None)
from app.config import parse_options
from app.main import create_app
from conftest import FakeController

settings = parse_options({"a1210_host": "", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, db_path=tmp / "a.db", scheduled_backups=False)
with TestClient(app) as c:
    admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising", "X-Remote-User-Id": "a1"}
    guest = {"X-Remote-User-Name": "ospite", "X-Remote-User-Display-Name": "Ospite", "X-Remote-User-Id": "g1"}
    ldap = {"X-Remote-User-Id": "abc123", "X-Remote-User-Display-Name": "Portiere"}
    me = c.get("/api/me", headers=admin).json(); print("admin me:", me.get("name"), me.get("admin"), me.get("role"))
    me = c.get("/api/me", headers=guest).json(); print("guest me:", me.get("name"), me.get("admin"), me.get("role"))
    print("guest GET /api/users:", c.get("/api/users", headers=guest).status_code)
    me = c.get("/api/me", headers=ldap).json(); print("ldap me:", {k: me.get(k) for k in ("username","name","admin","role")})
    print("ldap GET /api/users:", c.get("/api/users", headers=ldap).status_code)
    r = c.put("/api/users/ospite", json={"perms": ["utenti"]}, headers=ldap); print("ldap promotes ospite:", r.status_code, r.json().get("perms") if r.status_code==200 else r.text)
    print("users:", [(u["username"], u["role"]) for u in c.get("/api/users", headers=admin).json()["users"]])
    acts = c.get("/api/activity", headers=admin)
    print("activity", acts.status_code, str(acts.json())[:400])

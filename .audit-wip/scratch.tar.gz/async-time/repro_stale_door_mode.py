"""Modalità della porta rimasta "Accessed" dopo un'interruzione MQTT: la rilettura dal controller dopo l'interruzione
non la corregge (tiene quella "di MQTT") e le aperture da Home Assistant e dal citofono vengono rifiutate."""

import asyncio
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController

from app import main as m
from app.config import MqttSettings, parse_options
from app.ha import HomeAssistant
from app.service import ServiceError


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    controller = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        state = app.state
        await asyncio.wait_for(state.health_ready.wait(), 10)
        monitor = state.monitor
        # Come con il broker collegato (in questo test non c'è un broker vero)
        state.mqtt = MqttSettings("broker")
        monitor.connected, monitor.controller_online = True, True
        monitor.door_modes["porta"] = "Locked"
        await state.service.open_door(False, "Luca (Home Assistant)", "porta")
        print("dopo l'apertura da HA:", monitor.door_modes["porta"], "| controller:", controller.door)
        # Il broker si riavvia mentre la porta è aperta a tempo: il "Locked" del controller va perso.
        monitor.outages += 1  # come EventMonitor.run all'errore MQTT; poi si ricollega
        controller.door = "Locked"  # il controller ha già richiuso
        await m._read_door_states(state)  # rilettura che il controllo di stato fa dopo ogni interruzione
        print("dopo la rilettura per l'interruzione:", monitor.door_modes["porta"], "| controller:", controller.door)
        try:
            await state.service.open_door(False, "Luca (Home Assistant)", "porta")
            print("seconda apertura: eseguita")
        except ServiceError as err:
            print("seconda apertura RIFIUTATA:", err)


asyncio.run(main())

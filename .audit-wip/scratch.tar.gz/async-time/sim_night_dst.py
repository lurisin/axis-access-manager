"""Simula _backup_loop minuto per minuto attorno ai cambi d'ora (TZ=Europe/Rome) con la vera next_run."""

import json
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from app.backup import NIGHT_LATE, BackupService, _parsed
from app.db import Database


def simulate(night: str, start: str, hours: int = 30) -> None:
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db")
    svc = BackupService(db, tmp / "backup", "x")
    db.set_setting("backup_policy", json.dumps({"auto": True, "frequency": "notte", "night": night}))
    now = datetime.fromisoformat(start)
    # Ultimo backup: il notturno del giorno prima, fatto all'ora giusta
    items = []
    end = now + timedelta(hours=hours)
    made = []
    while now < end:
        due = svc.next_run(now, items)
        if due and _parsed(due["at"]) <= now:
            kind = due["kind"]
            if kind == "notturno" and now - _parsed(due["at"]) > NIGHT_LATE:
                kind = "automatico"
            items.insert(0, {"id": now.isoformat(), "created_at": now.isoformat(timespec="seconds")})
            made.append((now.astimezone().strftime("%d/%m %H:%M %Z"), kind))
        now += timedelta(minutes=1)
    print(f"notturno alle {night}, da {start}: {made}")


for night in ("03:00", "02:30"):
    # Autunno: domenica 25/10/2026, alle 03:00 CEST si torna alle 02:00 CET
    simulate(night, "2026-10-23T23:00:00+00:00", 72)
    # Primavera: domenica 29/03/2026, alle 02:00 CET si passa alle 03:00 CEST
    simulate(night, "2026-03-27T23:00:00+00:00", 72)

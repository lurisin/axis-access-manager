"""Tempo sul loop di un backup (parti, impronte, gzip, confronto) con molte persone; quanto resta bloccato il loop."""

import asyncio
import os
import sys
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController

from app.backup import BackupService
from app.db import Database

N = int(sys.argv[1]) if len(sys.argv) > 1 else 2000


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db")
    controller = FakeController()
    for i in range(N):
        pid = db.add_person(f"Persona {i}", f"utente_{i}")
        db.add_card(pid, f"{0x1000 + i:x}", f"cred-{i}", access={"access_profile": "profilo_sempre"})
        controller.add_existing(f"utente_{i}", f"Persona {i}", f"{0x1000 + i:x}")
    cid = db.save_controller(None, {"name": "A1210", "host": "x", "username": "u", "password": "p", "verify_ssl": 0,
                                    "mqtt_topic_prefix": "a"})
    service = BackupService(db, tmp / "backup", "x")
    lags = []

    async def ticker():
        while True:
            t0 = time.perf_counter()
            await asyncio.sleep(0.005)
            lags.append(time.perf_counter() - t0 - 0.005)

    tick = asyncio.create_task(ticker())
    await asyncio.sleep(0.05)
    t0 = time.perf_counter()
    await service.create("manuale", "", "u", {cid: controller})
    t1 = time.perf_counter()
    # Seconda: una persona cambiata, si confronta con la prima
    db.rename_person(1, "Cambiata")
    await service.create("manuale", "", "u", {cid: controller})
    t2 = time.perf_counter()
    t3 = time.perf_counter()
    await service.compare(service.latest()["id"], "precedente", {cid: controller})
    t4 = time.perf_counter()
    tick.cancel()
    print(f"{N} persone: primo backup {t1 - t0:.2f} s, secondo {t2 - t1:.2f} s, confronto {t4 - t3:.2f} s")
    print(f"blocco massimo del loop: {max(lags) * 1000:.0f} ms")


asyncio.run(main())

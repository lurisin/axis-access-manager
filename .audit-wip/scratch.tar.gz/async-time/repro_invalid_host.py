"""Host accettato dalla validazione ma rifiutato da httpx: reload_runtime lascia l'app a metà e al riavvio
l'add-on non parte."""

import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from fastapi.testclient import TestClient

from app.config import MqttSettings, parse_options
from app.ha import HomeAssistant
from app.main import create_app

tmp = Path(tempfile.mkdtemp())
db_path = tmp / "a.db"
settings = parse_options({"mqtt_topic_prefix": "accessi/x"})
# Broker inesistente: il task di ascolto MQTT resta vivo e riprova ogni 10 s
settings = settings.__class__(**{**settings.__dict__, "mqtt": MqttSettings("127.0.0.1", 1)})

app = create_app(settings, allow_any_client=True, db_path=db_path, home_assistant=HomeAssistant(token=""))
with TestClient(app) as client:
    state = app.state
    print("monitor_task prima:", state.monitor_task, "done:", state.monitor_task.done() if state.monitor_task else None)
    body = {"name": "A1210", "host": "fe80::1", "username": "root", "password": "x", "mqtt_topic_prefix": "accessi/x"}
    try:
        r = client.post("/api/controllers", json=body)
        print("POST /api/controllers ->", r.status_code, r.text[:200])
    except Exception as err:  # TestClient rilancia le eccezioni non gestite
        print("POST /api/controllers ha sollevato:", type(err).__name__, err)
    print("controller salvato nel DB:", [(c["id"], c["host"]) for c in state.db.list_controllers()])
    print("settings.a1210_host:", state.settings.a1210_host)
    print("monitor_task dopo:", state.monitor_task, "cancelled:", state.monitor_task.cancelled() if state.monitor_task else None)
    print("raw_controller chiuso:", state.raw_controller._client.is_closed)

print("\n--- riavvio dell'add-on con lo stesso database ---")
app2 = create_app(settings, allow_any_client=True, db_path=db_path, home_assistant=HomeAssistant(token=""))
try:
    with TestClient(app2) as client:
        print("avvio riuscito", client.get("/api/me").status_code)
except Exception as err:
    print("AVVIO FALLITO:", type(err).__name__, err)

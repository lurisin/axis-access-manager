"""Recupero di molti eventi dal registro del controller: quanto resta bloccato il loop asyncio e quanti task
publish_state partono (uno per evento)."""

import asyncio
import os
import sys
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController

from app import main as m
from app.config import parse_options
from app.ha import HomeAssistant

N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000


def log_entries(n: int) -> list[dict]:
    start = datetime.now(tz=UTC) - timedelta(days=2)
    rows = []
    for i in range(n):
        moment = start + timedelta(seconds=30 * i)
        rows.append(
            {
                "rowid": 1000 + i,
                "UtcTime": moment.strftime("%Y-%m-%dT%H:%M:%S.000000Z"),
                "KeyValues": [
                    {"Key": "topic0", "Value": "AccessControl"},
                    {"Key": "topic1", "Value": "AccessGranted"},
                    {"Key": "topic2", "Value": "Credential"},
                    {"Key": "AccessPointToken", "Value": "ap-in"},
                    {"Key": "CredentialToken", "Value": f"cred-x{i % 50}"},
                    {"Key": "CredentialHolderName", "Value": "utente_x"},
                ],
            }
        )
    return rows


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    controller = FakeController()
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
         "mqtt_topic_prefix": "accessi/x"}
    )
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        state = app.state
        await asyncio.wait_for(state.health_ready.wait(), 10)
        await asyncio.sleep(0.5)
        calls = {"publish_state": 0, "max_tasks": 0}
        original = state.bridge.publish_state

        async def counting():
            calls["publish_state"] += 1
            await original()

        state.bridge.publish_state = counting
        controller.log_events = log_entries(N)
        lags = []

        async def ticker():
            while True:
                t0 = time.perf_counter()
                await asyncio.sleep(0.01)
                lags.append(time.perf_counter() - t0 - 0.01)
                calls["max_tasks"] = max(calls["max_tasks"], len(state.service._tasks))

        tick = asyncio.create_task(ticker())
        t0 = time.perf_counter()
        recovered = await state.service.recover_events(datetime.now(tz=UTC) - timedelta(days=3))
        t1 = time.perf_counter()
        while state.service._tasks:
            await asyncio.sleep(0.05)
        t2 = time.perf_counter()
        tick.cancel()
        print(f"eventi recuperati: {recovered} su {N}")
        print(f"recover_events: {t1 - t0:.2f} s; task di contorno finiti dopo altri {t2 - t1:.2f} s")
        print(f"task in volo al massimo: {calls['max_tasks']}; chiamate publish_state: {calls['publish_state']}")
        print(f"blocco massimo del loop: {max(lags) * 1000:.0f} ms")


asyncio.run(main())

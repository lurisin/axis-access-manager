"""Due comandi di apertura ravvicinati (doppio tocco sul pulsante di HA, o HA e citofono insieme): il controllo
"solo a serratura bloccata" e la modalità "Accessed" stanno ai due lati di un await, senza lock."""

import asyncio
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService


class SlowController(FakeController):
    async def access_door(self, door_token, extended=False):
        await asyncio.sleep(0.2)  # richiesta HTTPS al controller
        await super().access_door(door_token, extended)


async def main() -> None:
    db = Database(Path(tempfile.mkdtemp()) / "a.db")
    controller = SlowController()
    monitor = EventMonitor(prefix="accessi/x", door_token="porta", connected=True)
    monitor.door_modes["porta"] = "Locked"
    settings = parse_options({"a1210_host": "x", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    service = AccessService(db, controller, settings, monitor)
    results = await asyncio.gather(
        service.open_door(False, "Luca (Home Assistant)", "porta"),
        service.open_door(False, "App Hik-Connect (Citofono)", "porta"),
        return_exceptions=True,
    )
    print("esiti:", results)
    print("AccessDoor mandati al controller:", sum(1 for c in controller.calls if c[0] == "access_door"))
    print("aperture nel registro:", [(e["source"]) for e in db.list_events(kind="apertura_remota")])


asyncio.run(main())

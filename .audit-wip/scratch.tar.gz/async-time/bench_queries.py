"""Costo sul loop delle query sincrone più frequenti con un registro di un anno."""

import os
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from app.db import Database, local_day_start
from app.main import _week_series
from app.notifications import NotificationService
from app.transfer import events_csv

tmp = Path(tempfile.mkdtemp())
db = Database(tmp / "a.db")
persons = 500
for i in range(persons):
    pid = db.add_person(f"Persona {i}", f"utente_{i}")
    db.add_card(pid, f"{0x1000 + i:x}", f"cred-{i}")
now = datetime.now(tz=UTC)
rows = []
for i in range(110_000):
    ts = (now - timedelta(seconds=290 * i)).isoformat(timespec="seconds")
    kind = ("lettura", "concesso", "negato", "uscita")[i % 4]
    rows.append((ts, kind, f"{0x1000 + i % persons:x}", 1 + i % persons, f"Persona {i % persons}", "", "controller",
                 '{"AccessPointToken": "ap-in", "CredentialToken": "cred-1", "CredentialHolderName": "utente_1"}', "porta"))
with db._lock:
    db._conn.executemany(
        "INSERT INTO events (ts, kind, card, person_id, person_name, detail, source, raw, door) VALUES (?,?,?,?,?,?,?,?,?)",
        rows,
    )
    db._conn.commit()


def timed(label, fn, n=5):
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    print(f"{label}: {(time.perf_counter() - t0) / n * 1000:.1f} ms")


timed("last_accesses (GET /api/persons, scheda persona)", db.last_accesses)
timed("list_persons", db.list_persons)
timed("dashboard: count_events oggi", lambda: db.count_events(local_day_start()))
timed("dashboard: settimana", lambda: _week_series(db.event_kinds_since(local_day_start(6))))
notes = NotificationService(db)
timed(
    "notifiche (ogni 5 s da /api/summary)",
    lambda: notes.collect(mqtt_configured=True, mqtt_connected=True, controller_configured=True,
                          controller_online=True, sync={}, door_names={"porta": "Porta"}),
)
timed("holder_name (ogni concesso di una tessera tolta dall'app)", lambda: db.holder_name("utente_inesistente"))
timed("export CSV 50.000 eventi", lambda: events_csv(db.list_events(limit=50000), {"porta": "Porta"}), n=1)
timed("prune 0 giorni (tutto)", lambda: db.prune_events(0), n=1)

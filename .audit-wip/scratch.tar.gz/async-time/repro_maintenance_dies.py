"""reload_runtime chiude il client del controller mentre _maintenance sta sincronizzando: RuntimeError non gestito,
il ciclo di manutenzione muore senza log e non sincronizza/pota più; allo spegnimento il lifespan si interrompe."""

import asyncio
import json
import logging
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
logging.basicConfig(level=logging.WARNING, format="LOG %(levelname)s %(name)s: %(message)s")

import httpx

from app import main as m
from app.config import parse_options
from app.db import Database
from app.ha import HomeAssistant

SLOW = {"pacsaxis:GetCredentialList": 0.5}


async def handler(request: httpx.Request) -> httpx.Response:
    body = json.loads(request.content or b"{}")
    path = request.url.path
    if path.endswith("basicdeviceinfo.cgi"):
        return httpx.Response(200, json={"data": {"propertyList": {"ProdNbr": "A1210", "SerialNumber": "X"}}})
    if path.startswith("/axis-cgi/"):
        return httpx.Response(200, json={"data": {}})
    method = next(iter(body), "")
    await asyncio.sleep(SLOW.get(method, 0))
    key = {
        "pacsaxis:GetCredentialList": "Credential",
        "axudb:GetUserList": "User",
        "pacsaxis:GetAccessPointList": "AccessPoint",
        "pacsaxis:GetAccessProfileList": "AccessProfile",
        "axsch:GetScheduleList": "Schedule",
        "pacsaxis:GetAccessControllerList": "AccessController",
    }.get(method)
    return httpx.Response(200, json={key: []} if key else {})


class MockClient(m.A1210Client):
    def __init__(self, host, username, password, verify_ssl=False, transport=None):
        super().__init__(host, username, password, verify_ssl, transport=httpx.MockTransport(handler))

    async def certificate_fingerprint(self) -> str:
        return "AA"


m.A1210Client = MockClient


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db")
    cid = db.save_controller(
        None,
        {
            "name": "A1210",
            "host": "127.0.0.1",
            "username": "root",
            "password": "x",
            "verify_ssl": 0,
            "mqtt_topic_prefix": "accessi/x",
        },
    )
    db.save_door(None, cid, {"door_token": "porta", "name": "Porta", "snapshot_camera": "", "snapshot_on_granted": 0, "ha_buttons": 1, "intercom_name": "", "intercom_open_door": 0, "intercom_relay": 1, "intercom_mqtt_prefix": "hmd"})
    db.close()
    app = m.create_app(
        parse_options({"mqtt_topic_prefix": "accessi/x"}),
        allow_any_client=True,
        db_path=tmp / "a.db",
        home_assistant=HomeAssistant(token=""),
    )
    async with app.router.lifespan_context(app):
        state = app.state
        await asyncio.wait_for(state.health_ready.wait(), 10)
        for _ in range(50):
            if state.last_sync["ok"]:
                break
            await asyncio.sleep(0.1)
        maintenance = next(t for t in asyncio.all_tasks() if t.get_coro().__name__ == "_maintenance")
        print("prima sincronizzazione:", state.last_sync["ok"], state.last_sync["at"])
        # Il controller torna raggiungibile: sincronizzazione subito. Intanto un utente salva una porta.
        state.sync_wake.set()
        await asyncio.sleep(0.1)
        await m.reload_runtime(app)
        await asyncio.sleep(1)
        print("task _maintenance finito:", maintenance.done())
        if maintenance.done():
            print("eccezione del task:", repr(maintenance.exception()))
        before = state.last_sync["at"]
        state.sync_wake.set()
        await asyncio.sleep(1)
        print("sync_wake di nuovo: last_sync cambiato?", state.last_sync["at"] != before)
        print("--- spegnimento ---")
    print("spegnimento completato")


try:
    asyncio.run(main())
except Exception as err:
    print("LIFESPAN INTERROTTO ALLO SPEGNIMENTO:", type(err).__name__, err)

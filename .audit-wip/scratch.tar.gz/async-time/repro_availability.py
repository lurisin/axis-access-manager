"""Spegnimento pulito dell'add-on (aggiornamento, riavvio, stop): il "messaggio di addio" (will) non parte perché
aiomqtt si scollega con DISCONNECT, e nessuno pubblica "offline": in Home Assistant le entità restano disponibili."""

import asyncio
import logging
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
logging.basicConfig(level=logging.ERROR)

import aiomqtt
from amqtt.broker import Broker
from conftest import FakeController

from app import main as m
from app.config import MqttSettings, parse_options
from app.ha import HomeAssistant

PORT = 18830


async def main() -> None:
    broker = Broker(
        {
            "listeners": {"default": {"type": "tcp", "bind": f"127.0.0.1:{PORT}"}},
            "sys_interval": 0,
            "auth": {"allow-anonymous": True, "plugins": ["auth_anonymous"]},
            "topic-check": {"enabled": False},
        }
    )
    await broker.start()
    tmp = Path(tempfile.mkdtemp())
    base = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    settings = base.__class__(**{**base.__dict__, "mqtt": MqttSettings("127.0.0.1", PORT)})
    app = m.create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        for _ in range(50):
            if app.state.monitor.connected:
                break
            await asyncio.sleep(0.1)
        await asyncio.sleep(1)
        print("add-on collegato al broker:", app.state.monitor.connected)
    print("add-on spento (spegnimento pulito)")
    await asyncio.sleep(1)
    # Come Home Assistant che si (ri)abbona: legge il valore conservato del topic di disponibilità
    async with aiomqtt.Client("127.0.0.1", PORT) as client:
        await client.subscribe("axis_access_manager/disponibile", qos=1)
        try:
            async with asyncio.timeout(3):
                async for message in client.messages:
                    print("disponibilità vista da Home Assistant:", message.payload.decode(), "(retain:",
                          message.retain, ")")
                    break
        except TimeoutError:
            print("nessun valore di disponibilità")
    await broker.shutdown()


asyncio.run(main())

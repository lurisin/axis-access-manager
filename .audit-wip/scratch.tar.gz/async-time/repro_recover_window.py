"""Recupero degli eventi persi dopo un'interruzione MQTT: il punto di partenza è l'ultimo evento nel registro, che può
essere un evento arrivato in diretta DOPO la riconnessione (il recupero parte al giro del controllo di stato, fino a
30 s dopo). In quel caso gli eventi dell'interruzione non vengono mai recuperati."""

import asyncio
import os
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController

from app import main as m
from app.config import MqttSettings, parse_options
from app.events import Event
from app.ha import HomeAssistant


def granted_log(rowid: int, moment: datetime) -> dict:
    return {
        "rowid": rowid,
        "UtcTime": moment.strftime("%Y-%m-%dT%H:%M:%S.000000Z"),
        "KeyValues": [
            {"Key": "topic0", "Value": "AccessControl"},
            {"Key": "topic1", "Value": "AccessGranted"},
            {"Key": "topic2", "Value": "Credential"},
            {"Key": "AccessPointToken", "Value": "ap-in"},
            {"Key": "CredentialHolderName", "Value": "utente_x"},
        ],
    }


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    controller = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        state = app.state
        await asyncio.wait_for(state.health_ready.wait(), 10)
        monitor, service = state.monitor, state.service
        state.mqtt = MqttSettings("broker")
        monitor.connected, monitor.controller_online = True, True
        state.recover_pending, state.recover_outages = False, monitor.outages
        now = datetime.now(tz=UTC).replace(microsecond=0)
        start = now - timedelta(minutes=30)
        # Prima dell'interruzione: un accesso arrivato in diretta
        service.record_event(Event("AccessControl", "AccessControl/AccessGranted/Credential/", start,
                                   {"AccessPointToken": "ap-in", "CredentialHolderName": "utente_x"}))
        # Broker fermo 20 minuti: il controller registra 5 accessi nel suo registro interno
        monitor.outages += 1
        outage = [granted_log(100 + i, start + timedelta(minutes=3 + 3 * i)) for i in range(5)]
        # Riconnessione; 10 s dopo passa una persona (evento in diretta, anche nel registro del controller)
        live = now - timedelta(seconds=5)
        controller.log_events = outage + [granted_log(200, live)]
        service.record_event(Event("AccessControl", "AccessControl/AccessGranted/Credential/", live,
                                   {"AccessPointToken": "ap-in", "CredentialHolderName": "utente_x"}))
        # Il giro del controllo di stato (ogni 30 s) arriva dopo: recupero
        await m._recover_if_needed(state)
        rows = state.db.list_events(kind="concesso", limit=100)
        print("ultimo recupero:", state.last_recovery)
        print("accessi nel registro:", len(rows), "attesi:", 1 + len(outage) + 1)
        for row in sorted(rows, key=lambda r: r["ts"]):
            print("  ", row["ts"], "recuperato" if row["recovered"] else "in diretta")


asyncio.run(main())

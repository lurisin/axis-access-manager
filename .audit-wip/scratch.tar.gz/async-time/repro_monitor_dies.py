"""Un messaggio MQTT con un timestamp fuori scala (o NaN) sotto <prefisso>/eventi/ ferma per sempre EventMonitor.run:
l'eccezione non è MqttError, il ciclo di riconnessione non la prende e "connected" resta True."""

import asyncio
import json

import aiomqtt

from app import events
from app.events import EventMonitor


class Message:
    def __init__(self, topic: str, payload: bytes) -> None:
        self.topic = aiomqtt.Topic(topic)
        self.payload = payload
        self.retain = False


class FakeClient:
    """Broker finto: consegna i messaggi della lista, poi resta in attesa."""

    def __init__(self, messages):
        self._messages = messages

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False

    async def subscribe(self, *args, **kwargs):
        return None

    @property
    def messages(self):
        async def gen():
            for message in self._messages:
                yield message
            await asyncio.Event().wait()

        return gen()


async def main() -> None:
    received = []
    good = Message("accessi/x/eventi/AccessControl/AccessGranted/Credential", json.dumps(
        {"timestamp": 1761400000000, "message": {"data": {"Card": "04aa"}}}).encode())
    bad = Message("accessi/x/eventi/Prova", b'{"timestamp": 1e300}')
    after = Message("accessi/x/eventi/AccessControl/AccessGranted/Credential", json.dumps(
        {"timestamp": 1761400001000, "message": {"data": {"Card": "04bb"}}}).encode())
    events.aiomqtt.Client = lambda **kwargs: FakeClient([good, bad, after])
    monitor = EventMonitor(prefix="accessi/x")
    monitor.on_event = lambda event, retained: received.append(event.data.get("Card"))
    task = asyncio.create_task(monitor.run(events.MqttSettings("broker")))
    await asyncio.sleep(0.5)
    print("eventi ricevuti:", received)
    print("task di ascolto finito:", task.done(), "->", repr(task.exception()) if task.done() else "")
    print("monitor.connected (mostrato in Stato e usato da notifiche e recupero):", monitor.connected)


asyncio.run(main())

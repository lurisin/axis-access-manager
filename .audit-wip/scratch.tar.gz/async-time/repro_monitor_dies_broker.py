"""Con un broker vero: un messaggio con timestamp fuori scala sotto <prefisso>/eventi/ ferma l'ascolto MQTT per sempre;
gli accessi successivi non entrano nel registro e i pulsanti di HA non aprono più, ma lo stato resta "collegato"."""

import asyncio
import json
import logging
import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
logging.basicConfig(level=logging.ERROR)

import aiomqtt
from amqtt.broker import Broker
from conftest import FakeController

from app import main as m
from app.config import MqttSettings, parse_options
from app.ha import HomeAssistant

PORT = 18831


async def main() -> None:
    broker = Broker(
        {
            "listeners": {"default": {"type": "tcp", "bind": f"127.0.0.1:{PORT}"}},
            "sys_interval": 0,
            "auth": {"allow-anonymous": True, "plugins": ["auth_anonymous"]},
            "topic-check": {"enabled": False},
        }
    )
    await broker.start()
    tmp = Path(tempfile.mkdtemp())
    base = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    settings = base.__class__(**{**base.__dict__, "mqtt": MqttSettings("127.0.0.1", PORT)})
    controller = FakeController()
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=HomeAssistant(token=""))
    async with app.router.lifespan_context(app):
        state = app.state
        for _ in range(50):
            if state.monitor.connected:
                break
            await asyncio.sleep(0.1)
        await asyncio.sleep(0.5)
        state.monitor.door_modes["porta"] = "Locked"
        ms = int(time.time() * 1000)
        async with aiomqtt.Client("127.0.0.1", PORT) as client:
            granted = "accessi/x/eventi/AccessControl/AccessGranted/Credential/$source/AccessPointToken/ap-in"
            await client.publish(granted, json.dumps({"timestamp": ms, "message": {"data": {}}}), qos=1)
            await asyncio.sleep(0.5)
            await client.publish("accessi/x/eventi/Device/Prova", b'{"timestamp": 1e300}', qos=1)
            await asyncio.sleep(0.5)
            await client.publish(granted, json.dumps({"timestamp": ms + 5000, "message": {"data": {}}}), qos=1)
            await client.publish("axis_access_manager/comando", b"apri", qos=1)
            await asyncio.sleep(1)
        print("accessi nel registro:", len(state.db.list_events(kind="concesso")), "(attesi 2)")
        print("AccessDoor dal pulsante di HA:", sum(1 for c in controller.calls if c[0] == "access_door"), "(atteso 1)")
        print("task di ascolto MQTT finito:", state.monitor_task.done(),
              repr(state.monitor_task.exception()) if state.monitor_task.done() else "")
        print("stato mostrato: MQTT collegato =", state.monitor.connected)
        state.monitor_task = None  # evita che lo spegnimento rilanci l'eccezione
    await broker.shutdown()


asyncio.run(main())

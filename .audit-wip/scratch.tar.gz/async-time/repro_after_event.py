"""after_event: la pubblicazione dell'evento a Home Assistant aspetta l'istantanea (telecamera lenta = evento in
ritardo) e un errore di scrittura del file la salta del tutto, senza segnare l'errore della telecamera."""

import asyncio
import gc
import logging
import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
logging.basicConfig(level=logging.ERROR, format="LOG %(levelname)s %(name)s: %(message)s")

import httpx
from conftest import FakeController

from app import main as m
from app.config import parse_options
from app.ha import CORE_API, HomeAssistant

DELAY = 3.0


async def camera(request: httpx.Request) -> httpx.Response:
    await asyncio.sleep(DELAY)  # telecamera che risponde lenta (HA aspetta fino a 10 s)
    return httpx.Response(200, content=b"jpeg")


async def run(snapshot_dir: Path, label: str) -> None:
    tmp = Path(tempfile.mkdtemp())
    ha = HomeAssistant(token="x", snapshot_dir=snapshot_dir)
    await ha._client.aclose()
    ha._client = httpx.AsyncClient(base_url=CORE_API, transport=httpx.MockTransport(camera))
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    controller = FakeController()
    app = m.create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                       home_assistant=ha)
    async with app.router.lifespan_context(app):
        state = app.state
        state.db.save_door(state.doors[0]["id"], state.doors[0]["controller_id"],
                           {**{k: state.doors[0][k] for k in state.db.DOOR_FIELDS}, "snapshot_camera": "camera.ingresso"})
        await m.reload_runtime(app)
        published = []
        original = state.bridge.publish_event

        async def spy(row):
            published.append(time.perf_counter())
            await original(row)

        state.bridge.publish_event = spy
        t0 = time.perf_counter()
        state.service.log_event(ts=state.service.event_now(), kind="negato", card="04aa", detail="fuori fascia",
                                source="controller", door="porta")
        await asyncio.sleep(DELAY + 1)
        gc.collect()
        print(f"[{label}] evento pubblicato a HA:", f"dopo {published[0] - t0:.1f} s" if published else "MAI")
        print(f"[{label}] errori telecamera registrati:", state.snapshot_errors)


async def main() -> None:
    await run(Path(tempfile.mkdtemp()), "telecamera lenta")
    # Cartella Media non scrivibile (disco pieno, file system in sola lettura...): qui un file al posto della cartella
    blocker = Path(tempfile.mkdtemp()) / "media_file"
    blocker.write_text("x")
    await run(blocker / "axis_access_manager", "scrittura non riuscita")


asyncio.run(main())

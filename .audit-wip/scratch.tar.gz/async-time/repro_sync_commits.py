"""sync_from_controller con N tessere già note e invariate: quanti commit fa e quanto blocca il loop."""

import asyncio
import sqlite3
import sys
import tempfile
import time
from pathlib import Path

from conftest import FakeController

from app.config import parse_options
from app.db import Database
from app.service import AccessService

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000


async def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db")
    controller = FakeController()
    for i in range(N):
        controller.add_existing(f"utente_{i}", f"Persona {i}", f"{0x1000 + i:x}")
    settings = parse_options({"a1210_host": "x", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    service = AccessService(db, controller, settings)
    await service.sync_from_controller()  # prima importazione

    commits = {"n": 0}
    conn = db._conn

    class Counting:
        def __getattr__(self, name):
            return getattr(conn, name)

        def commit(self):
            commits["n"] += 1
            return conn.commit()

    db._conn = Counting()
    t0 = time.perf_counter()
    result = await service.sync_from_controller()  # niente di cambiato sul controller
    elapsed = time.perf_counter() - t0
    print(f"tessere: {result['cards']}, nuove: {result['added']}")
    print(f"commit per una sincronizzazione senza modifiche: {commits['n']}")
    print(f"tempo con il loop bloccato (FakeController non cede mai il controllo): {elapsed:.2f} s")
    db._conn = conn
    conn.execute("PRAGMA synchronous = OFF")
    t0 = time.perf_counter()
    await service.sync_from_controller()
    print(f"stessa sincronizzazione con synchronous=OFF (senza fsync): {time.perf_counter() - t0:.2f} s")


asyncio.run(main())

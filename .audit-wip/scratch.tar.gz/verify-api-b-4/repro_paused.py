"""Due porte; il controller passa in un'altra struttura mentre non risponde: il profilo resta quello vecchio per
sempre (online lo stesso salvataggio aggiorna il profilo)."""
import os
import sys
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402
from app.vapix import VapixError  # noqa: E402

OFFLINE = False
tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
controller.access_points.append({"token": "ap-cantina", "Entity": "porta2", "EntityType": "axtdc:Door",
    "Name": "Cantina", "Enabled": True, "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
    "Attribute": [{"Name": "Direction", "Value": "in"}]})
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    teatro = client.get("/api/locations", headers=admin).json()[0]
    cantina_area = client.post(f"/api/sites/{teatro['id']}/areas", json={"name": "Cantina"}, headers=admin).json()
    uffici = client.post("/api/sites", json={"name": "Uffici"}, headers=admin).json()
    piano = client.post(f"/api/sites/{uffici['id']}/areas", json={"name": "Piano 1"}, headers=admin).json()
    # Seconda porta nell'app, con l'area Teatro › Cantina scelta per la porta
    client.post("/api/controllers/1/doors", json={"door_token": "porta2", "name": "Cantina",
                                                  "area_id": cantina_area["id"]}, headers=admin)
    rules = [{"target": "site", "target_id": teatro["id"], "schedule": "standard_always"}]
    cat = client.post("/api/categories", json={"name": "Personale Teatro", "rules": rules}, headers=admin).json()
    policies = lambda: sorted(p["AccessPoint"] for p in controller.profiles[cat["token"]]["AccessPolicy"])  # noqa: E731
    print("Personale Teatro apre:", policies())
    real = controller.get_access_profiles

    async def offline(tokens):
        raise VapixError("il controller non risponde (ConnectTimeout)")

    controller.serial = "Y"  # controller sostituito: scritture sospese
    if OFFLINE:
        controller.get_access_profiles = offline
    ctrl = client.get("/api/installation", headers=admin).json()["controllers"][0]
    body = {"name": ctrl["name"], "host": ctrl["host"], "username": "root", "password": "x",
            "mqtt_topic_prefix": ctrl["mqtt_topic_prefix"], "area_id": piano["id"]}
    print("controller spostato in Uffici › Piano 1", "(controller offline)" if OFFLINE else "(controller online)",
          client.put("/api/controllers/1", json=body, headers=admin).status_code)
    controller.get_access_profiles = real
    print("paused:", app.state.controller.paused)
    print("accept", client.post("/api/controllers/1/identity/accept", headers=admin).status_code, "paused:", repr(app.state.controller.paused))
    client.post("/api/sync", headers=admin)
    print("Personale Teatro apre adesso:", policies())

import os, tempfile, time, logging
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app import main as main_module
from app.main import create_app

logging.basicConfig(level=logging.ERROR)
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
c = FakeController()
ta = c.add_existing("utente_anna", "Anna", "04aaaa")
tb = c.add_existing("utente_bruno", "Bruno", "04bbbb")
main_module.SYNC_INTERVAL = 0.2
main_module.SYNC_RETRY = 0.2
main_module.PRUNE_INTERVAL = 0.3
prunes = []
work = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=c, db_path=work / "api.db")
with TestClient(app, raise_server_exceptions=False) as client:
    time.sleep(1.5)
    orig_prune = app.state.db.prune_events
    def counting(days):
        prunes.append(time.time()); return orig_prune(days)
    app.state.db.prune_events = counting
    a0 = app.state.last_sync["at"]; time.sleep(1.2)
    print("loop alive:", app.state.last_sync["at"] != a0, "prunes so far", len(prunes))
    # Variant: Bruno deleted on controller first (marked missing), then badge 04bbbb reassigned to Anna's credential
    c.credentials.pop(tb)
    r = client.post("/api/sync"); print("sync after Bruno removal:", r.status_code, r.json())
    print("missing:", [(m["person_name"], m["number"]) for m in client.get("/api/missing-cards").json()])
    c.credentials[ta]["IdData"] = [{"Name": "Card", "Value": "04BBBB"}]
    r = client.post("/api/sync"); print("sync after reassign:", r.status_code, r.text[:120])
    n = len(prunes); at = app.state.last_sync["at"]; time.sleep(2)
    print("loop still alive?", app.state.last_sync["at"] != at, "prunes after:", len(prunes) - n, app.state.last_sync)
    st = client.get("/api/status")
    print("status sync:", st.status_code, st.json().get("sync") if st.status_code == 200 else st.text[:100])

"""Repro: delete_card dell'ultima tessera avvisa Home Assistant prima di cancellare la persona: lo stato
pubblicato conta ancora la persona eliminata."""

import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService
from conftest import FakeController


class SlowController(FakeController):
    async def remove_user(self, token):
        await asyncio.sleep(0.01)  # come una richiesta HTTP vera
        await super().remove_user(token)


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    service = AccessService(db, SlowController(), settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    person = await service.create_person("Mario", "04aa", "admin")
    published = []

    async def on_change():
        published.append(len(db.all_persons()))

    service.on_change = on_change
    await service.delete_card(person["cards"][0]["id"], "admin")
    await asyncio.sleep(0.05)
    print("persone pubblicate in HA dopo l'eliminazione:", published, "| persone nel DB:", len(db.all_persons()))


asyncio.run(run())

"""Repro: numero di una tessera corretto sul controller verso un numero che nel DB ha già un'altra tessera
(per esempio non presente) -> sqlite3.IntegrityError non gestita dentro sync_from_controller."""

import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService
from conftest import FakeController


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    service = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    mario = await service.create_person("Mario", "04aa", "admin")
    anna = await service.create_person("Anna", "04bb", "admin")
    # La tessera di Anna sparisce dal controller (segnata non presente) ...
    controller.credentials.pop(anna["cards"][0]["axis_credential_token"])
    await service.sync_from_controller()
    # ... e sul controller qualcuno corregge il numero della tessera di Mario in 04bb
    controller.credentials[mario["cards"][0]["axis_credential_token"]]["IdData"] = [{"Name": "Card", "Value": "04bb"}]
    try:
        await service.sync_from_controller()
        print("sincronizzazione ok")
    except Exception as err:  # noqa: BLE001
        print("sincronizzazione fallita con", type(err).__name__, err)


asyncio.run(run())

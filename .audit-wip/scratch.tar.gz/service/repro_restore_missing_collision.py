"""Repro: Ripristino delle tessere non presenti (anche dal Ripristino Completo) con due persone importate da
tessere senza utente e senza descrizione ("(Senza nome)"): nello stesso secondo ricevono lo stesso utente."""

import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService
from conftest import FakeController


def bare(token, number):
    return {
        "token": token,
        "Enabled": True,
        "IdData": [{"Name": "Card", "Value": number}],
        "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre", "ValidFrom": "", "ValidTo": ""}],
    }


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    service = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    controller.credentials = {"c1": bare("c1", "04a1"), "c2": bare("c2", "04a2")}
    await service.sync_from_controller()
    for p in db.list_persons():
        db.update_person_details(p["id"], f"Ditta {p['cards'][0]['number']}", "")
    print("prima:", [(p["name"], p["company"], [c["number"] for c in p["cards"]]) for p in db.list_persons()])
    controller.credentials.clear()  # reset del controller
    await service.sync_from_controller()
    try:
        print(await service.restore_missing("admin"))
    except Exception as err:  # noqa: BLE001
        print("restore_missing interrotto da", type(err).__name__, err)
    print("tessere sul controller:", [(c["IdData"][0]["Value"], c["UserToken"]) for c in controller.credentials.values()])
    await service.sync_from_controller()
    print("dopo la sincronizzazione:",
          [(p["name"], p["company"], [c["number"] for c in p["cards"]]) for p in db.list_persons()])


asyncio.run(run())

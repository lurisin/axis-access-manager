"""Repro: un payload con timestamp fuori scala fa uscire handle() con un'eccezione non MqttError,
che chiude per sempre il ciclo run() del monitor MQTT (nessuna riconnessione, connected resta True)."""

import asyncio
import json

import aiomqtt

from app.events import EventMonitor


class FakeMessage:
    def __init__(self, topic, payload):
        self.topic = aiomqtt.Topic(topic)
        self.payload = payload
        self.retain = False


class FakeClient:
    def __init__(self, *args, **kwargs):
        msgs = [
            FakeMessage("accessi/x/eventi/IdPoint/Request/IdData", json.dumps({"timestamp": 1761479926000000,
                                                                               "message": {"data": {"Card": "aa"}}}).encode()),
            FakeMessage("accessi/x/eventi/IdPoint/Request/IdData", json.dumps({"timestamp": 1761479926000,
                                                                               "message": {"data": {"Card": "bb"}}}).encode()),
        ]

        async def gen():
            for m in msgs:
                yield m
            await asyncio.sleep(3600)

        self.messages = gen()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False

    async def subscribe(self, *a, **k):
        pass


async def run():
    aiomqtt.Client = FakeClient
    import app.events as ev

    ev.aiomqtt.Client = FakeClient
    monitor = EventMonitor(prefix="accessi/x")
    seen = []
    monitor.on_event = lambda e, r: seen.append(e.data.get("Card"))
    settings = type("S", (), {"host": "h", "port": 1, "username": "", "password": ""})()
    task = asyncio.create_task(monitor.run(settings))
    await asyncio.sleep(0.2)
    print("task terminato:", task.done(), "| connected:", monitor.connected)
    if task.done():
        print("eccezione:", type(task.exception()).__name__, task.exception())
    print("eventi gestiti:", seen)


asyncio.run(run())

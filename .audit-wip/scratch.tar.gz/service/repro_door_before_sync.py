"""Repro: con due porte, all'avvio il recupero gira prima della prima sincronizzazione (access_point_doors vuoto):
gli esiti recuperati finiscono sulla porta principale e l'impronta non coincide con quella dell'evento live."""

import asyncio
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import Event, EventMonitor
from app.service import AccessService
from conftest import FakeController


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    controller.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Name": "Cantina"})
    moment = datetime(2026, 10, 25, 17, 54, 49, tzinfo=UTC)
    granted = {"AccessPointToken": "ap-cantina", "CredentialToken": "cred-x", "CredentialHolderName": "utente_x"}

    # Esecuzione precedente: sincronizzata, l'evento live va sulla Cantina
    before = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    await before.sync_from_controller()
    before.record_event(Event("AccessControl", "AccessControl/AccessGranted/Credential/", moment, dict(granted)))

    # Riavvio dell'add-on: servizio nuovo, recupero dal registro prima della prima sincronizzazione
    after = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    after._recovering = True
    try:
        after.record_event(Event("AccessControl", "AccessControl/AccessGranted/Credential/", moment, dict(granted)))
    finally:
        after._recovering = False
    for e in db.list_events():
        print(e["kind"], e["door"], "recuperato" if e["recovered"] else "live")


asyncio.run(run())

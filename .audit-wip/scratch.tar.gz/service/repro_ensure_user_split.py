"""Repro: restore_person su una persona importata da una tessera senza utente (credenziale:...) le dà un utente
nuovo ma lascia la tessera esistente senza utente: alla sincronizzazione successiva la persona si spezza in due e
quella originale (ditta, note, tipologia) viene cancellata."""

import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService
from conftest import FakeController


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    service = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    # Tessera creata fuori dall'app senza utente
    controller.credentials["cred-x"] = {
        "token": "cred-x",
        "Description": "Luca Verdi",
        "Enabled": True,
        "IdData": [{"Name": "Card", "Value": "04cc"}],
        "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre", "ValidFrom": "", "ValidTo": ""}],
    }
    await service.sync_from_controller()
    [person] = db.list_persons()
    print("dopo l'importazione:", person["name"], person["axis_user_token"], [c["number"] for c in person["cards"]])
    db.update_person_details(person["id"], "Ditta Verdi", "chiavi magazzino")
    saved = dict(db.get_person(person["id"]))  # backup di adesso
    saved["notes"] = "chiavi magazzino e cantina"  # nel backup la nota era diversa
    card = person["cards"][0]
    cards = [{k: card[k] for k in ("number", "enabled", "access_profile", "valid_from", "valid_to")}]
    await service.restore_person(saved, cards, 0, "admin")
    p = db.get_person(person["id"])
    print("dopo il ripristino:", p["name"], p["axis_user_token"], p["company"], p["notes"])
    print("UserToken della tessera sul controller:", controller.credentials["cred-x"].get("UserToken"))
    await service.sync_from_controller()
    for p in db.list_persons():
        print("dopo la sincronizzazione:", p["id"], p["name"], p["axis_user_token"], repr(p["company"]),
              repr(p["notes"]), [c["number"] for c in p["cards"]])
    print("persona originale ancora presente:", db.get_person(person["id"]) is not None)
    print("utenti orfani sul controller:", list(controller.users))


asyncio.run(run())

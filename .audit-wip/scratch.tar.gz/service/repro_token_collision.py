"""Repro: due persone con lo stesso slug create nello stesso secondo (importazione CSV) condividono il token utente."""

import asyncio
import tempfile
from datetime import datetime
from pathlib import Path

from app import service as service_module
from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService, user_token_for
from app.transfer import import_persons
from conftest import FakeController

FIXED = datetime(2026, 10, 28, 9, 0, 0)


class FrozenDatetime(datetime):
    @classmethod
    def now(cls, tz=None):
        return FIXED if tz is None else FIXED.replace(tzinfo=tz)


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    service = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    a = "Ospite Convegno Regionale Teatro 01"
    b = "Ospite Convegno Regionale Teatro 02"
    print("token A:", user_token_for(a, FIXED))
    print("token B:", user_token_for(b, FIXED))
    # Stesso secondo (in un'importazione CSV le righe si scrivono una dopo l'altra in pochi ms)
    service_module.datetime = FrozenDatetime
    csv = f"nome;tessera\n{a};04aa01\n{b};04aa02\nTerza Persona;04aa03\n"
    try:
        result = await import_persons(service, csv, [], "admin", apply=True)
        print("import:", result["riepilogo"])
    except Exception as err:  # noqa: BLE001
        print("importazione interrotta da:", type(err).__name__, err)
    print("utenti sul controller:", {t: u["Name"] for t, u in controller.users.items()})
    print("tessere sul controller:", sorted(card["IdData"][0]["Value"] for card in controller.credentials.values()))
    print("persone nell'app:", [(p["name"], [c["number"] for c in p["cards"]]) for p in db.list_persons()])
    service_module.datetime = datetime
    await service.sync_from_controller()
    print("dopo la sincronizzazione:", [(p["name"], [c["number"] for c in p["cards"]]) for p in db.list_persons()])


asyncio.run(run())

"""Repro: una lettura live arrivata dopo la riconnessione sposta in avanti l'inizio del recupero e gli eventi
dell'interruzione non vengono mai recuperati."""

import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

from app import main
from app.config import parse_options
from app.db import Database
from app.events import Event, EventMonitor
from app.service import AccessService
from conftest import FakeController


def log_entry(rowid, when, card):
    return {
        "rowid": rowid,
        "UtcTime": when.strftime("%Y-%m-%dT%H:%M:%S.000000Z"),
        "KeyValues": [
            {"Key": "topic0", "Value": "IdPoint"},
            {"Key": "topic1", "Value": "Request"},
            {"Key": "topic2", "Value": "IdData"},
            {"Key": "Card", "Value": card},
        ],
    }


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    monitor = EventMonitor(prefix="accessi/x", door_token="porta")
    service = AccessService(db, controller, settings, monitor)
    now = datetime.now(tz=UTC).replace(microsecond=0)

    # Prima dell'interruzione: ultimo evento live alle now-30min
    t0 = now - timedelta(minutes=30)
    service.record_event(Event("IdPoint", "IdPoint/Request/IdData/", t0, {"Card": "aa01"}))
    # Broker fermo: durante l'interruzione il controller registra 3 letture (solo nel suo registro)
    lost = [log_entry(10 + i, t0 + timedelta(minutes=5 + i), f"bb0{i}") for i in range(3)]
    # Broker di nuovo collegato: arriva subito una lettura live, prima del giro del controllo (30 s)
    t_live = now - timedelta(seconds=5)
    controller.log_events = lost + [log_entry(20, t_live, "cc01")]
    monitor.outages = 1
    monitor.connected = True
    service.record_event(Event("IdPoint", "IdPoint/Request/IdData/", t_live, {"Card": "cc01"}))

    state = SimpleNamespace(
        monitor=monitor,
        recover_pending=False,
        recover_outages=0,
        installation=SimpleNamespace(primary={"id": 1}),
        health=SimpleNamespace(states={1: SimpleNamespace(online=True)}),
        controller=SimpleNamespace(paused=""),
        mqtt=object(),
        db=db,
        service=service,
    )
    await main._recover_if_needed(state)
    print("ultimo recupero:", state.last_recovery)
    cards = sorted(e["card"] for e in db.list_events())
    print("carte nel registro:", cards)
    print("letture perse durante l'interruzione recuperate:", [c for c in cards if c.startswith("bb")])


asyncio.run(run())

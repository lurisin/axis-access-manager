"""Repro: set_person_access salva la tipologia nel DB prima di scrivere sul controller; se una tessera manca
(o il controller non risponde) la richiesta fallisce ma tipologia e prima tessera restano cambiate."""

import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.service import AccessService, ServiceError
from conftest import FakeController


async def run():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
    )
    controller = FakeController()
    controller.profiles["p_pulizie"] = {"token": "p_pulizie", "Name": "Pulizie"}
    service = AccessService(db, controller, settings, EventMonitor(prefix="accessi/x", door_token="porta"))
    cat = db.save_category(None, {"name": "Pulizie", "color": "blue", "group_token": "p_pulizie", "valid_days": 0,
                                  "description": ""})
    person = await service.create_person("Mario", "04aa", "admin", group="profilo_sempre")
    person = await service.add_card(person["id"], "04bb", "admin")
    # La seconda tessera sparisce dal controller (non ancora segnata come non presente)
    controller.credentials.pop(person["cards"][1]["axis_credential_token"])
    try:
        await service.set_person_access(person["id"], "", "", "", "admin", category_id=cat)
    except ServiceError as err:
        print("errore mostrato:", err)
    p = db.get_person(person["id"])
    print("tipologia nel DB:", p["category_id"], "(nuova:", cat, ")")
    print("gruppi delle tessere nel DB:", [c["access_profile"] for c in p["cards"]])
    print("gruppi sul controller:", [c["CredentialAccessProfile"][0]["AccessProfile"]
                                     for c in controller.credentials.values()])
    print("attività:", [(a["action"], a["detail"]) for a in db.list_audit()][:2])


asyncio.run(run())

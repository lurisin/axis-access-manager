for (const to of ["2026-10-25", "2026-03-29", "2026-10-24"]) {
  const until = new Date(new Date(to + "T00:00:00").getTime() + 86400000);
  console.log(to, "until(local)=", until.toString(), "iso=", until.toISOString());
}
// logRows yesterday at 30/03 00:30 local
const fake = new Date("2026-03-30T00:30:00").getTime();
console.log("yesterday computed at 30/03 00:30:", new Date(fake - 86400000).toDateString());
const fake2 = new Date("2026-10-25T23:30:00").getTime();
console.log("yesterday computed at 25/10 23:30:", new Date(fake2 - 86400000).toDateString());

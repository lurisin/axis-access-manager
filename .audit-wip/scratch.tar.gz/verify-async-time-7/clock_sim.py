import asyncio, time as _time
from datetime import UTC, datetime, timedelta
from app import health as H, service as S

SKEW = {"v": -3600.0}  # HA clock behind by 1 h

class FakeTime:
    @staticmethod
    def time():
        return _time.time() + SKEW["v"]
    monotonic = staticmethod(_time.monotonic)
H.time = FakeTime

class FakeDT(datetime):
    @classmethod
    def now(cls, tz=None):
        return datetime.fromtimestamp(FakeTime.time(), tz=tz)
S.datetime = FakeDT

class Client:
    async def date_time_info(self):
        return {"utcDateTime": datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")}
    async def ntp_info(self):
        return {}

async def main():
    st = H.ControllerHealth(id=1, name="c")
    hm = H.HealthMonitor.__new__(H.HealthMonitor)
    await hm._clock(Client(), st)
    print("offset measured:", st.clock_offset)
    svc = S.AccessService.__new__(S.AccessService)
    svc.clock_offset = lambda: st.clock_offset
    true_now = datetime.now(tz=UTC).replace(microsecond=0)
    print("true now       :", true_now.isoformat())
    print("event_now (HA behind):", svc.event_now())
    SKEW["v"] = 0.0  # NTP fixes HA clock
    print("event_now after HA clock step, before next clock read:", svc.event_now())
asyncio.run(main())

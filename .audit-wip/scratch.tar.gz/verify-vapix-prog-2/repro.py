import asyncio, copy, tempfile
from pathlib import Path
from conftest import FakeController
from app.db import Database
from app.programming import ProgrammingService, is_rex_profile
from app.service import ServiceError
from app.vapix import VapixError
from app.ha_mqtt import *  # noqa
import app.ha_mqtt as ham


class F(FakeController):
    fail_ap = False
    fail_remove_idpoint = False
    async def create_access_point(self, ap):
        if self.fail_ap:
            raise VapixError("ReadTimeout")
        return await super().create_access_point(ap)
    async def remove_idpoint(self, token):
        if self.fail_remove_idpoint:
            raise VapixError("timeout")
        return await super().remove_idpoint(token)


def setup():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = F()
    c.doors["porta2"] = {**copy.deepcopy(c.doors["porta"]), "token": "porta2", "Name": "Retro"}
    c.door_configs["porta2"] = {"token": "porta2", "Configuration": [{"Name": "Lock.Type", "Value": "FailSecure"}]}
    cid = db.save_controller(None, {f: "" for f in db.CONTROLLER_FIELDS} | {"name": "A1210", "verify_ssl": 0})
    return db, c, cid, ProgrammingService(db, c, cid, asyncio.Lock())


def state(tag, db, c, cid, io="IO1"):
    r = db.controller_inputs(cid).get(io, {})
    rex = [p.get("AccessPolicy") for p in c.profiles.values() if is_rex_profile(p)]
    print(f"[{tag}] db role={r.get('role')!r} door={r.get('door_token')!r} ap={r.get('access_point_token')!r} idp={r.get('idpoint_token')!r}")
    print(f"     controller APs={[a['token'] for a in c.access_points]} rexpolicies={rex} io={c.io_assignments.get(io)}")


async def case1():
    print("=== Caso 1: rex -> Non Usato, errore in _release_io ===")
    db, c, cid, s = setup()
    st = {"name": "Pulsante Uscita", "role": "rex", "door": "porta", "contact": "no", "supervised": False}
    await s.update_input("IO1", st, "admin")
    state("ok", db, c, cid)
    c.fail_io_assignment = True
    try:
        await s.update_input("IO1", {**st, "role": ""}, "admin")
    except ServiceError as e:
        print("errore:", e)
    c.fail_io_assignment = False
    state("dopo errore", db, c, cid)
    page = await s.read()
    print("  rex_missing:", page["rex_missing"], "unmanaged:", page["unmanaged"], "errors:", page["errors"])
    print("  pagina IO1:", [(i["role"], i["door"]) for i in page["inputs"] if i["io"] == "IO1"])
    c.calls.clear()
    await s.update_input("IO1", st, "admin")
    print("  risalvo uguale -> chiamate:", c.calls)
    state("dopo risalvataggio uguale", db, c, cid)
    # retry intended change
    await s.update_input("IO1", {**st, "role": "", "name": "Ingresso AUX 1"}, "admin")
    state("ritento Non Usato", db, c, cid)


async def case1b():
    print("=== Caso 1b: rex porta -> rex porta2, errore in _write_rex ===")
    db, c, cid, s = setup()
    st = {"name": "Pulsante Uscita", "role": "rex", "door": "porta", "contact": "no", "supervised": False}
    await s.update_input("IO1", st, "admin")
    c.fail_io_assignment = True
    try:
        await s.update_input("IO1", {**st, "door": "porta2"}, "admin")
    except ServiceError as e:
        print("errore:", e)
    c.fail_io_assignment = False
    state("dopo errore", db, c, cid)
    page = await s.read()
    print("  rex_missing:", page["rex_missing"])
    c.calls.clear()
    await s.update_input("IO1", st, "admin")
    print("  torno a porta -> chiamate:", c.calls)
    state("dopo", db, c, cid)
    # ha polarity
    print("  pushbutton ports (DB):", [r["role"] for r in db.all_controller_inputs()])


async def case2():
    print("=== Caso 2: creazione, errore in create_access_point ===")
    db, c, cid, s = setup()
    c.fail_ap = True
    try:
        await s.update_input("IO1", {"name": "Pulsante", "role": "rex", "door": "porta"}, "admin")
    except ServiceError as e:
        print("errore:", e)
    c.fail_ap = False
    state("dopo errore", db, c, cid)
    page = await s.read()
    print("  pagina IO1:", [(i["role"], i["name"], i["assigned"]) for i in page["inputs"] if i["io"] == "IO1"])
    print("  readers in pagina:", [r["token"] for r in page["readers"]], "idpoints controller:", list(c.idpoints))
    c.calls.clear()
    await s.update_input("IO1", {"name": "Ingresso AUX 1", "role": ""}, "admin")
    print("  risalvo Non Usato -> chiamate:", c.calls)
    state("dopo", db, c, cid)

asyncio.run(case1()); asyncio.run(case1b()); asyncio.run(case2())

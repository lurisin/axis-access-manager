"""UI harness for Axis Access Manager: runs the real FastAPI app on a FakeController with realistic seed data.

Usage:  python3 serve.py [PORT] [--fresh]
  PORT     default 8765
  --fresh  delete ui.db, backups and snapshots of a previous run and seed again

The repository is only read: everything this script writes stays in this folder.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import sys
import threading
import time
import traceback
from datetime import UTC, datetime, timedelta
from pathlib import Path

# Before importing the app: Italian installation, no scheduled backups, no Supervisor
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["TZ"] = "Europe/Rome"
time.tzset()

REPO = Path("/home/user/axis-access-manager")
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(REPO / "tests"), str(REPO / "axis_access_manager")]

import httpx  # noqa: E402
import uvicorn  # noqa: E402
from conftest import FakeController  # noqa: E402

import app.main as main_mod  # noqa: E402
from app.config import MqttSettings, parse_options  # noqa: E402
from app.events import CategoryStats, EventMonitor  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

PORT = int(next((a for a in sys.argv[1:] if a.isdigit()), "8765"))
FRESH = "--fresh" in sys.argv
DB = HERE / "ui.db"
SNAPSHOTS = HERE / "snapshots"
ADMIN = {"X-Remote-User-Name": "luca", "X-Remote-User-Display-Name": "Luca Bianchi"}

if FRESH:
    for path in (DB, HERE / "backup", SNAPSHOTS, HERE / "copie_database", HERE / "copia_backup"):
        if path.is_dir():
            shutil.rmtree(path)
        elif path.exists():
            path.unlink()
    for extra in HERE.glob("ui.db*"):
        extra.unlink()
SEED = not DB.exists()


def jpeg(path: Path, label: str, tint: tuple[int, int, int]) -> None:
    """A fake camera frame."""
    from PIL import Image, ImageDraw

    img = Image.new("RGB", (640, 360), tint)
    draw = ImageDraw.Draw(img)
    for y in range(0, 360, 24):
        draw.line([(0, y), (640, y + 40)], fill=tuple(min(255, c + 25) for c in tint), width=2)
    draw.rectangle([180, 60, 460, 330], outline=(230, 230, 230), width=6)
    draw.rectangle([10, 10, 300, 40], fill=(0, 0, 0))
    draw.text((18, 18), label, fill=(255, 255, 255))
    img.save(path, "JPEG", quality=80)


class FakeHA(HomeAssistant):
    """Home Assistant with four cameras (one idle, one unavailable) and a person behind the buttons."""

    def __init__(self) -> None:
        super().__init__(token="harness", snapshot_dir=SNAPSHOTS)

    async def states(self) -> list[dict]:
        return [
            {"entity_id": "camera.cantina", "name": "Cantina", "state": "idle"},
            {"entity_id": "camera.cortile", "name": "Cortile Interno", "state": "unavailable"},
            {"entity_id": "camera.ingresso_scala", "name": "Ingresso Scala A", "state": "streaming"},
            {"entity_id": "camera.quadro", "name": "Quadro Elettrico", "state": "streaming"},
        ]

    async def save_snapshot(self, camera: str, name: str) -> tuple[str, str]:
        SNAPSHOTS.mkdir(parents=True, exist_ok=True)
        jpeg(SNAPSHOTS / f"{name}.jpg", f"{camera} {name}", (60, 70, 90))
        return f"{name}.jpg", ""

    async def button_presser(self, now=None) -> str | None:
        return "Luca"


class FakeMonitor(EventMonitor):
    """MQTT always connected: controller online, events of every category already seen."""

    async def run(self, settings) -> None:  # noqa: ARG002
        now = datetime.now(tz=UTC)
        self.connected = True
        self.controller_online = True
        self.last_error = ""
        self.casing_open = False
        self.system_ready = (now - timedelta(days=3)).isoformat(timespec="seconds")
        for name, topic in (
            ("AccessControl", "AccessControl/AccessGranted/Anonymous/$source/AccessPointToken/ap-in"),
            ("Device", "Device/IO/Port/$source/port/0"),
            ("Door", "Door/State/DoorMode/$source/DoorToken/porta"),
            ("IdPoint", "IdPoint/Request/IdData/$source/IdPointToken/lettore-1"),
        ):
            self.categories[name] = CategoryStats(count=17, last_topic=topic, last_seen=now - timedelta(minutes=4))
        self.door_modes.update({"porta": "Locked", "porta2": "Unlocked"})
        self.door_physical.update({"porta": "Closed", "porta2": "Open"})
        self.io_ports.update({"0": True, "1": True, "2": False, "3": False})
        self.io_changed.update({"0"})
        self.last_card = {"card": "04a1b2c3d4e5f6", "read_at": now - timedelta(minutes=4)}
        await asyncio.Event().wait()


async def fake_resolve_mqtt(settings, client=None, token=None):  # noqa: ARG001
    return MqttSettings(host="core-mosquitto", port=1883, username="addons", password="x")


main_mod.EventMonitor = FakeMonitor
main_mod.resolve_mqtt = fake_resolve_mqtt

settings = parse_options(
    {
        "a1210_host": "a1210.local",
        "door_token": "porta",
        "access_profile": "profilo_sempre",
        "mqtt_topic_prefix": "accessi/x",
    }
)
controller = FakeController()
# Cantina with its own reader, and an exit access point on the main door (no reader yet)
controller.access_points.append({
    "token": "ap-cantina", "Entity": "porta2", "EntityType": "axtdc:Door", "Name": "Cantina ingresso", "Enabled": True,
    "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}], "Attribute": [{"Name": "Direction", "Value": "in"}],
})
controller.access_points.append({
    "token": "ap-out", "Entity": "porta", "EntityType": "axtdc:Door", "Name": "Uscita scala", "Enabled": True,
    "IdPointDevice": [], "Attribute": [{"Name": "Direction", "Value": "out"}],
})
controller.access_controllers["Axis-x AccessController"]["AccessPoint"] += ["ap-cantina", "ap-out"]
controller.door_configs["porta2"] = {"token": "porta2", "Configuration": [{"Name": "Lock.Type", "Value": "FailSafe"}]}


async def _idpoint_configs():
    """Like a real A1210: the configuration of every identification point (the fake controller has none)."""
    base = {
        t: {"token": t, "DeviceUUID": "uuid-locale",
            "Configuration": [{"Name": "IdPoint.Reader.Type", "Value": "OSDP"}, {"Name": "IdPoint.Reader.Protocol", "Value": "OSDP"}]}
        for t in ("lettore-1", "lettore-2")
    }
    for t, cfg in controller.idpoint_configs.items():
        base[t] = {"token": t, "DeviceUUID": cfg.get("DeviceUUID", ""),
                   "Configuration": [{"Name": k, "Value": v} for k, v in cfg.items() if k != "DeviceUUID"]}
    return list(base.values())


controller.list_idpoint_configurations = _idpoint_configs
app = create_app(settings, allow_any_client=True, controller=controller, db_path=DB, home_assistant=FakeHA())


async def scenario(name: str) -> dict:
    """Harness only: switch the plant into an error state to capture alerts, then back."""
    state = app.state
    if name == "offline":
        controller.offline = True
        state.monitor.connected = False
        state.monitor.last_error = "[Errno 111] Connection refused"
        for _ in range(3):
            await state.health.check_all()
    elif name == "changed":
        controller.offline = False
        controller.serial = "ACCC8E0A1B2C"
        await state.health.check_all()
    else:
        controller.offline = False
        controller.serial = "X"
        state.monitor.connected = True
        state.monitor.last_error = ""
        await state.health.check_all()
        for row in state.db.list_controllers():
            if row.get("identity_change"):
                state.health.accept_identity(row["id"], "harness")
    main_mod._apply_pause(state)
    return {"ok": True, "scenario": name}


app.add_api_route("/__harness/scenario/{name}", scenario, methods=["POST"])


def iso(moment: datetime) -> str:
    return moment.astimezone(UTC).isoformat(timespec="seconds")


def seed(base: str) -> None:
    c = httpx.Client(base_url=base, headers=ADMIN, timeout=60)

    def call(method: str, path: str, **kw):
        r = c.request(method, path, **kw)
        if r.status_code >= 400:
            raise RuntimeError(f"{method} {path} -> {r.status_code} {r.text}")
        return r.json()

    state = app.state
    db = state.db
    now = datetime.now().astimezone()
    call("GET", "/api/me")

    # Strutture e aree
    [site] = call("GET", "/api/locations")
    teatro, via_consulta = site["id"], site["areas"][0]["id"]
    call("PUT", f"/api/sites/{teatro}", json={"name": "Teatro Eliseo", "description": "Via Nazionale 183, Roma"})
    call("PUT", f"/api/areas/{via_consulta}", json={"name": "Via Consulta"})
    palco = call("POST", f"/api/sites/{teatro}/areas", json={"name": "Palcoscenico"})["id"]
    hotel = call("POST", "/api/sites", json={"name": "Hotel Giulia", "description": "Dependance"})["id"]
    call("POST", f"/api/sites/{hotel}/areas", json={"name": "Reception"})
    call("POST", f"/api/sites/{hotel}/areas", json={"name": "Primo Piano"})

    # Controller e porte
    [ctrl] = call("GET", "/api/installation")["controllers"]
    call(
        "PUT",
        f"/api/controllers/{ctrl['id']}",
        json={
            "name": "Controller Portineria",
            "host": "a1210.local",
            "username": "root",
            "password": "Segreta!2026",
            "verify_ssl": False,
            "mqtt_topic_prefix": "accessi/x",
            "area_id": via_consulta,
            "description": "Quadro elettrico sotto la scala",
        },
    )
    [ctrl] = call("GET", "/api/installation")["controllers"]
    [door] = ctrl["doors"]
    call(
        "PUT",
        f"/api/doors/{door['id']}",
        json={
            "door_token": "porta",
            "name": "Ingresso Scala A",
            "snapshot_camera": "camera.ingresso_scala",
            "snapshot_on_granted": False,
            "ha_buttons": True,
            "intercom_name": "Citofono Ingresso",
            "intercom_open_door": True,
            "intercom_relay": 1,
            "intercom_mqtt_prefix": "hmd",
        },
    )
    call(
        "POST",
        f"/api/controllers/{ctrl['id']}/doors",
        json={"door_token": "porta2", "name": "Cantina", "snapshot_camera": "camera.cantina", "ha_buttons": False},
    )
    call("PUT", f"/api/controllers/{ctrl['id']}/camera", json={"camera": "camera.quadro"})
    # Ingressi del controller: pulsante, relè del citofono, allarme
    call(
        "PUT",
        "/api/programming/inputs/IO1",
        json={"name": "Pulsante Portineria", "role": "rex", "door": "porta", "contact": "no", "supervised": False},
    )
    call("PUT", "/api/programming/inputs/IO2", json={"name": "", "role": "intercom", "door": "porta", "contact": "no"})
    call("PUT", "/api/programming/inputs/ALARM", json={"name": "Allagamento Cantina", "role": "alarm"})
    call("PUT", "/api/programming/doors/porta", json={"name": "Ingresso scala", "description": "Portone su strada",
                                                       "access_time": 7, "extended_access_time": 30,
                                                       "open_too_long_time": 15, "extended_open_too_long_time": 60,
                                                       "pre_alarm_time": 5})
    doors = {d["door_token"]: d for d in call("GET", "/api/installation")["controllers"][0]["doors"]}

    # Fasce orarie e festività
    office = call("POST", "/api/schedules", json={"name": "Orario Ufficio", "description": "Uffici e biglietteria",
                                                   "rules": [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "08:00", "end": "18:00"}],
                                                   "holidays": True})["token"]
    cleaning = call("POST", "/api/schedules", json={"name": "Pulizie Mattina", "rules": [
        {"days": ["MO", "TU", "WE", "TH", "FR", "SA"], "start": "06:00", "end": "10:00"}], "holidays": True})["token"]
    evening = call("POST", "/api/schedules", json={"name": "Serale Spettacoli", "description": "Turni serali",
                                                    "rules": [{"days": ["TU", "WE", "TH", "FR", "SA"], "start": "17:30", "end": "24:00"},
                                                              {"days": ["SU"], "start": "14:00", "end": "20:00"}],
                                                    "holidays": False})["token"]
    summer = call("POST", "/api/schedules", json={"name": "Orario Estivo", "rules": [
        {"days": ["MO", "TU", "WE", "TH", "FR"], "start": "07:00", "end": "14:00"}], "holidays": True})["token"]
    call("PUT", "/api/hidden", json={"kind": "schedule", "token": summer, "hidden": True})
    call("POST", "/api/holidays/italia", json={"year": now.year})
    call("POST", "/api/holidays", json={"day": f"{now.year}-06-29", "name": "Santi Pietro e Paolo (Patrono)", "yearly": True})
    call("POST", "/api/holidays", json={"day": f"{now.year}-11-02", "name": "Chiusura Straordinaria", "yearly": False})

    # Tipologie
    def cat(name, color, rules, valid_days=0, description=""):
        return call("POST", "/api/categories", json={"name": name, "color": color, "valid_days": valid_days,
                                                     "description": description, "rules": rules})

    dip = cat("Dipendente", "blue", [{"target": "door", "target_id": doors["porta"]["id"], "schedule": office},
                                      {"target": "door", "target_id": doors["porta2"]["id"], "schedule": "standard_office_hours"}],
              description="Personale del teatro")
    pul = cat("Pulizie", "teal", [{"target": "area", "target_id": via_consulta, "schedule": cleaning}])
    man = cat("Manutentore", "orange", [{"target": "site", "target_id": teatro, "schedule": "standard_always"}])
    osp = cat("Ospite", "purple", [{"target": "door", "target_id": doors["porta"]["id"], "schedule": "standard_office_hours"}],
              valid_days=1, description="Visitatori con tessera giornaliera")
    forn = cat("Fornitore", "gray", [{"target": "door", "target_id": doors["porta2"]["id"], "schedule": office}])
    art = cat("Artista", "pink", [{"target": "door", "target_id": doors["porta"]["id"], "schedule": evening}],
              description="Compagnie in scena questa stagione")
    call("PUT", "/api/default-category", json={"category_id": dip["id"]})

    # Persone
    def person(name, card, category, company="", notes="", valid_from=None, valid_to=None, group=""):
        body = {"name": name, "card": card, "category_id": category["id"] if category else 0, "company": company,
                "notes": notes, "group": group}
        if valid_from:
            body["valid_from"] = iso(valid_from)
        if valid_to:
            body["valid_to"] = iso(valid_to)
        return call("POST", "/api/persons", json=body)

    p = {}
    p["mario"] = person("Mario Rossi", "04a1b2c3d4e5f6", dip, "Amministrazione")
    p["giulia"] = person("Giulia Bianchi", "04b7c81a2f6680", dip, "Biglietteria")
    p["luca"] = person("Luca Ferrari", "04c2d93e11a4b0", man, "Ferrari Impianti Srl", "Manutenzione caldaia il primo lunedì del mese")
    p["francesca"] = person("Francesca Esposito", "04d3e04f22b5c1", pul, "Pulisan Cooperativa")
    p["alessandro"] = person("Alessandro Romano", "04e4f15033c6d2", dip, "Sala")
    p["chiara"] = person("Chiara Colombo", "04f5016144d7e3", osp, "Ospite della direzione",
                         valid_from=now - timedelta(hours=20), valid_to=now + timedelta(days=2))
    p["davide"] = person("Davide Ricci", "0406127255e8f4", forn, "Bevande Ricci", valid_from=now - timedelta(days=30),
                         valid_to=now + timedelta(days=5))
    p["sara"] = person("Sara Marino", "0417238366f905", dip, "Stagista", valid_from=now - timedelta(days=90),
                       valid_to=now - timedelta(days=1))
    p["matteo"] = person("Matteo Greco", "042834947700a6", osp, valid_from=now + timedelta(days=3),
                         valid_to=now + timedelta(days=4))
    p["elena"] = person("Elena Bruno", "04394a5a8811b7", dip, "Ufficio Stampa")
    p["simone"] = person("Simone Gallo", "044a5b6b9922c8", pul, "Pulisan Cooperativa", group="profilo_sempre")
    p["valentina"] = person("Valentina Conti", "045b6c7caa33d9", dip, "Biglietteria")
    p["andrea"] = person("Andrea De Luca", "046c7d8dbb44ea", man, "Ascensori Roma")
    p["roberto"] = person("Roberto Costa", "047d8e9ecc55fb", dip)
    p["federica"] = person("Federica Maria Giordano Lombardi", "048e9fafdd660c", art,
                           "Ufficio Tecnico e Progettazione Allestimenti Scenici",
                           "Accesso al palcoscenico solo con il direttore di scena.\nTelefono: 333 1234567")
    p["nicolo"] = person("Nicolò Barbieri", "049fa0b0ee771d", art, "Compagnia del Teatro Stabile")
    p["ilaria"] = person("Ilaria Moretti", "04a0b1c1ff882e", dip, "Sala")
    # Seconda tessera, sospesa
    elena = call("POST", f"/api/persons/{p['elena']['id']}/cards", json={"card": "04aab2c200993f"})
    call("PATCH", f"/api/cards/{elena['cards'][-1]['id']}", json={"enabled": False})
    call("PATCH", f"/api/cards/{p['alessandro']['cards'][0]['id']}", json={"enabled": False})
    # Senza tipologia
    db.set_person_category(p["roberto"]["id"], 0)
    # Tessera sparita dal controller
    gone = p["valentina"]["cards"][0]
    controller.credentials.pop(gone["token"], None) if gone.get("token") else None
    for token, cred in list(controller.credentials.items()):
        if any(d.get("Value") == "045b6c7caa33d9" for d in cred.get("IdData", [])):
            controller.credentials.pop(token)
    call("POST", "/api/sync")

    # Primo backup, bloccato
    first = call("POST", "/api/backups", json={"name": "Prima dei lavori al piano 2"})
    call("PUT", f"/api/backups/{first['id']}/lock", json={"locked": True})
    # Modifiche dopo il backup
    call("PATCH", f"/api/persons/{p['giulia']['id']}", json={"company": "Biglietteria e Accoglienza"})
    paolo = person("Paolo Fontana", "04bbc3d311aa40", forn, "Bevande Ricci")
    call("DELETE", f"/api/persons/{paolo['id']}")
    person("Beatrice Rinaldi", "04ccd4e422bb51", dip, "Sala")
    call("PUT", f"/api/categories/{forn['id']}", json={"name": "Fornitore", "color": "red", "valid_days": 0,
                                                       "description": "Consegne in cantina",
                                                       "rules": [{"target": "door", "target_id": doors["porta2"]["id"], "schedule": office}]})
    call("PUT", "/api/programming/doors/porta", json={"name": "Ingresso scala", "description": "Portone su strada",
                                                       "access_time": 8, "extended_access_time": 30,
                                                       "open_too_long_time": 20, "extended_open_too_long_time": 60,
                                                       "pre_alarm_time": 5})
    call("POST", "/api/backups", json={"name": ""})

    # Utenti
    def user(username, name, perms):
        call("POST", "/api/users", json={"username": username, "name": name, "perms": perms})

    roles = call("GET", "/api/users")["roles"]
    user("giulia.b", "Giulia Bianchi", roles["operatore"]["perms"])
    user("marco", "Marco Neri", roles["consultazione"]["perms"])
    user("portineria", "Portineria", roles["solo_stato"]["perms"])
    user("revisore", "Revisore Conti", roles["solo_registro"]["perms"])
    user("tecnico", "Tecnico Impianti", ["stato", "impianti", "backup"])
    user("ospite", "", [])

    # Registro: eventi degli ultimi giorni, oggi compreso
    ids = {k: v["id"] for k, v in p.items()}
    names = {k: v["name"] for k, v in p.items()}
    cards = {k: v["cards"][0]["number"] for k, v in p.items()}
    snaps = []

    def ev(at: datetime, kind: str, who: str = "", door: str = "porta", snapshot=False, **fields):
        row = {"ts": iso(at), "kind": kind, "door": door}
        if who:
            row.update(card=cards[who], person_id=ids[who], person_name=names[who])
        row.update(fields)
        if "source" not in row:
            row["source"] = {"concesso": "controller", "negato": "controller", "lettura": "lettore",
                             "sconosciuta": "lettore", "allarme": "porta"}.get(kind, "")
        event_id = db.add_event(**row)
        if snapshot:
            snaps.append((event_id, at, snapshot if isinstance(snapshot, str) else ""))
        return event_id

    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    regulars = ["mario", "giulia", "elena", "valentina", "ilaria", "roberto", "luca", "francesca"]
    for days_ago in range(6, 0, -1):
        day = today - timedelta(days=days_ago)
        for i, who in enumerate(regulars[: 4 + days_ago % 4]):
            ev(day + timedelta(hours=7 + i, minutes=5 * i + 3), "concesso", who)
        ev(day + timedelta(hours=8, minutes=50), "negato", "sara", detail="tessera scaduta", snapshot=True)
        ev(day + timedelta(hours=12, minutes=14), "uscita", source="Pulsante Portineria", detail="Pulsante Uscita · Aux 1")
        ev(day + timedelta(hours=19, minutes=30), "apertura_remota", source="Luca (Home Assistant)")
        if days_ago % 2:
            ev(day + timedelta(hours=21, minutes=2), "negato", "alessandro", detail="tessera sospesa")
            ev(day + timedelta(hours=10, minutes=11), "concesso", "davide", door="porta2")
        if days_ago == 3:
            ev(day + timedelta(hours=23, minutes=40), "allarme", detail="porta aperta troppo a lungo", door="porta2")
            ev(day + timedelta(hours=9, minutes=1), "concesso", "mario", recovered=True)
            ev(day + timedelta(hours=9, minutes=3), "concesso", "giulia", recovered=True)
        if days_ago == 2:
            ev(day + timedelta(hours=15, minutes=20), "citofono", source="Citofono Ingresso", detail="ha suonato", snapshot=True)
            ev(day + timedelta(hours=15, minutes=20, seconds=40), "citofono", source="Citofono Ingresso", detail="nessuna risposta")
            ev(day + timedelta(hours=16, minutes=2), "concesso", door="porta", person_name="Paolo Fontana (tolta dall'app)",
               card="04bbc3d311aa40")

    # Oggi: ore relative ad adesso, così tutto cade nelle ultime 24 ore e prima di adesso
    def ago(**kw):
        return now - timedelta(**kw)

    ev(ago(hours=23, minutes=10), "manomissione", door="", source="Controller Portineria", detail="coperchio del controller aperto")
    ev(ago(hours=9), "concesso", "francesca", door="porta")
    ev(ago(hours=8, minutes=40), "lettura", "alessandro", detail="tessera sospesa")
    ev(ago(hours=8, minutes=40), "negato", "alessandro", detail="tessera sospesa", snapshot=True)
    ev(ago(hours=8, minutes=5), "concesso", "mario")
    ev(ago(hours=8), "concesso", "giulia")
    ev(ago(hours=7, minutes=55), "concesso", "elena")
    ev(ago(hours=7, minutes=30), "concesso", "luca", door="porta2")
    ev(ago(hours=7, minutes=2), "sconosciuta", card="c0110a99")
    ev(ago(hours=7, minutes=2), "negato", card="c0110a99", detail="tessera non registrata", snapshot=True)
    ev(ago(hours=6, minutes=58), "negato", card="c0110a99", detail="tessera non registrata")
    ev(ago(hours=6, minutes=40), "uscita", source="Pulsante Portineria", detail="Pulsante Uscita · Aux 1 · più pressioni", snapshot=True)
    ev(ago(hours=6), "citofono", source="Citofono Ingresso", detail="ha suonato", snapshot=True)
    ev(ago(hours=5, minutes=59, seconds=50), "citofono", source="Citofono Ingresso", detail="risposta dopo 8 s")
    ev(ago(hours=5, minutes=59, seconds=30), "apertura_remota", source="App Hik-Connect (Citofono)",
       detail="20 s dopo la chiamata", snapshot=True)
    ev(ago(hours=5), "apertura_remota", source="Relè Citofono", detail="Relè Citofono · Aux 2")
    ev(ago(hours=4, minutes=30), "negato", "davide", door="porta2", detail="fuori fascia oraria")
    ev(ago(hours=4, minutes=12), "concesso", "chiara")
    ev(ago(hours=3, minutes=20), "negato", source="Pulsante Portineria",
       detail="Pulsante Uscita · Aux 1 · profilo di accesso non valido")
    ev(ago(hours=2, minutes=50), "allarme", detail="porta forzata", door="porta", snapshot="telecamera non disponibile (risposta 503 di Home Assistant)")
    ev(ago(hours=2, minutes=5), "manomissione", source="porta", detail="manomissione porta", door="porta2")
    ev(ago(hours=1, minutes=40), "apertura_remota", source="Automazione (Home Assistant)", detail="tempo esteso")
    for m in (35, 33, 31):
        ev(ago(minutes=m), "negato", "simone", detail="fuori fascia oraria", door="porta2")
    ev(ago(minutes=25), "lettura", "nicolo")
    ev(ago(minutes=25), "concesso", "nicolo")
    ev(ago(minutes=12), "sconosciuta", card="04ffee0011223344")
    ev(ago(minutes=12), "negato", card="04ffee0011223344", detail="tessera non registrata")
    ev(ago(minutes=4), "concesso", "valentina")
    ev(ago(minutes=2), "apertura_remota", source="Luca (Home Assistant)")
    # Tessere da registrare
    db.note_unknown_card("c0110a99", iso(ago(hours=7, minutes=10)))
    db.note_unknown_card("c0110a99", iso(ago(hours=7, minutes=2)))
    db.note_unknown_card("c0110a99", iso(ago(hours=6, minutes=58)))
    db.note_unknown_card("04ffee0011223344", iso(ago(minutes=12)))
    db.note_unknown_card("0a1b2c3d", iso(ago(days=3, hours=2)))
    # Istantanee
    SNAPSHOTS.mkdir(parents=True, exist_ok=True)
    for event_id, at, error in snaps:
        if error:
            db.set_event_snapshot(event_id, "", error)
            continue
        name = f"{event_id}_{at.strftime('%Y%m%d_%H%M%S')}.jpg"
        jpeg(SNAPSHOTS / name, f"Ingresso Scala A {at:%d/%m %H:%M:%S}", (40 + event_id % 5 * 20, 60, 80))
        db.set_event_snapshot(event_id, name)
    # Una notifica già vista
    listing = call("GET", "/api/notifications")
    alarm = next((i for i in listing["items"] if i["type"] == "door_alarm" and "Manomissione" in i["title"]), None)
    if alarm:
        call("POST", "/api/notifications/seen", json={"ids": [alarm["id"]]})
    print("SEED OK", flush=True)


class Server(uvicorn.Server):
    def install_signal_handlers(self) -> None:  # main thread keeps the default handlers
        pass


def main() -> None:
    config = uvicorn.Config(app, host="127.0.0.1", port=PORT, log_level="warning")
    server = Server(config)

    def after_start() -> None:
        while not server.started:
            time.sleep(0.1)
        if SEED:
            try:
                seed(f"http://127.0.0.1:{PORT}")
            except Exception:  # noqa: BLE001
                traceback.print_exc()
                print("SEED FAILED", flush=True)
        else:
            print("SEED SKIPPED (existing ui.db; use --fresh to reseed)", flush=True)
        print(f"READY http://127.0.0.1:{PORT}/", flush=True)

    threading.Thread(target=after_start, daemon=True).start()
    server.run()


if __name__ == "__main__":
    main()

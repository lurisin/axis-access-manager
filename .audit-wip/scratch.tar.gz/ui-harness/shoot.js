// Screenshots, console/network errors and WCAG contrast audit of every page and main dialog.
// Usage: node shoot.js [filter...]      (filters match shot names, e.g. "light-desktop-registro")
// Needs serve.py running on BASE (default http://127.0.0.1:8765/).
"use strict";
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

const BASE = process.env.BASE || "http://127.0.0.1:8765/";
const ROOT = "/tmp/claude-0/-home-user-axis-access-manager/a9d7407e-af26-5ce9-9e95-9f7c1abd8eb4/scratchpad/audit";
const OUT = path.join(ROOT, "ui-shots");
const REPORT = path.join(ROOT, "ui-harness", "report.json");
const FILTERS = process.argv.slice(2);
const USERS = {
  admin: { "X-Remote-User-Name": "luca", "X-Remote-User-Display-Name": "Luca Bianchi" },
  stato: { "X-Remote-User-Name": "portineria", "X-Remote-User-Display-Name": "Portineria" },
  registro: { "X-Remote-User-Name": "revisore", "X-Remote-User-Display-Name": "Revisore Conti" },
  operatore: { "X-Remote-User-Name": "giulia.b", "X-Remote-User-Display-Name": "Giulia Bianchi" },
  nessuno: { "X-Remote-User-Name": "ospite", "X-Remote-User-Display-Name": "Ospite" },
  tecnico: { "X-Remote-User-Name": "tecnico", "X-Remote-User-Display-Name": "Tecnico Impianti" },
};
fs.mkdirSync(OUT, { recursive: true });

async function api(p, user = "admin", method = "GET") {
  const r = await fetch(BASE + p, { method, headers: USERS[user] });
  return r.json();
}

// ---------- In-page contrast audit (WCAG 2.x) ----------
function contrastAudit(rootSelector) {
  const root = rootSelector ? document.querySelector(rootSelector) : document.body;
  if (!root) return [];
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 1;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  const parse = (str) => {
    let m = /^rgba?\(([^)]+)\)$/.exec(str);
    if (m) {
      const p = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
      return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
    }
    m = /^color\(srgb ([^)]+)\)$/.exec(str);
    if (m) {
      const p = m[1].split(/[\s/]+/).filter(Boolean).map(Number);
      return [p[0] * 255, p[1] * 255, p[2] * 255, p.length > 3 ? p[3] : 1];
    }
    ctx.clearRect(0, 0, 1, 1);
    ctx.fillStyle = "rgba(0,0,0,0)";
    ctx.fillStyle = str;
    ctx.fillRect(0, 0, 1, 1);
    const d = ctx.getImageData(0, 0, 1, 1).data;
    return [d[0], d[1], d[2], d[3] / 255];
  };
  const blend = (top, bottom) => {
    const a = top[3];
    return [top[0] * a + bottom[0] * (1 - a), top[1] * a + bottom[1] * (1 - a), top[2] * a + bottom[2] * (1 - a), 1];
  };
  const lum = (c) => {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
  };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const hex = (c) => "#" + c.slice(0, 3).map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
  const canvasBg = parse(getComputedStyle(document.body).backgroundColor);
  const background = (el) => {
    const layers = [];
    let gradient = false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.backgroundImage && cs.backgroundImage !== "none") gradient = true;
      const c = parse(cs.backgroundColor);
      if (c[3] > 0) { layers.push(c); if (c[3] >= 0.999) break; }
      if (n.tagName === "DIALOG") break;
    }
    let base = canvasBg[3] > 0 ? canvasBg : [255, 255, 255, 1];
    for (let i = layers.length - 1; i >= 0; i--) base = blend(layers[i], base);
    return { color: base, gradient };
  };
  const opacityOf = (el) => {
    let o = 1;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) o *= Number(getComputedStyle(n).opacity);
    return o;
  };
  const selector = (el) => {
    const parts = [];
    for (let n = el, i = 0; n && n.nodeType === 1 && i < 4; n = n.parentElement, i++) {
      let s = n.tagName.toLowerCase();
      if (n.id) s += "#" + n.id;
      const cls = [...n.classList].slice(0, 3).join(".");
      if (cls) s += "." + cls;
      parts.unshift(s);
      if (n.id) break;
    }
    return parts.join(" > ");
  };
  const out = [];
  const seen = new Set();
  const all = [root, ...root.querySelectorAll("*")];
  for (const el of all) {
    if (["SCRIPT", "STYLE", "OPTION", "SVG", "PATH", "TITLE"].includes(el.tagName.toUpperCase())) continue;
    if (el.closest("svg")) continue;
    const text = [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim();
    if (!text) continue;
    const rects = el.getClientRects();
    if (!rects.length) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility === "hidden") continue;
    if (el.closest(":disabled, [disabled], [aria-disabled=true]")) continue;
    const op = opacityOf(el);
    if (op < 0.05) continue;
    const fg0 = parse(cs.color);
    const bgInfo = background(el);
    const fg = blend([fg0[0], fg0[1], fg0[2], fg0[3] * op], bgInfo.color);
    const bg = op < 1 ? blend([bgInfo.color[0], bgInfo.color[1], bgInfo.color[2], op], canvasBg) : bgInfo.color;
    const value = ratio(fg, bg);
    const size = parseFloat(cs.fontSize);
    const weight = Number(cs.fontWeight) || 400;
    const large = size >= 24 || (size >= 18.66 && weight >= 700);
    const need = large ? 3 : 4.5;
    if (value >= need) continue;
    const key = `${el.className}|${hex(fg)}|${hex(bg)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      selector: selector(el),
      text: text.slice(0, 70),
      fg: hex(fg),
      bg: hex(bg),
      ratio: Math.round(value * 100) / 100,
      need,
      size,
      weight,
      opacity: Math.round(op * 100) / 100,
      gradient: bgInfo.gradient,
    });
  }
  return out;
}

// ---------- Shots ----------
async function settle(page, extra = 400) {
  await page.waitForLoadState("networkidle", { timeout: 6000 }).catch(() => {});
  await page.waitForFunction(() => !document.querySelector("#view .loading, #st-body .loading, #i-body .loading, #c-body .loading, #r-body .loading"), null, { timeout: 8000 }).catch(() => {});
  await page.waitForTimeout(extra);
}
const dialog = "dialog[open]";
async function openModal(page, selector, nth = 0) {
  const loc = page.locator(selector).nth(nth);
  await loc.click();
  await page.waitForSelector(dialog, { timeout: 8000 });
  await settle(page, 600);
}

function desktopShots(ctx) {
  const { persons, ctrl } = ctx;
  const pid = (name) => persons.find((p) => p.name.startsWith(name))?.id;
  return [
    { name: "dashboard", hash: "#cruscotto" },
    { name: "dashboard-modifica", hash: "#cruscotto", act: async (p) => { await p.click("#top-edit"); await settle(p); } },
    { name: "dlg-aggiungi-riquadro", hash: "#cruscotto", dialog: true, act: async (p) => { await p.click("#top-edit"); await settle(p); await openModal(p, "#dash-add"); } },
    { name: "dlg-evento-cruscotto", hash: "#cruscotto", dialog: true, act: async (p) => { await openModal(p, "[data-dash-events] [data-event]", 1); } },
    { name: "topbar-allarmi", hash: "#porte", act: async (p) => { await p.click("[data-pop=alarms]"); await p.waitForTimeout(400); } },
    { name: "topbar-guasti", hash: "#porte", act: async (p) => { await p.click("[data-pop=faults]"); await p.waitForTimeout(400); } },
    { name: "porte", hash: "#porte" },
    { name: "porta-dettaglio", hash: "#porte/1" },
    { name: "porta-dettaglio-cantina", hash: "#porte/2" },
    { name: "persone", hash: "#persone" },
    { name: "persone-filtro-sospese", hash: "#persone", act: async (p) => { await p.selectOption("#p-state", "sospese"); await p.waitForTimeout(300); } },
    { name: "dlg-scheda-persona", hash: `#persone/${pid("Federica")}`, dialog: true, wait: "#sheet[open]" },
    { name: "dlg-scheda-persona-personalizzato", hash: `#persone/${pid("Simone")}`, dialog: true, wait: "#sheet[open]" },
    { name: "dlg-scheda-persona-mancante", hash: `#persone/${pid("Valentina")}`, dialog: true, wait: "#sheet[open]" },
    { name: "dlg-scheda-persona-scaduta", hash: `#persone/${pid("Sara")}`, dialog: true, wait: "#sheet[open]" },
    { name: "dlg-nuova-persona", hash: "#persone", dialog: true, act: async (p) => { await openModal(p, "#p-new"); await p.check("#f-limited"); await p.waitForTimeout(200); } },
    { name: "dlg-accesso-persona", hash: `#persone/${pid("Simone")}`, dialog: true, act: async (p) => { await p.waitForSelector("#sheet[open]"); await settle(p); await p.click("#sheet [data-edit-access]"); await p.waitForSelector("#modal[open]"); await settle(p); } },
    { name: "dlg-conferma-elimina-persona", hash: `#persone/${pid("Mario")}`, dialog: true, act: async (p) => { await p.waitForSelector("#sheet[open]"); await settle(p); await p.click("#sheet [data-del-person]"); await p.waitForSelector("#modal[open]"); await settle(p); } },
    { name: "tipologie", hash: "#persone/tipologie" },
    { name: "dlg-tipologia", hash: "#persone/tipologie", dialog: true, act: async (p) => { await openModal(p, "[data-c-edit]", 0); } },
    { name: "da-registrare", hash: "#da-registrare" },
    { name: "dlg-assegna-tessera", hash: "#da-registrare", dialog: true, act: async (p) => { await openModal(p, "[data-assign]", 0); } },
    { name: "registro", hash: "#registro", pre: async (p) => { await p.evaluate(() => localStorage.setItem("aam-log-view", "controllo")); } },
    { name: "registro-negati", hash: "#registro", act: async (p) => { await p.click("[data-view=negati]"); await settle(p); } },
    { name: "registro-accessi", hash: "#registro", act: async (p) => { await p.click("[data-view=accessi]"); await settle(p); } },
    { name: "registro-allarmi", hash: "#registro", act: async (p) => { await p.click("[data-view=allarmi]"); await settle(p); } },
    { name: "registro-tutto", hash: "#registro", act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); } },
    { name: "registro-dettaglio", hash: "#registro", act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); await p.locator("#l-list [data-event]").filter({ has: p.locator("svg") }).first().click(); await settle(p); } },
    { name: "registro-dettaglio-remota", hash: "#registro", act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); await p.locator("#l-list [data-event]", { hasText: "Relè Citofono" }).first().click(); await settle(p); } },
    { name: "dlg-istantanea", hash: "#registro", dialog: true, act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); await p.locator("#l-list [data-event]").filter({ has: p.locator("svg") }).first().click(); await settle(p); await openModal(p, "#l-detail [data-snap]"); } },
    { name: "regole", hash: "#regole" },
    { name: "regole-nascoste", hash: "#regole", act: async (p) => { await p.check("#show-hidden"); await settle(p); } },
    { name: "dlg-fascia", hash: "#regole", dialog: true, act: async (p) => { await openModal(p, "[data-s-edit]", 2); } },
    { name: "dlg-fascia-predefinita", hash: "#regole", dialog: true, act: async (p) => { await openModal(p, "[data-s-edit]", 0); } },
    { name: "festivita", hash: "#regole/festivita" },
    { name: "impianti", hash: "#impianti" },
    { name: "strutture", hash: "#impianti/strutture" },
    { name: "dlg-nuova-area", hash: "#impianti/strutture", dialog: true, act: async (p) => { await openModal(p, "[data-area-new]", 0); } },
    { name: "backup", hash: "#impianti/backup" },
    { name: "dlg-backup-confronta", hash: "#impianti/backup", dialog: true, act: async (p) => { await openModal(p, "[data-cmp]", 0); await p.waitForFunction(() => !document.querySelector("#cmp-body .loading"), null, { timeout: 8000 }).catch(() => {}); await p.waitForTimeout(300); } },
    { name: "dlg-backup-confronta-attuale", hash: "#impianti/backup", dialog: true, act: async (p) => { const n = await p.locator("[data-cmp]").count(); await openModal(p, "[data-cmp]", n - 1); await p.selectOption("[name=other]", "attuale"); await p.waitForTimeout(600); await p.waitForFunction(() => !document.querySelector("#cmp-body .loading"), null, { timeout: 8000 }).catch(() => {}); await p.waitForTimeout(300); } },
    { name: "dlg-backup-ripristina", hash: "#impianti/backup", dialog: true, act: async (p) => { const n = await p.locator("[data-restore]").count(); await openModal(p, "[data-restore]", n - 1); } },
    { name: "dlg-backup-cosa-cambiera", hash: "#impianti/backup", dialog: true, act: async (p) => { const n = await p.locator("[data-restore]").count(); await openModal(p, "[data-restore]", n - 1); await p.click("#modal .dlg-foot .primary"); await p.waitForFunction(() => document.querySelector("#modal h2")?.textContent.includes("Cosa"), null, { timeout: 10000 }).catch(() => {}); await settle(p, 600); } },
    { name: "controller-schema", hash: `#impianti/c${ctrl}` },
    { name: "controller-schema-selezione", hash: `#impianti/c${ctrl}`, act: async (p) => { await p.click("[data-reader]"); await p.waitForTimeout(300); } },
    { name: "dlg-schema-ingresso", hash: `#impianti/c${ctrl}`, dialog: true, act: async (p) => { await p.click("[data-input='IO1']"); await p.waitForTimeout(200); await p.click("[data-input='IO1']"); await p.waitForSelector(dialog); await settle(p); } },
    { name: "dlg-schema-collegamento", hash: `#impianti/c${ctrl}`, dialog: true, act: async (p) => { await p.waitForSelector("[data-link]"); await openModal(p, "[data-link]", 0); } },
    { name: "controller-porte", hash: `#impianti/c${ctrl}/porte` },
    { name: "dlg-porta-nome-tempi", hash: `#impianti/c${ctrl}/porte`, dialog: true, act: async (p) => { await openModal(p, "[data-pd]", 0); } },
    { name: "dlg-porta-impostazioni-app", hash: `#impianti/c${ctrl}/porte`, dialog: true, act: async (p) => { await openModal(p, "[data-app-edit]", 0); } },
    { name: "controller-lettori", hash: `#impianti/c${ctrl}/lettori` },
    { name: "dlg-lettore", hash: `#impianti/c${ctrl}/lettori`, dialog: true, act: async (p) => { await openModal(p, "[data-pr]", 0); } },
    { name: "controller-telecamere", hash: `#impianti/c${ctrl}/telecamere` },
    { name: "dlg-telecamera", hash: `#impianti/c${ctrl}/telecamere`, dialog: true, act: async (p) => { await openModal(p, "[data-cam-edit]", 1); } },
    { name: "controller-videocitofoni", hash: `#impianti/c${ctrl}/citofoni` },
    { name: "dlg-videocitofono", hash: `#impianti/c${ctrl}/citofoni`, dialog: true, act: async (p) => { await openModal(p, "[data-ic-edit]", 0); } },
    { name: "controller-stato", hash: `#impianti/c${ctrl}/stato` },
    { name: "controller-storico", hash: `#impianti/c${ctrl}/storico` },
    { name: "controller-backup", hash: `#impianti/c${ctrl}/backup` },
    { name: "dlg-controller-ripristino", hash: `#impianti/c${ctrl}/backup`, dialog: true, act: async (p) => { await openModal(p, "[data-restore]", 0); } },
    { name: "controller-connessione", hash: `#impianti/c${ctrl}/connessione` },
    { name: "dlg-nuovo-controller", hash: "#impianti", dialog: true, act: async (p) => { await p.evaluate(() => { controllerEditor(); }); await p.waitForSelector(dialog); await settle(p); } },
    { name: "notifiche", hash: "#notifiche" },
    { name: "dlg-notifica-dettagli", hash: "#notifiche", dialog: true, act: async (p) => { await openModal(p, "[data-n-event]", 0); } },
    { name: "impostazioni", hash: "#impostazioni" },
    { name: "impostazioni-notifiche", hash: "#impostazioni/notifiche" },
    { name: "impostazioni-backup", hash: "#impostazioni/backup" },
    { name: "impostazioni-utenti", hash: "#impostazioni/utenti" },
    { name: "dlg-utente", hash: "#impostazioni/utenti", dialog: true, act: async (p) => { await openModal(p, "[data-u-edit='tecnico']"); } },
    { name: "dlg-nuovo-utente", hash: "#impostazioni/utenti", dialog: true, act: async (p) => { await openModal(p, "#u-new"); } },
    { name: "impostazioni-attivita", hash: "#impostazioni/attivita" },
    { name: "dlg-riprova", hash: "#persone", dialog: true, act: async (p) => { p.evaluate(() => { retryBox("errore del controller: il controller non risponde (ConnectTimeout)"); }); await p.waitForSelector("#retry[open]"); await p.waitForTimeout(300); } },
    { name: "dlg-importazione", hash: "#impostazioni", dialog: true, act: async (p) => {
      const csv = "nome;tessera;gruppo;valida_dal;valida_al;ditta;note;tipologia\nAnna Verdi;04de00112233;;;;Sala;;Dipendente\nMario Rossi;04a1b2c3d4e5f6;;;31/12/2026;Amministrazione;;Dipendente\nSenza Tessera;;;;;;;\nLuigi Neri;zz11;;;;;;";
      fs.writeFileSync(path.join(ROOT, "visual", "import.csv"), csv);
      await p.setInputFiles("#import-file", path.join(ROOT, "visual", "import.csv"));
      await p.waitForSelector(dialog); await settle(p);
    } },
    // Altri ruoli
    { name: "ruolo-solo-stato-cruscotto", hash: "#cruscotto", user: "stato" },
    { name: "ruolo-solo-registro", hash: "#registro", user: "registro" },
    { name: "ruolo-operatore-cruscotto", hash: "#cruscotto", user: "operatore" },
    { name: "ruolo-nessun-accesso", hash: "#cruscotto", user: "nessuno" },
    { name: "ruolo-personalizzato-impianti", hash: "#impianti", user: "tecnico" },
  ];
}

function mobileShots(ctx) {
  const { persons, ctrl } = ctx;
  const pid = (name) => persons.find((p) => p.name.startsWith(name))?.id;
  return [
    { name: "dashboard", hash: "#cruscotto" },
    { name: "menu-aperto", hash: "#cruscotto", act: async (p) => { await p.click("#nav-toggle"); await p.waitForTimeout(400); } },
    { name: "topbar-allarmi", hash: "#cruscotto", act: async (p) => { await p.click("[data-pop=alarms]"); await p.waitForTimeout(400); } },
    { name: "porte", hash: "#porte" },
    { name: "porta-dettaglio", hash: "#porte/1" },
    { name: "persone", hash: "#persone" },
    { name: "dlg-scheda-persona", hash: `#persone/${pid("Federica")}`, dialog: true, wait: "#sheet[open]" },
    { name: "da-registrare", hash: "#da-registrare" },
    { name: "registro", hash: "#registro", act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); } },
    { name: "dlg-evento", hash: "#registro", dialog: true, act: async (p) => { await p.click("[data-view=tutto]"); await settle(p); await openModal(p, "#l-list [data-event]", 2); } },
    { name: "notifiche", hash: "#notifiche" },
    { name: "regole", hash: "#regole" },
    { name: "impostazioni", hash: "#impostazioni" },
    { name: "impostazioni-backup", hash: "#impostazioni/backup" },
    { name: "backup", hash: "#impianti/backup" },
    { name: "controller-schema", hash: `#impianti/c${ctrl}` },
    { name: "controller-stato", hash: `#impianti/c${ctrl}/stato` },
    { name: "dlg-nuova-persona", hash: "#persone", dialog: true, act: async (p) => { await openModal(p, "#p-new"); await p.check("#f-limited"); await p.waitForTimeout(200); } },
  ];
}

function errorShots(ctx) {
  const { ctrl } = ctx;
  return [
    { scenario: "offline", name: "guasto-offline-cruscotto", hash: "#cruscotto" },
    { scenario: "offline", name: "guasto-offline-guasti", hash: "#cruscotto", act: async (p) => { await p.click("[data-pop=faults]"); await p.waitForTimeout(400); } },
    { scenario: "offline", name: "guasto-offline-impianti", hash: "#impianti" },
    { scenario: "offline", name: "guasto-offline-stato", hash: `#impianti/c${ctrl}/stato` },
    { scenario: "offline", name: "guasto-offline-schema", hash: `#impianti/c${ctrl}` },
    { scenario: "offline", name: "guasto-offline-notifiche", hash: "#notifiche" },
    { scenario: "changed", name: "guasto-cambiato-schema", hash: `#impianti/c${ctrl}` },
    { scenario: "changed", name: "guasto-cambiato-impianti", hash: "#impianti" },
  ];
}

async function run() {
  const persons = await api("api/persons");
  const installation = await api("api/installation");
  const ctx = { persons, ctrl: installation.controllers[0].id };
  const report = fs.existsSync(REPORT) && FILTERS.length ? JSON.parse(fs.readFileSync(REPORT, "utf8")) : {};
  const browser = await chromium.launch();
  const jobs = [];
  for (const theme of ["light", "dark"]) {
    desktopShots(ctx).forEach((s) => jobs.push({ ...s, theme, device: "desktop", viewport: { width: 1440, height: 900 } }));
    mobileShots(ctx).forEach((s) => jobs.push({ ...s, theme, device: "mobile", viewport: { width: 390, height: 844 }, mobile: true }));
  }
  for (const theme of ["light", "dark"]) {
    errorShots(ctx).forEach((s) => jobs.push({ ...s, theme, device: "desktop", viewport: { width: 1440, height: 900 } }));
  }
  let scenario = "normal";
  for (const job of jobs) {
    const id = `${job.theme}-${job.device}-${job.name}`;
    if (FILTERS.length && !FILTERS.some((f) => id.includes(f))) continue;
    const wanted = job.scenario || "normal";
    if (wanted !== scenario) {
      await fetch(BASE + `__harness/scenario/${wanted}`, { method: "POST" });
      scenario = wanted;
      await new Promise((r) => setTimeout(r, 800));
    }
    const context = await browser.newContext({
      viewport: job.viewport,
      deviceScaleFactor: 1,
      colorScheme: job.theme,
      locale: "it-IT",
      timezoneId: "Europe/Rome",
      isMobile: Boolean(job.mobile),
      hasTouch: Boolean(job.mobile),
      extraHTTPHeaders: USERS[job.user || "admin"],
    });
    const page = await context.newPage();
    const log = { console: [], pageErrors: [], failed: [], http: [] };
    page.on("console", (m) => { if (["error", "warning"].includes(m.type())) log.console.push(`${m.type()}: ${m.text()}`); });
    page.on("pageerror", (e) => log.pageErrors.push(String(e && e.stack || e)));
    page.on("requestfailed", (r) => log.failed.push(`${r.method()} ${r.url()} ${r.failure()?.errorText}`));
    page.on("response", (r) => { if (r.status() >= 400) log.http.push(`${r.status()} ${r.request().method()} ${r.url()}`); });
    try {
      await page.goto(BASE, { waitUntil: "domcontentloaded" });
      if (job.pre) { await job.pre(page); }
      await settle(page, 200);
      await page.evaluate((h) => { location.hash = h; }, job.hash);
      await settle(page);
      if (job.wait) { await page.waitForSelector(job.wait, { timeout: 8000 }); await settle(page, 500); }
      if (job.act) await job.act(page);
      await page.waitForTimeout(250);
      if (process.env.SCHEMA_DEBUG) console.log(await page.evaluate(() => { const s = document.querySelector("#schema"); if (!s) return "no schema"; const b = s.getBoundingClientRect(); const r = document.querySelector("[data-reader]").getBoundingClientRect(); const p = document.querySelector("#sch-svg path"); return `box.left=${b.left} W=${b.width} readerRight=${r.right - b.left} path=${p && p.getAttribute("d").slice(0, 30)} innerW=${innerWidth}`; }));
      const file = path.join(OUT, `${id}.png`);
      await page.screenshot({ path: file, fullPage: true, animations: "disabled" });
      let contrast = [];
      const open = await page.$("dialog[open]");
      if (job.dialog && open) {
        const dlgId = await open.evaluate((d) => d.id);
        await open.screenshot({ path: path.join(OUT, `${id}-el.png`), animations: "disabled" }).catch(() => {});
        contrast = await page.evaluate(contrastAudit, `#${dlgId}`);
      } else {
        contrast = await page.evaluate(contrastAudit, null);
      }
      const texts = await page.evaluate(() => {
        // Raw technical values shown to users
        const body = document.body.innerText;
        const hits = [];
        for (const re of [/\bundefined\b/g, /\bnull\b/g, /\bNaN\b/g, /\[object Object\]/g, /\bPT\d+[SMH]\b/g, /\bInvalid Date\b/g]) {
          const m = body.match(re);
          if (m) hits.push(`${re}: ${m.length}`);
        }
        return hits;
      });
      report[id] = { ...log, contrast, rawValues: texts, title: await page.title() };
      console.log(`${id}: ${contrast.length} contrast, ${log.console.length} console, ${log.pageErrors.length} pageerr, ${log.failed.length} failed, ${log.http.length} http, raw ${texts.join(" ")}`);
    } catch (err) {
      report[id] = { ...log, error: String(err) };
      console.log(`${id}: ERROR ${err}`);
      await page.screenshot({ path: path.join(OUT, `${id}-ERROR.png`), fullPage: true }).catch(() => {});
    }
    await context.close();
  }
  if (scenario !== "normal") await fetch(BASE + "__harness/scenario/normal", { method: "POST" });
  await browser.close();
  fs.writeFileSync(REPORT, JSON.stringify(report, null, 1));
}

run().catch((e) => { console.error(e); process.exit(1); });

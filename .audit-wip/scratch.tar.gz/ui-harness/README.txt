UI harness - Axis Access Manager 0.21.7 (rendered UI audit)
============================================================

Everything here is outside the repository (/home/user/axis-access-manager is only read).

Files
  serve.py     real FastAPI app (create_app) on tests/conftest.FakeController, TZ Europe/Rome,
               no Supervisor token, AAM_SCHEDULED_BACKUPS=0. MQTT is simulated as connected
               (FakeMonitor), Home Assistant is simulated (FakeHA: 4 cameras, JPEG snapshots).
               On a fresh database it seeds through the HTTP API (+ Database for events):
               sites/areas, controller with 2 doors, 3 programmed inputs, 4 schedules (1 hidden),
               Italian holidays + 2 custom, 6 tipologie, 19 persons (suspended, expiring, expired,
               future, custom access, missing on controller, no tipologia), unknown cards,
               ~150 events of every kind over 7 days (snapshots, snapshot error, recovered),
               7 app users (every role + custom), 3 backups (1 locked).
               Extra endpoint POST /__harness/scenario/{offline|changed|normal} switches the plant
               into error states (controller unreachable + MQTT lost / controller replaced).
  shoot.js     Playwright (chromium) screenshots + console/page errors + failed requests + HTTP >= 400
               + raw-value scan + WCAG 2.x contrast audit of every page/dialog, light and dark,
               desktop 1440x900 and mobile 390x844, plus error scenarios and other roles.
               Output: ../ui-shots/<theme>-<desktop|mobile>-<name>.png (full page) and
               <name>-el.png (dialog element only); report: ./report.json
  report.json  per shot: console, pageErrors, failed, http, rawValues, contrast[]

Commands
  cd /tmp/claude-0/-home-user-axis-access-manager/a9d7407e-af26-5ce9-9e95-9f7c1abd8eb4/scratchpad/audit/ui-harness

  # start (fresh seed) in the background, pid in server.pid, log in server.log
  (echo $$ > server.pid; exec python3 serve.py 8765 --fresh) > server.log 2>&1 &
  # wait until the log says READY
  until grep -q READY server.log; do sleep 1; done; tail -3 server.log

  # re-use the existing ui.db (no reseed):   python3 serve.py 8765
  # other port:                              python3 serve.py 8800 --fresh ; BASE=http://127.0.0.1:8800/ node shoot.js

  # all screenshots + audit (about 15 minutes)
  node shoot.js
  # only some shots (substring match on "<theme>-<device>-<name>")
  node shoot.js light-desktop-registro dark-mobile-dashboard
  # debug the schema wires geometry
  SCHEMA_DEBUG=1 node shoot.js light-desktop-controller-schema

  # contrast summary
  python3 -c "import json; r=json.load(open('report.json')); [print(k, c['ratio'], c['fg'], c['bg'], c['text']) for k,v in r.items() for c in v.get('contrast',[]) if c['opacity']>=0.99]"

  # stop
  kill $(cat server.pid)

Ad-hoc probes used during the audit (in ../visual/): probe.js (evaluate an expression on a page),
probe2.js (schema wires after toggling the side menu), overflow.js (horizontal overflow at 390/360 px),
savebar.js (schema save bar in both themes).

Notes
  - Headless Chromium shows date/time inputs as mm/dd/yyyy and 12h AM/PM regardless of the page
    locale: that is the test browser, not the app.
  - The fake controller lists no IO2/EXTERNAL_TAMPER inputs, so the Relè Citofono programmed on IO2
    does not appear in the schema.
  - "Sempre" tipologia is created by the app itself (adopt_groups) from the fake controller's
    pre-existing profile "profilo_sempre".

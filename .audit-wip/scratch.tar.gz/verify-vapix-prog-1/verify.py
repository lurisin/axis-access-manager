import asyncio, os, re, tempfile
from pathlib import Path
import httpx
from fastapi.testclient import TestClient
from app.config import parse_options, normalize_host
from app.main import create_app
from app.vapix import A1210Client, VapixError

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
pat = re.compile(r"^[A-Za-z0-9.\-:\[\]]+$")
for h in ["2001:db8::50", "fe80::1", "192.168.1.50:443:", "192.168.1.50::443", "[2001:db8::50]", "192.168.1.50:8443", "[fe80::1]:443", "a1210.local:abc"]:
    h2 = normalize_host(h)
    try:
        A1210Client(h2, "u", "p")
        r = "ok"
    except Exception as e:
        r = f"{type(e).__name__}: {e} (HTTPError? {isinstance(e, httpx.HTTPError)})"
    print(repr(h2), bool(pat.match(h2)), r)

async def fp():
    c = A1210Client("[::1]", "u", "p")
    try:
        await c.certificate_fingerprint()
    except VapixError as e:
        print("fingerprint [::1]:", e)
asyncio.run(fp())

tmp = Path(tempfile.mkdtemp()); db_path = tmp / "aam.db"
settings = parse_options({})
app = create_app(settings, allow_any_client=True, db_path=db_path)
with TestClient(app, raise_server_exceptions=False) as client:
    r = client.post("/api/controllers/test", json={"host": "2001:db8::50", "username": "root", "password": "x", "verify_ssl": False})
    print("test:", r.status_code, r.text[:100])
    data = {"name": "A1210", "host": "2001:db8::50", "username": "root", "password": "x", "mqtt_topic_prefix": "accessi"}
    r = client.post("/api/controllers", json=data)
    print("save:", r.status_code, r.text[:80])
    cid = client.app.state.db.list_controllers()[0]["id"]
    print("raw_controller closed?", client.app.state.raw_controller._client.is_closed)
    r = client.get("/api/controllers")
    print("list:", r.status_code, r.text[:200])
    # correction in same session
    data["host"] = "192.168.1.50"
    r = client.put(f"/api/controllers/{cid}", json=data)
    print("correct:", r.status_code, r.text[:80])
    print("host now:", client.app.state.settings.a1210_host, "closed?", client.app.state.raw_controller._client.is_closed)
app = create_app(settings, allow_any_client=True, db_path=db_path)
with TestClient(app, raise_server_exceptions=False) as client:
    print("restart after correction:", client.get("/api/summary").status_code)

# legacy option
tmp = Path(tempfile.mkdtemp()); db_path = tmp / "aam.db"
settings = parse_options({"a1210_host": "fe80::1", "a1210_username": "root", "a1210_password": "x"})
print("legacy host:", settings.a1210_host)
app = create_app(settings, allow_any_client=True, db_path=db_path)
try:
    with TestClient(app, raise_server_exceptions=False) as client:
        print("legacy start ok")
except Exception as e:
    print("LEGACY START FAILED:", type(e).__name__, e)

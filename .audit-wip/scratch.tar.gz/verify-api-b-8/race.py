"""Comando "Apri" di Home Assistant ancora in corso quando una modifica a porte o controller fa reload_runtime:
il client chiuso dà RuntimeError, che on_command non gestisce. La porta non si apre e nel registro non resta niente."""
import asyncio
import json
import logging
import os
import tempfile
from pathlib import Path

import httpx

os.environ.pop("SUPERVISOR_TOKEN", None)

import app.main as main  # noqa: E402
from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.vapix import A1210Client  # noqa: E402

logging.basicConfig(level=logging.CRITICAL)
access = []


async def handler(request):
    body = json.loads(request.content or b"{}")
    method = next(iter(body), "") if request.url.path.startswith("/vapix") else body.get("method", "")
    if request.url.path.endswith("basicdeviceinfo.cgi"):
        return httpx.Response(200, json={"data": {"propertyList": {"ProdNbr": "A1210", "SerialNumber": "X"}}})
    if request.url.path.endswith(".cgi"):
        return httpx.Response(200, json={"data": {}})
    if method == "tdc:GetDoorState":
        return httpx.Response(200, json={"DoorState": {"DoorMode": "Locked", "DoorPhysicalState": "Closed"}})
    if method == "tdc:AccessDoor":
        access.append(body)
        return httpx.Response(200, json={})
    if method == "tdc:GetDoorInfoList":
        return httpx.Response(200, json={"DoorInfo": [{"token": "porta", "Name": "Porta"}]})
    key = {"pacsaxis:GetCredentialList": "Credential", "axudb:GetUserList": "User",
           "pacsaxis:GetAccessPointList": "AccessPoint", "pacsaxis:GetAccessProfileList": "AccessProfile",
           "pacsaxis:GetAccessControllerList": "AccessController", "axsch:GetScheduleList": "Schedule"}.get(method)
    if key:
        return httpx.Response(200, json={key: []})
    if method == "axlog:FetchEvents":
        return httpx.Response(200, json={"Event": [], "More": False})
    return httpx.Response(200, json={})




async def scenario():
    tmp = Path(tempfile.mkdtemp())
    settings = parse_options({"a1210_host": "127.0.0.1:9", "a1210_username": "root", "a1210_password": "x",
                              "door_token": "porta", "mqtt_topic_prefix": "accessi/x",
                              "mqtt_host": "127.0.0.1", "mqtt_port": 9})
    app = main.create_app(settings, allow_any_client=True, db_path=tmp / "a.db",
                          home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
    async with app.router.lifespan_context(app):
        mon = app.state.monitor
        mon.door_modes["porta"] = "Locked"

        async def slow_presser():
            await asyncio.sleep(0.3)
            return "Luca"
        app.state.ha.button_presser = slow_presser
        # Il monitor riceve il comando come dal broker
        mon._command(b"apri")
        task = next(iter(mon._tasks))
        await asyncio.sleep(0.05)
        await main.reload_runtime(app)   # salvataggio di una porta mentre il comando aspetta HA
        await asyncio.sleep(0.5)
        print("task finito:", task.done(), "| eccezione:", repr(task.exception()) if task.done() else None)
        print("AccessDoor inviati:", len(access), "| aperture nel registro:",
              len(app.state.db.list_events(kind="apertura_remota")))


asyncio.run(scenario())

// Repro I: bindCategory propone la durata di una tipologia ma non la toglie scegliendone una senza durata
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  const api = async (method, path, data) => { const r = await page.request.fetch(base + path, { method, data }); return [r.status(), await r.json()]; };
  const [, ospiti] = await api("POST", "/api/categories", { name: "Ospiti", color: "orange", valid_days: 1, rules: [{ target: "door", target_id: 1, schedule: "standard_always" }] });
  const [, cats] = await api("GET", "/api/categories");
  console.log("tipologie:", cats.map((c) => `${c.id}:${c.name} durata ${c.valid_days}g${c.default ? " (predefinita)" : ""}`));
  const sempre = cats.find((c) => c.default);
  await page.goto(base + "/#persone");
  await page.waitForSelector("#p-new");
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=category]");
  await page.fill("#modal [name=name]", "Dipendente Rossi");
  await page.fill("#modal [name=card]", "04E1E2E3");
  // Scorrendo le tipologie (anche con le frecce della tastiera ogni voce fa scattare "change") si passa da Ospiti
  await page.selectOption("#modal [name=category]", String(ospiti.id));
  await page.selectOption("#modal [name=category]", String(sempre.id));
  console.log("dopo aver scelto di nuovo", sempre.name, ": Validità Limitata =", await page.isChecked("#modal #f-limited"), "fino al", await page.inputValue("#modal [name=valid_to]"));
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(1200);
  const [, persons] = await api("GET", "/api/persons");
  const p = persons.find((x) => x.name === "Dipendente Rossi");
  console.log("persona creata:", p.name, "tipologia", p.category_id, "valid_to", p.cards[0].valid_to);
  await browser.close();
})();

const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("#dash", { timeout: 10000 });
  console.log("title:", await page.textContent("#page-title"));
  console.log("widgets:", await page.$$eval(".dw[data-w]", (els) => els.map((e) => e.dataset.w)));
  console.log("errors:", errors);
  await browser.close();
})();

// Repro A: una risposta lenta della pagina precedente sovrascrive la pagina nuova
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  await ctl({ delay: {}, offline: [] });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("#dash");
  // Controller lento (offline: ogni chiamata VAPIX aspetta il timeout di 10 s; qui 3 s)
  await ctl({ delay: { list_access_points: 3 } });
  await page.evaluate(() => { location.hash = "#porte/1"; });
  await page.waitForTimeout(600);
  // L'utente si stanca dello spinner e va al Registro
  await page.click('#nav a[data-route="registro"]');
  await page.waitForSelector("#l-list", { timeout: 5000 });
  const before = { hash: await page.evaluate(() => location.hash), title: await page.textContent("#page-title"), hasLog: !!(await page.$("#l-list")) };
  await page.waitForTimeout(3500);
  const after = {
    hash: await page.evaluate(() => location.hash),
    title: await page.textContent("#page-title"),
    docTitle: await page.title(),
    navActive: await page.$eval("#nav a.active", (a) => a.dataset.route),
    hasLog: !!(await page.$("#l-list")),
    hasDoorDetail: !!(await page.$("#d-events")) || (await page.textContent("#view")).includes("Dispositivi"),
  };
  console.log("subito dopo il clic su Registro:", before);
  console.log("dopo l'arrivo della risposta lenta:", after);
  // Il refresh periodico del registro non ripara: refreshLog esce perché #l-list non c'è più
  console.log("errors:", errors);
  await ctl({ delay: {}, offline: [] });
  await browser.close();
})();

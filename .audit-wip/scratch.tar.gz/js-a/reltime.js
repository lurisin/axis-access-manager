// relTime copiata da index.html (righe 734-749) con "adesso" iniettabile
const fmtTime = (iso) => iso ? new Date(iso).toLocaleTimeString("it-IT", {hour: "2-digit", minute: "2-digit"}) : "";
const fmtDate = (iso) => iso ? new Date(iso).toLocaleDateString("it-IT", {day: "numeric", month: "short", year: "numeric"}) : "";
function relTime(iso, nowIso) {
  if (!iso) return "";
  const d = new Date(iso), now = new Date(nowIso);
  const diff = (now - d) / 1000;
  if (diff < 60) return "adesso";
  if (diff < 3600) return `${Math.floor(diff / 60)} min fa`;
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (d >= startToday) return `oggi ${fmtTime(iso)}`;
  if (d >= new Date(startToday - 86400000)) return `ieri ${fmtTime(iso)}`;
  if (diff < 6 * 86400) return d.toLocaleDateString("it-IT", {weekday: "long"}) + " " + fmtTime(iso);
  return fmtDate(iso);
}
const now = "2026-10-28T10:00:00+01:00";
console.log("evento 40 min nel futuro (orologio del controller avanti):", relTime("2026-10-28T10:40:00+01:00", now));
console.log("evento 3 ore nel futuro:", relTime("2026-10-28T13:00:00+01:00", now));
console.log("evento domani:", relTime("2026-10-29T09:00:00+01:00", now));
console.log("DST primavera, lunedì 30/3 10:00, evento sabato 28/3 23:30:", relTime("2026-03-28T23:30:00+01:00", "2026-03-30T10:00:00+02:00"));

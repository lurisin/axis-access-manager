// Repro K/L/M/N: testi e filtri delle pagine Porte
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  const ev = (data) => page.request.post(base + "/__event", { data });
  const now = Date.now();
  await ev({ ts: new Date(now - 300000).toISOString(), kind: "concesso", door: "porta", card: "04A1", person_name: "Anna" });
  await ev({ ts: new Date(now - 240000).toISOString(), kind: "negato", door: "porta", card: "04A2", detail: "fuori fascia" });
  await ev({ ts: new Date(now - 200000).toISOString(), kind: "manomissione", door: "porta", detail: "lettore manomesso" });
  await ev({ ts: new Date(now - 60000).toISOString(), kind: "uscita", door: "porta", source: "Pulsante Uscita" });
  // Cruscotto con il riquadro Porte (layout salvato)
  await page.request.put(base + "/api/dashboard/layout", { data: { widgets: [{ type: "porte", size: 2, height: 3 }] } });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector(".dw-porte .tile");
  console.log("riquadro porta:", (await page.textContent(".dw-porte .tile")).replace(/\s+/g, " ").trim());
  await page.goto(base + "/#porte");
  await page.waitForSelector(".door-row");
  console.log("elenco porte:", (await page.textContent(".door-row .meta")).replace(/\s+/g, " ").trim());
  await page.goto(base + "/#porte/1");
  await page.waitForSelector("#d-events");
  const kpis = await page.$$eval(".grid.kpi .card", (cs) => cs.map((c) => c.textContent.replace(/\s+/g, " ").trim()));
  console.log("KPI dettaglio porta:", kpis);
  // Filtri lasciati da una ricerca precedente nel registro
  await page.evaluate(() => { logFilters.q = "Mario"; });
  await page.click("#d-log");
  await page.waitForSelector("#l-list");
  await page.waitForTimeout(800);
  console.log("Apri nel Registro → vista:", await page.$eval(".segmented a.active", (a) => a.textContent), "| ricerca:", await page.inputValue("#l-q"), "| elenco:", (await page.textContent("#l-list")).replace(/\s+/g, " ").trim().slice(0, 80));
  await browser.close();
})();

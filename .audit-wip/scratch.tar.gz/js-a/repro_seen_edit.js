// Repro C: "Segna Tutti Come Visti" dalla barra in alto mentre si modifica il cruscotto: modifiche perse senza avviso
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  await page.request.post(base + "/__event", { data: { ts: new Date().toISOString(), kind: "allarme", door: "porta", detail: "porta forzata" } });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("#dash");
  await page.waitForSelector('#top-status [data-pop="alarms"]');
  const before = await page.$$eval(".dw[data-w]", (els) => els.map((e) => e.dataset.w));
  await page.click("#top-edit");
  await page.waitForSelector("#dash.editing");
  // Toglie due riquadri: modifica non salvata
  await page.click('.dw[data-w="settimana"] [data-remove]');
  await page.click('.dw[data-w="persone"] [data-remove]');
  const draft = await page.$$eval(".dw[data-w]", (els) => els.map((e) => e.dataset.w));
  await page.click('#top-status [data-pop="alarms"]');
  await page.waitForSelector("#top-pop:not([hidden]) [data-pop-seen]");
  await page.click("#top-pop [data-pop-seen]");
  await page.waitForTimeout(1500);
  const after = {
    editing: !!(await page.$("#dash.editing")),
    modalOpen: await page.$eval("#modal", (d) => d.open),
    widgets: await page.$$eval(".dw[data-w]", (els) => els.map((e) => e.dataset.w)),
  };
  console.log("prima:", before.length, "riquadri; bozza:", draft.length, "riquadri (tolti settimana e persone)");
  console.log("dopo Segna Tutti Come Visti:", after);
  const [saved] = [await (await page.request.get(base + "/api/dashboard/layout")).json()];
  console.log("layout salvato:", saved.widgets);
  await browser.close();
})();

// Repro E: persona senza tipologia (importata dal controller): la finestra Accesso preseleziona la tipologia
// predefinita senza "Nessuna"; salvando solo la validità cambiano tipologia e profilo sul controller
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const api = async (method, path, data) => { const r = await page.request.fetch(base + path, { method, data }); return [r.status(), await r.json()]; };
  await page.request.post(base + "/__ctl", { data: { delay: {}, offline: [] } });
  // Tipologia predefinita diversa dal profilo della persona importata
  const [, cat] = await api("POST", "/api/categories", { name: "Ospiti", color: "orange", valid_days: 0, rules: [{ target: "door", target_id: 1, schedule: "standard_always" }] });
  await api("PUT", "/api/default-category", { category_id: cat.id });
  // Tessera aggiunta sul controller dopo l'avvio (script di HA, altro strumento): la sincronizzazione la importa
  await page.request.post(base + "/__existing", { data: { user: "utente_luca", name: "Luca Neri", card: "04cc", profile: "profilo_sempre" } });
  const [, sync] = await api("POST", "/api/sync");
  const [, persons] = await api("GET", "/api/persons");
  const mario = persons.find((p) => p.name === "Luca Neri");
  console.log("importata dal controller:", mario.name, "category_id", mario.category_id, "profilo", mario.cards[0].access_profile);
  await page.goto(base + "/#persone/" + mario.id);
  await page.waitForSelector("#sheet[open] [data-edit-access]");
  console.log("scheda: Tipologia =", await page.$eval("#sheet dl.props dd", (e) => e.textContent.trim()), "| avviso personalizzato:", !!(await page.$("#sheet [data-align]")));
  await page.click("#sheet [data-edit-access]");
  await page.waitForSelector("#modal[open] [name=category]");
  console.log("select tipologia:", await page.$$eval("#modal [name=category] option", (o) => o.map((x) => `${x.value}:${x.textContent}${x.selected ? "*" : ""}`)));
  console.log("testo sotto:", await page.$eval("#modal .dlg-body p.hint:last-of-type", (e) => e.textContent));
  // L'operatore vuole solo dare una scadenza
  await page.check("#modal #f-limited");
  await page.click('#modal [data-preset="30"]');
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(1500);
  const [, after] = await api("GET", "/api/persons/" + mario.id);
  console.log("dopo il salvataggio: category_id", after.category_id, "profilo", after.cards[0].access_profile);
  await browser.close();
})();

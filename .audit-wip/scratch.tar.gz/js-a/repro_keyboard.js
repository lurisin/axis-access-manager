// Repro P: righe evento con role=button e tabindex=0 nel cruscotto e nella porta: Invio non apre il dettaglio
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  await page.request.post(base + "/__event", { data: { ts: new Date().toISOString(), kind: "concesso", door: "porta", card: "04A1", person_name: "Anna" } });
  await page.request.delete(base + "/api/dashboard/layout");
  const check = async (hash, sel) => {
    await page.goto(base + hash);
    await page.waitForSelector(sel);
    await page.focus(sel);
    const role = await page.$eval(sel, (r) => `${r.getAttribute("role")}/${r.getAttribute("tabindex")}`);
    await page.keyboard.press("Enter");
    await page.waitForTimeout(400);
    const enter = await page.$eval("#modal", (d) => d.open);
    await page.keyboard.press("Escape");
    await page.click(sel);
    await page.waitForTimeout(400);
    const click = await page.$eval("#modal", (d) => d.open);
    await page.keyboard.press("Escape");
    return { hash, role, opensWithEnter: enter, opensWithClick: click };
  };
  console.log(await check("/#cruscotto", "[data-dash-events] [data-event]"));
  console.log(await check("/#porte/1", "#d-events [data-event]"));
  await browser.close();
})();

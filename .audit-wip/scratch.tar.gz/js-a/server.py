"""Harness: avvia l'add-on con un FakeController controllabile, per guidare la pagina con Playwright.

Uso (dalla radice del repo):
  PYTHONPATH=axis_access_manager:tests python3 <questo file> PORT DBPATH
Controllo: POST /__ctl {"delay": {"list_access_points": 4}, "offline": ["list_access_profiles"]}
"""

import asyncio
import os
import sys

import uvicorn
from fastapi import Request

from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError
from conftest import FakeController

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

CTL = {"delay": {}, "offline": set()}


class SlowController(FakeController):
    pass


def _wrap(name):
    orig = getattr(FakeController, name)

    async def method(self, *args, **kwargs):
        delay = CTL["delay"].get(name, 0)
        if delay:
            await asyncio.sleep(delay)
        if name in CTL["offline"]:
            raise VapixError("il controller non risponde (ConnectTimeout)")
        return await orig(self, *args, **kwargs)

    return method


for _name in (
    "list_access_points",
    "list_idpoints",
    "list_access_profiles",
    "list_schedules",
    "set_credential",
    "get_credentials",
    "set_user",
    "device_info",
):
    setattr(SlowController, _name, _wrap(_name))


def main():
    port = int(sys.argv[1])
    db_path = sys.argv[2]
    settings = parse_options(
        {
            "a1210_host": "a1210.local",
            "door_token": "porta",
            "access_profile": "profilo_sempre",
            "mqtt_topic_prefix": "accessi/x",
        }
    )
    controller = SlowController()
    if os.environ.get("EXISTING"):
        controller.add_existing("utente_mario", "Mario Rossi", "04aa")
    app = create_app(settings, allow_any_client=True, controller=controller, db_path=db_path, scheduled_backups=False)

    async def ctl(request: Request) -> dict:
        body = await request.json()
        if "delay" in body:
            CTL["delay"] = body["delay"]
        if "offline" in body:
            CTL["offline"] = set(body["offline"])
        return {"ok": True, "delay": CTL["delay"], "offline": sorted(CTL["offline"])}

    async def add_event(request: Request) -> dict:
        body = await request.json()
        return {"id": request.app.state.db.add_event(**body)}

    async def existing(request: Request) -> dict:
        body = await request.json()
        token = controller.add_existing(body["user"], body["name"], body["card"])
        if body.get("profile"):
            controller.credentials[token]["CredentialAccessProfile"][0]["AccessProfile"] = body["profile"]
        return {"token": token}

    app.add_api_route("/__existing", existing, methods=["POST"])
    app.add_api_route("/__ctl", ctl, methods=["POST"])
    app.add_api_route("/__event", add_event, methods=["POST"])
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    main()

#!/bin/bash
# start.sh PORT DBNAME [EXTRA_ENV...]
S=/tmp/claude-0/-home-user-axis-access-manager/a9d7407e-af26-5ce9-9e95-9f7c1abd8eb4/scratchpad/audit/js-a
PORT=$1; NAME=$2
if [ -f $S/pid.$PORT ]; then kill $(cat $S/pid.$PORT) 2>/dev/null; sleep 0.5; fi
rm -f $S/$NAME.db*
cd /home/user/axis-access-manager
EXISTING=$EXISTING PYTHONPATH=axis_access_manager:tests nohup timeout 1800 python3 $S/server.py $PORT $S/$NAME.db > $S/server.$PORT.log 2>&1 &
echo $! > $S/pid.$PORT
for i in $(seq 1 40); do curl -s -o /dev/null http://127.0.0.1:$PORT/api/me && echo "up on $PORT" && exit 0; sleep 0.5; done
echo "server failed"; tail -20 $S/server.$PORT.log; exit 1

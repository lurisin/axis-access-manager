// Repro B2: tipologie non caricate (controller offline) → la finestra Accesso propone "Nessuna" e salvando
// la persona perde la tipologia e riceve il profilo predefinito
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  const api = async (method, path, data) => { const r = await page.request.fetch(base + path, { method, data }); return [r.status(), await r.json()]; };
  await ctl({ delay: {}, offline: [] });
  // Tipologia "Ospiti" con un suo profilo e una persona in quella tipologia
  const [st, cat] = await api("POST", "/api/categories", { name: "Ospiti", color: "orange", valid_days: 0, rules: [{ target: "door", target_id: 1, schedule: "standard_always" }] });
  console.log("tipologia:", st, cat.id ?? cat, cat.group_token);
  const [, person] = await api("POST", "/api/persons", { name: "Ospite Verdi", card: "04B1B2C3", category_id: cat.id });
  console.log("persona:", person.id, "category_id", person.category_id, "profilo", person.cards[0].access_profile);
  // Controller che non risponde mentre si apre la scheda (anche la rilettura forzata fallisce)
  await ctl({ offline: ["list_access_profiles"] });
  await page.goto(base + "/#persone/" + person.id);
  await page.waitForSelector("#sheet[open] [data-edit-access]");
  console.log("scheda: Tipologia =", await page.$eval("#sheet dl.props dd", (e) => e.textContent.trim()));
  // Il controller torna: l'operatore allunga la validità
  await ctl({ offline: ["list_access_profiles", "get_credentials", "set_credential"] });
  await page.click("#sheet [data-edit-access]");
  await page.waitForSelector("#modal[open] [name=category]");
  console.log("select tipologia:", await page.$$eval("#modal [name=category] option", (o) => o.map((x) => `${x.value}:${x.textContent}${x.selected ? "*" : ""}`)));
  await page.check("#modal #f-limited");
  await page.click('#modal [data-preset="30"]');
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForSelector("#retry[open]");
  console.log("finestra:", await page.$eval("#retry h2", (e) => e.textContent), "|", await page.$eval("#retry .dlg-body", (e) => e.textContent.replace(/\s+/g, " ").trim()));
  await page.click('#retry [data-r="0"]');
  await page.waitForTimeout(800);
  await ctl({ offline: [] });
  const [, after] = await api("GET", "/api/persons/" + person.id);
  console.log("dopo il salvataggio: category_id", after.category_id, "profilo", after.cards[0].access_profile, "valid_to", after.cards[0].valid_to);
  await browser.close();
})();

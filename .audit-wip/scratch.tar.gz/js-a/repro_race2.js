// Repro A2: cruscotto lento che arriva dopo il cambio pagina: riquadri e matita sulla pagina Persone
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  await page.goto(base + "/#porte");
  await page.waitForSelector(".door-row");
  await page.route("**/api/dashboard", async (route) => { await new Promise((r) => setTimeout(r, 2500)); await route.continue(); });
  await page.click('#nav a[data-route="cruscotto"]');
  await page.waitForTimeout(400);
  await page.click('#nav a[data-route="persone"]');
  await page.waitForSelector("#p-list");
  await page.waitForTimeout(3000);
  console.log({
    hash: await page.evaluate(() => location.hash),
    title: await page.textContent("#page-title"),
    viewHasDash: !!(await page.$("#view #dash")),
    viewHasPersons: !!(await page.$("#view #p-list")),
    pencilVisible: await page.$eval("#top-edit", (b) => !b.hidden),
    pageSub: await page.$eval("#page-sub", (s) => s.hidden ? "" : s.textContent),
  });
  await browser.close();
})();

// Repro B: loadGroups() memorizza il fallimento come elenco vuoto e non riprova più
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome" });
  const page = await browser.newPage();
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  await ctl({ delay: {}, offline: [] });
  // Una persona con la tipologia predefinita
  const r = await page.request.post(base + "/api/persons", { data: { name: "Anna Bianchi", card: "04A1B2C3" } });
  console.log("persona creata:", r.status(), (await r.json()).category_id);
  let groupsCalls = 0;
  page.on("request", (req) => { if (req.url().endsWith("/api/groups")) groupsCalls++; });
  // Controller offline mentre si apre Persone
  await ctl({ offline: ["list_access_profiles"] });
  await page.goto(base + "/#persone");
  await page.waitForSelector("#p-list .person-row");
  const offline = {
    chips: await page.$eval("#p-cats", (e) => e.textContent.trim()),
    swatchTitle: await page.$eval("#p-list .person-row .swatch", (e) => e.title),
    groupsCalls,
  };
  console.log("controller offline:", offline);
  // Il controller torna in linea; l'utente cambia pagina e torna su Persone
  await ctl({ offline: [] });
  await page.click('#nav a[data-route="registro"]');
  await page.waitForSelector("#l-list");
  await page.click('#nav a[data-route="persone"]');
  await page.waitForSelector("#p-list .person-row");
  await page.waitForTimeout(500);
  const back = {
    chips: await page.$eval("#p-cats", (e) => e.textContent.trim()),
    swatchTitle: await page.$eval("#p-list .person-row .swatch", (e) => e.title),
    groupsCalls,
  };
  console.log("controller di nuovo in linea, Persone riaperta:", back);
  // Nuova Persona: la select della tipologia
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=category]");
  console.log("opzioni tipologia in Nuova Persona:", await page.$$eval("#modal [name=category] option", (o) => o.map((x) => x.textContent)));
  console.log("chiamate a api/groups:", groupsCalls);
  await browser.close();
})();

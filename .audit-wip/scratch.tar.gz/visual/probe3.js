const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, colorScheme: "light", locale: "it-IT", timezoneId: "Europe/Rome",
    extraHTTPHeaders: { "X-Remote-User-Name": "luca" } });
  const page = await ctx.newPage();
  const measure = (label) => page.evaluate((label) => {
    const schema = document.querySelector("#schema"); if (!schema) return label + " no schema";
    const box = schema.getBoundingClientRect();
    const r = document.querySelector("[data-reader]").getBoundingClientRect();
    const path = document.querySelector("#sch-svg path"); const d = path ? path.getAttribute("d") : "";
    return `${label}: readerRight=${Math.round(r.right - box.left)} schemaW=${Math.round(box.width)} path=${d.slice(0, 30)} nav=${Math.round(document.querySelector('#nav').getBoundingClientRect().width)} docH=${document.documentElement.scrollHeight}`;
  }, label);
  await page.goto("http://127.0.0.1:8765/", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.evaluate(() => { location.hash = "#impianti/c1"; });
  for (const t of [100, 300, 600, 1200, 2500]) { await page.waitForTimeout(t); console.log(await measure("t+" + t)); }
  await page.screenshot({ path: "probe3.png", fullPage: true });
  console.log(await measure("after fullpage shot"));
  await browser.close();
})();

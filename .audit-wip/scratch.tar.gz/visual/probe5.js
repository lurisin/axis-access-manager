const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, colorScheme: "light", locale: "it-IT", timezoneId: "Europe/Rome",
    isMobile: false, hasTouch: false, extraHTTPHeaders: { "X-Remote-User-Name": "luca", "X-Remote-User-Display-Name": "Luca Bianchi" } });
  const page = await ctx.newPage();
  const measure = (label) => page.evaluate((label) => {
    const schema = document.querySelector("#schema"); if (!schema) return label + " no schema";
    const box = schema.getBoundingClientRect(); const svg = document.querySelector("#sch-svg").getBoundingClientRect();
    const r = document.querySelector("[data-reader]").getBoundingClientRect();
    const path = document.querySelector("#sch-svg path"); const d = path ? path.getAttribute("d") : "";
    return `${label}: box.left=${Math.round(box.left)} svg.left=${Math.round(svg.left)} svgW=${Math.round(svg.width)} readerRight=${Math.round(r.right - box.left)} schemaW=${Math.round(box.width)} path=${d.slice(0, 30)}`;
  }, label);
  await page.goto("http://127.0.0.1:8765/", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("networkidle", { timeout: 6000 }).catch(() => {});
  await page.waitForTimeout(200);
  await page.evaluate(() => { location.hash = "#impianti/c1"; });
  await page.waitForLoadState("networkidle", { timeout: 6000 }).catch(() => {});
  await page.waitForTimeout(400);
  console.log(await measure("before"));
  await page.screenshot({ path: "probe5.png", fullPage: true, animations: "disabled" });
  console.log(await measure("after"));
  await browser.close();
})();

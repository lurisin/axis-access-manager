// Ad-hoc probe: node probe.js <hash> <theme> <width> "<js expression returning JSON>" [clickSelector...]
"use strict";
const { chromium } = require("playwright");
(async () => {
  const [hash, theme = "light", width = "1440", expr = "document.title", ...clicks] = process.argv.slice(2);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: Number(width), height: 900 }, colorScheme: theme, locale: "it-IT", timezoneId: "Europe/Rome",
    extraHTTPHeaders: { "X-Remote-User-Name": "luca", "X-Remote-User-Display-Name": "Luca Bianchi" },
  });
  const page = await ctx.newPage();
  await page.goto("http://127.0.0.1:8765/", { waitUntil: "domcontentloaded" });
  await page.waitForLoadState("networkidle", { timeout: 5000 }).catch(() => {});
  await page.evaluate((h) => { location.hash = h; }, hash);
  await page.waitForLoadState("networkidle", { timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(1200);
  for (const c of clicks) { await page.click(c); await page.waitForTimeout(800); }
  const result = await page.evaluate(expr);
  console.log(JSON.stringify(result, null, 1));
  await browser.close();
})();

const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const hashes = ["#cruscotto", "#porte", "#porte/1", "#porte/2", "#persone", "#persone/tipologie", "#da-registrare", "#registro", "#regole", "#regole/festivita", "#impianti", "#impianti/strutture", "#impianti/backup", "#impianti/c1", "#impianti/c1/porte", "#impianti/c1/lettori", "#impianti/c1/telecamere", "#impianti/c1/citofoni", "#impianti/c1/stato", "#impianti/c1/storico", "#impianti/c1/backup", "#impianti/c1/connessione", "#notifiche", "#impostazioni", "#impostazioni/notifiche", "#impostazioni/backup", "#impostazioni/utenti", "#impostazioni/attivita"];
  for (const width of [390, 360]) {
    const ctx = await browser.newContext({ viewport: { width, height: 844 }, isMobile: true, hasTouch: true, locale: "it-IT", timezoneId: "Europe/Rome", extraHTTPHeaders: { "X-Remote-User-Name": "luca" } });
    const page = await ctx.newPage();
    await page.goto("http://127.0.0.1:8765/");
    await page.waitForTimeout(1500);
    for (const h of hashes) {
      await page.evaluate((x) => { location.hash = x; }, h);
      await page.waitForTimeout(1300);
      const r = await page.evaluate(() => {
        const vw = document.documentElement.clientWidth;
        const wide = [...document.querySelectorAll("#view *")].filter((e) => { const b = e.getBoundingClientRect(); return b.width > 0 && b.right > vw + 1 && !e.closest(".table-wrap, .segmented"); })
          .slice(0, 4).map((e) => `${e.tagName.toLowerCase()}.${[...e.classList].join(".")}#${e.id} right=${Math.round(e.getBoundingClientRect().right)} "${(e.textContent || "").trim().slice(0, 30)}"`);
        return { sw: document.documentElement.scrollWidth, vw, wide };
      });
      if (r.sw > r.vw || r.wide.length) console.log(width, h, JSON.stringify(r));
    }
    await ctx.close();
  }
  await browser.close();
})();

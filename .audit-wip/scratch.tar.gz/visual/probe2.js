const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "it-IT", timezoneId: "Europe/Rome",
    extraHTTPHeaders: { "X-Remote-User-Name": "luca" } });
  const page = await ctx.newPage();
  const measure = () => page.evaluate(() => {
    const schema = document.querySelector("#schema"); const box = schema.getBoundingClientRect();
    const r = document.querySelector("[data-reader]").getBoundingClientRect();
    const d = document.querySelector("[data-door]").getBoundingClientRect();
    const path = document.querySelector("#sch-svg path"); const m = /M([\d.]+) ([\d.]+) C.* ([\d.]+) ([\d.]+)$/.exec(path.getAttribute("d"));
    return { readerRight: Math.round(r.right - box.left), doorLeft: Math.round(d.left - box.left), pathStart: Math.round(+m[1]), pathEnd: Math.round(+m[3]), schemaW: Math.round(box.width), navW: Math.round(document.querySelector("#nav").getBoundingClientRect().width) };
  });
  // Direct load of the controller page
  await page.goto("http://127.0.0.1:8765/#impianti/c1");
  await page.waitForTimeout(3000);
  console.log("direct load", JSON.stringify(await measure()));
  // Navigate away and back with the menu already open
  await page.evaluate(() => { location.hash = "#porte"; }); await page.waitForTimeout(1500);
  await page.evaluate(() => { location.hash = "#impianti/c1"; }); await page.waitForTimeout(2500);
  console.log("in-app nav", JSON.stringify(await measure()));
  // Toggle the side menu
  await page.click("#nav-toggle"); await page.waitForTimeout(1000);
  console.log("menu toggled", JSON.stringify(await measure()));
  await page.screenshot({ path: "schema-after-toggle.png" });
  await browser.close();
})();

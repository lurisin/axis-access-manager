const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  for (const theme of ["light", "dark"]) {
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, colorScheme: theme, locale: "it-IT", timezoneId: "Europe/Rome", extraHTTPHeaders: { "X-Remote-User-Name": "luca" } });
    const page = await ctx.newPage();
    await page.goto("http://127.0.0.1:8765/#impianti/c1");
    await page.waitForTimeout(2500);
    await page.click("[data-reader='lettore-2']"); await page.waitForTimeout(300);
    await page.click("[data-door='porta']"); await page.waitForTimeout(600);
    await page.screenshot({ path: `savebar-${theme}.png` });
    const r = await page.evaluate(() => { const b = document.querySelector("#sch-bar"); const cs = getComputedStyle(b); const btn = b.querySelector("button:not(.primary)"); return { bg: cs.backgroundColor, color: cs.color, btnBorder: getComputedStyle(btn).borderColor, page: getComputedStyle(document.body).backgroundColor, text: b.textContent.trim().slice(0, 120) }; });
    console.log(theme, JSON.stringify(r));
    await ctx.close();
  }
  await browser.close();
})();

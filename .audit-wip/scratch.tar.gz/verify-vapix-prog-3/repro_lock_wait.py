"""Sync di _maintenance in coda sul lock del servizio; reload_runtime chiude il client; il lock si libera."""
import asyncio, json, tempfile
from pathlib import Path
from types import SimpleNamespace
import httpx
from app.config import parse_options
from app.db import Database
from app.main import _maintenance
from app.service import AccessService
from app.vapix import A1210Client, ControllerGuard


async def main():
    async def handler(request):
        body = json.loads(request.content)
        method = next(iter(body))
        key = method.split(":")[1].replace("Get", "").replace("List", "")
        return httpx.Response(200, json={key: []})

    raw = A1210Client("a1210.local", "u", "p", transport=httpx.MockTransport(handler))
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "x"})
    service = AccessService(db, ControllerGuard(raw), settings)
    ready = asyncio.Event(); ready.set()
    state = SimpleNamespace(health_ready=ready, controller=SimpleNamespace(paused=""), settings=settings,
        service=service, sync_wake=asyncio.Event(), last_sync=None, db=db,
        ha=SimpleNamespace(delete_snapshots=lambda files: None))
    await service.lock.acquire()  # un'operazione di scrittura in corso (es. ripristino tessere)
    task = asyncio.create_task(_maintenance(SimpleNamespace(state=state)))
    await asyncio.sleep(0.05)
    await raw.aclose()  # reload_runtime -> _stop_runtime
    service.lock.release()
    await asyncio.sleep(0.1)
    print("task finito:", task.done(), "| eccezione:", repr(task.exception()) if task.done() else None)
    print("last_sync:", state.last_sync)

asyncio.run(main())

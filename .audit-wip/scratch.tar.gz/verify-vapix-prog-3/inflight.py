import asyncio, httpx

async def handle(reader, writer):
    await reader.read(65536)
    await asyncio.sleep(0.5)
    body = b"{}"
    writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n" + body)
    await writer.drain(); writer.close()

async def main():
    server = await asyncio.start_server(handle, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    client = httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}")
    t = asyncio.create_task(client.post("/x", json={}))
    await asyncio.sleep(0.1)
    await client.aclose()
    try:
        r = await t; print("in corso: completata", r.status_code)
    except Exception as e:
        print("in corso:", type(e).__mro__[:3])
    try:
        await client.post("/x", json={})
    except Exception as e:
        print("successiva:", repr(e))
    server.close()

asyncio.run(main())

"""Due persone con lo stesso nome ricreate dal backup nello stesso secondo: stesso token utente
(utente_<nome>_<aammgghhmmss>), IntegrityError non gestito, ripristino interrotto a meta'."""

import asyncio

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    a = await plant.access.create_person("Badge Riserva", "04aa", "admin")
    await asyncio.sleep(1.1)  # create a mano in secondi diversi
    b = await plant.access.create_person("Badge Riserva", "04bb", "admin")
    await plant.access.create_person("Carla", "04cc", "admin")
    backup = await plant.backup()
    for p in (a, b):
        await plant.access.delete_person(p["id"], "admin")
    try:
        items, result = await restore(plant, backup["id"], ["persone"])
        print("RISULTATO:", result)
    except Exception as err:  # noqa: BLE001
        print("ECCEZIONE NON GESTITA:", type(err).__name__, err)
    print("persone nel db:", [(p["name"], p["axis_user_token"], [c["number"] for c in p["cards"]]) for p in db.list_persons()])
    print("utenti sul controller:", list(controller.users))
    print("tessere sul controller:", [(c["IdData"][0]["Value"], c["UserToken"]) for c in controller.credentials.values()])
    print("ultime voci audit:", [a["action"] for a in db.list_audit(5)])


run(main())

"""Tipologie: le regole del backup indicano aree/porte per numero. Un'area eliminata e una nuova creata dopo
riprendono lo stesso numero: la tipologia ricreata entra nell'area nuova, mentre l'anteprima mostra il nome vecchio."""

from test_backup import DOOR
from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    magazzino = db.save_area(None, plant.site, "Magazzino")
    cantina = db.save_door(None, plant.controller_id, DOOR | {"door_token": "porta2", "name": "Cantina"})
    db.set_door_area(cantina, magazzino)
    controller.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Name": "Cantina",
        "Enabled": True, "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
        "Attribute": [{"Name": "Direction", "Value": "in"}]})
    rule = {"target": "area", "target_id": magazzino, "schedule": "standard_always"}
    pulizie = await plant.rules.save_category(None, {"name": "Pulizie", "rules": [rule]}, "admin")
    backup = await plant.backup()
    # Dopo il backup: tipologia e area Magazzino eliminate; nasce l'area Direzione con la porta Scala
    await plant.rules.delete_category(pulizie["id"], "admin")
    db.set_door_area(cantina, 0)
    db.delete_area(magazzino)
    direzione = db.save_area(None, plant.site, "Direzione")
    db.set_door_area(plant.scala, direzione)
    print("id Magazzino (backup):", magazzino, "| id Direzione (nuova):", direzione)

    items, result = await restore(plant, backup["id"], ["tipologie"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    category = db.category_by_name("Pulizie")
    print("regole ricreate:", db.category_rules(category["id"]))
    profile = controller.profiles[category["group_token"]]
    print("punti di accesso nel profilo:", [p["AccessPoint"] for p in profile["AccessPolicy"]], "(nel backup: ap-cantina; ap-in = porta Scala, ora in Direzione)")


run(main())

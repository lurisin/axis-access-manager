"""Persone: tipologia rinominata dopo il backup -> la persona ripristinata perde la tipologia."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    rule = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    category = await plant.rules.save_category(None, {"name": "Pulizie", "color": "teal", "rules": [rule]}, "admin")
    anna = await plant.access.create_person("Anna", "04aa", "admin", category_id=category["id"])
    backup = await plant.backup()
    # Dopo il backup: la tipologia cambia nome (stesso numero, stesso profilo) e Anna viene sospesa
    await plant.rules.save_category(
        category["id"], {"name": "Impresa Pulizie", "color": "teal", "rules": [rule]}, "admin"
    )
    await plant.access.set_card_enabled(anna["cards"][0]["id"], False, "admin")
    print("Prima: categoria di Anna =", db.get_person(anna["id"])["category_id"])

    items, result = await restore(plant, backup["id"], ["persone"])
    print("ANTEPRIMA (solo Persone):")
    show(items)
    print("RISULTATO:", result)
    after = db.get_person(anna["id"])
    print("Dopo: categoria di Anna =", after["category_id"], "| tessera attiva =", after["cards"][0]["enabled"])
    print("Tipologia", category["id"], "esiste ancora:", db.get_category(category["id"]))
    print("profilo condiviso ora?", plant.rules._profile_shared(category["token"], category["id"]))


run(main())

"""Harness comune per le prove: impianto finto come in tests/test_backup.py."""

import asyncio
import json
import tempfile
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.config import parse_options
from app.db import Database
from app.restore import Runtime, apply, plan, public


def settings():
    return parse_options(
        {
            "a1210_host": "a1210.local",
            "door_token": "porta",
            "access_profile": "profilo_sempre",
            "mqtt_topic_prefix": "accessi/x",
        }
    )


def make_plant(tmp=None):
    tmp = Path(tmp or tempfile.mkdtemp())
    db = Database(tmp / "test.db")
    controller = FakeController()
    plant = Plant(db, controller, settings(), tmp / "backup")
    return plant, db, controller


async def preview(plant, backup_id, sections, mqtt_users=None):
    _, saved = plant.backups.load(backup_id)
    current, _ = await plant.backups.snapshot(plant.clients)
    return plan(saved, current, list(sections), plant.controller_id, mqtt_users)


async def restore(plant, backup_id, sections, keys=None, password="", known=None):
    _, saved = plant.backups.load(backup_id)
    current, _ = await plant.backups.snapshot(plant.clients)
    items = plan(saved, current, list(sections), plant.controller_id, set(known or {}))
    chosen = [i["key"] for i in items if i["default"] and not i["blocked"]] if keys is None else keys
    runtime = Runtime(
        plant.db,
        plant.access,
        plant.rules,
        plant.programming,
        plant.controller_id,
        mqtt_password=password,
        mqtt_known=known or {},
    )
    return items, await apply(items, chosen, runtime, "admin")


def show(items):
    for i in public(items):
        print(" ", json.dumps({k: i[k] for k in ("key", "action", "text", "changes", "warnings", "blocked", "default")}, ensure_ascii=False))


def run(coro):
    return asyncio.run(coro)

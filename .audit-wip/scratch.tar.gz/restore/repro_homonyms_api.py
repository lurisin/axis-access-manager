"""Stesso caso via API: risposta 500, ripristino a meta', nessuna voce 'ripristino da backup'."""

import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController
from fastapi.testclient import TestClient
from harness import settings

from app.main import create_app

tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings(), allow_any_client=True, controller=controller, db_path=tmp / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app, raise_server_exceptions=False) as client:
    client.get("/api/me", headers=admin)
    a = client.post("/api/persons", json={"name": "Senza Nome", "card": "04aa"}, headers=admin).json()
    time.sleep(1.1)
    b = client.post("/api/persons", json={"name": "Senza Nome", "card": "04bb"}, headers=admin).json()
    created = client.post("/api/backups", json={}, headers=admin).json()
    client.delete(f"/api/persons/{a['id']}", headers=admin)
    client.delete(f"/api/persons/{b['id']}", headers=admin)
    preview = client.post(f"/api/backups/{created['id']}/preview", json={"sections": ["persone"]}, headers=admin).json()
    keys = [i["key"] for i in preview["items"] if i["default"]]
    response = client.post(f"/api/backups/{created['id']}/restore", json={"sections": ["persone"], "keys": keys}, headers=admin)
    print("HTTP", response.status_code, response.text[:120])
    print("persone:", [(p["name"], [c["number"] for c in p["cards"]]) for p in client.get("/api/persons", headers=admin).json()])
    print("tessere sul controller:", [(c["IdData"][0]["Value"], c["UserToken"]) for c in controller.credentials.values()])
    print("audit:", [x["action"] for x in client.get("/api/audit", headers=admin).json()[:4]])

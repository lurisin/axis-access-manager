"""Ripristino completo ripetuto dopo che il controller ha rifiutato i token Axis-<serie>:...:
gli oggetti rinominati la prima volta vengono ricreati una seconda volta (doppioni sul controller)."""

from harness import make_plant, restore, run, show

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    controller.serial = "B8A44FE6A074"
    # Oggetti creati dal controller: token Axis-<serie>:...
    door = controller.doors.pop("porta")
    controller.doors["Axis-b8a44fe6a074:1.1"] = {**door, "token": "Axis-b8a44fe6a074:1.1"}
    db.replace_token("porta", "Axis-b8a44fe6a074:1.1")
    controller.access_points[0]["Entity"] = "Axis-b8a44fe6a074:1.1"
    controller.door_configs = {}
    profile = controller.profiles.pop("profilo_sempre")
    controller.profiles["Axis-b8a44fe6a074:9.9"] = {**profile, "token": "Axis-b8a44fe6a074:9.9"}
    db.set_setting("default_group", "Axis-b8a44fe6a074:9.9")
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()

    controller.factory_reset()
    controller.refuse_axis_tokens = True
    items, result = await restore(plant, backup["id"], FULL, password="x")
    print("PRIMO RIPRISTINO: failed =", result["failed"], "renamed =", result.get("renamed"))
    print("porte sul controller:", sorted(controller.doors), "| profili:", sorted(controller.profiles))
    print("default_group nel db:", db.get_setting("default_group"), "| door_token nel db:", [d["door_token"] for d in db.list_doors()])

    # L'utente rifà il ripristino con lo stesso backup (per esempio dopo una riga non riuscita)
    items2, result2 = await restore(plant, backup["id"], FULL, password="x")
    print("SECONDO RIPRISTINO, anteprima:")
    show([i for i in items2 if i["section"] == "controller"])
    print("risultato:", result2["applied"], result2["failed"])
    print("porte sul controller:", sorted(controller.doors), "| profili:", sorted(controller.profiles))
    print("default_group nel db:", db.get_setting("default_group"), "| door_token nel db:", [d["door_token"] for d in db.list_doors()])


run(main())

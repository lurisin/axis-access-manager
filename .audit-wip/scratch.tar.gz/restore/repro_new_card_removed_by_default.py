"""Persona che ha solo ricevuto una tessera in piu' dopo il backup: la riga 'Riporta com'era' e' spuntata di serie
e il suo unico effetto e' togliere la tessera nuova (DOCS: 'tessere aggiunte dopo il backup: si tolgono solo
se le spunti')."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    anna = await plant.access.create_person("Anna", "04aa", "admin")
    bruno = await plant.access.create_person("Bruno", "04bb", "admin")
    backup = await plant.backup()
    # Dopo il backup: Anna riceve una seconda tessera (sostitutiva); Bruno viene eliminato per errore
    await plant.access.add_card(anna["id"], "04cc", "admin")
    await plant.access.delete_person(bruno["id"], "admin")

    # L'amministratore ripristina per riavere Bruno, con le righe spuntate di serie
    items, result = await restore(plant, backup["id"], ["persone"])
    show(items)
    print("RISULTATO:", result)
    print("tessere di Anna:", [c["number"] for c in db.get_person(anna["id"])["cards"]])
    print("credenziali sul controller:", sorted(c["IdData"][0]["Value"] for c in controller.credentials.values()))


run(main())

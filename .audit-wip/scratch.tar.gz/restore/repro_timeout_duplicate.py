"""_create ritenta senza token per QUALSIASI VapixError: un timeout su una scrittura che il controller ha
eseguito crea un doppione e l'app passa al token nuovo."""

from harness import make_plant, restore, run, show
from app.vapix import VapixError

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    controller.serial = "B8A44FE6A074"
    profile = controller.profiles.pop("profilo_sempre")
    controller.profiles["Axis-b8a44fe6a074:9.9"] = {**profile, "token": "Axis-b8a44fe6a074:9.9"}
    db.set_setting("default_group", "Axis-b8a44fe6a074:9.9")
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()
    controller.factory_reset()

    original = controller.set_access_profile
    state = {"first": True}

    async def slow(profile):
        token = await original(profile)          # il controller scrive...
        if state["first"] and profile.get("token"):
            state["first"] = False
            raise VapixError("il controller non risponde (ReadTimeout)")   # ...ma la risposta non arriva
        return token

    controller.set_access_profile = slow
    items, result = await restore(plant, backup["id"], FULL, password="x")
    print("failed:", result["failed"], "| renamed:", result.get("renamed"))
    print("profili sul controller:", sorted(controller.profiles))
    print("default_group:", db.get_setting("default_group"))


run(main())

"""Porta tolta dall'app dopo il backup: 'Porte e Lettori' la rimette con un numero nuovo, e la tipologia del
backup che la usava (porta n. vecchio) non si puo' piu' ripristinare, neanche rifacendo il ripristino."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    from test_backup import DOOR
    plant.db.save_door(None, plant.controller_id, DOOR | {"door_token": "porta2", "name": "Cantina"})
    rule = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    category = await plant.rules.save_category(None, {"name": "Pulizie", "rules": [rule]}, "admin")
    backup = await plant.backup()
    # Dopo il backup: la tipologia passa all'area, la porta viene tolta dall'app
    db.set_door_area(plant.scala, plant.area)
    area_rule = {"target": "area", "target_id": plant.area, "schedule": "standard_always"}
    await plant.rules.save_category(category["id"], {"name": "Pulizie", "rules": [area_rule]}, "admin")
    plant.rules.check_place_unused("door", plant.scala)
    plant.db.delete_door(plant.scala)

    for attempt in (1, 2):
        items, result = await restore(plant, backup["id"], ["tipologie", "porte"])
        print(f"TENTATIVO {attempt}:")
        show(items)
        print("  risultato:", result)
        print("  porte nell'app:", [(d["id"], d["door_token"]) for d in db.list_doors()])
        print("  regole della tipologia:", db.category_rules(category["id"]))


run(main())

"""API: anteprima con il controller raggiungibile, ripristino con il controller che non risponde.
Le righe scelte spariscono dal piano ricalcolato e il risultato le conta come 'gia' come nel backup'."""

import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController
from fastapi.testclient import TestClient
from harness import settings

from app.main import create_app

tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings(), allow_any_client=True, controller=controller, db_path=tmp / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    created = client.post("/api/backups", json={}, headers=admin).json()
    part = next(k for k in created["parts"] if k.startswith("controller:"))
    controller.doors["porta"]["Name"] = "Nome cambiato"
    controller.doors["porta"]["AccessTime"] = "PT20S"
    preview = client.post(f"/api/backups/{created['id']}/preview", json={"sections": ["porte"], "part": part}, headers=admin).json()
    keys = [i["key"] for i in preview["items"] if i["default"] and not i["blocked"]]
    print("anteprima:", [(i["key"], i["blocked"]) for i in preview["items"]])
    # Il controller smette di rispondere tra l'anteprima e la conferma (rete, riavvio...)
    controller.offline = True
    response = client.post(f"/api/backups/{created['id']}/restore", json={"sections": ["porte"], "part": part, "keys": keys}, headers=admin)
    print("HTTP", response.status_code, response.json())
    print("porta sul controller:", controller.doors["porta"]["Name"], controller.doors["porta"]["AccessTime"])
    audit = client.get("/api/audit", headers=admin).json()
    print("audit:", [(a["action"], a["detail"]) for a in audit[:3]])

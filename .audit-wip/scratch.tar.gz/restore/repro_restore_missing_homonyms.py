"""Riga 'Tessere' del ripristino completo (restore_missing): due persone lette da tessere senza utente e senza
nome ('(Senza nome)') ricevono lo stesso token utente nello stesso secondo -> IntegrityError non gestito."""

from harness import make_plant, restore, run, show

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    for i, card in enumerate(("04a1", "04a2")):
        controller.credentials[f"c{i}"] = {
            "token": f"c{i}", "Enabled": True, "IdData": [{"Name": "Card", "Value": card}],
            "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre"}],
        }
    await plant.access.sync_from_controller()
    print("persone:", [(p["name"], p["axis_user_token"]) for p in db.list_persons()])
    backup = await plant.backup()
    controller.factory_reset()
    try:
        items, result = await restore(plant, backup["id"], FULL, password="x")
        print("RISULTATO:", result["applied"][-1:], result["failed"])
    except Exception as err:  # noqa: BLE001
        print("ECCEZIONE NON GESTITA:", type(err).__name__, err)
    print("tessere sul controller:", [(c["IdData"][0]["Value"], c["UserToken"]) for c in controller.credentials.values()])
    print("tessere non presenti nel db:", [c["number"] for c in db.missing_cards()])


run(main())

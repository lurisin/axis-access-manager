"""Il backup 'Prima del Ripristino' applica la ritenzione: puo' eliminare proprio il backup da cui si sta
ripristinando. Se il ripristino riesce a meta' non si puo' piu' riprovare."""

import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"

from conftest import FakeController
from fastapi.testclient import TestClient
from harness import settings

from app.main import create_app

tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings(), allow_any_client=True, controller=controller, db_path=tmp / "api.db")
admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    policy = {"keep_last": 3, "keep_daily": 0, "keep_weekly": 0, "keep_monthly": 0, "keep_yearly": 0, "confirm": True}
    print(client.put("/api/backups/policy", json=policy, headers=admin).json()["saved"])
    p = client.post("/api/persons", json={"name": "Anna", "card": "04aa"}, headers=admin).json()
    old = client.post("/api/backups", json={"name": "Prima dei lavori"}, headers=admin).json()
    for i in range(2):
        time.sleep(1.05)
        client.post("/api/backups", json={"name": f"altro {i}"}, headers=admin)
    client.delete(f"/api/persons/{p['id']}", headers=admin)
    preview = client.post(f"/api/backups/{old['id']}/preview", json={"sections": ["persone"]}, headers=admin).json()
    keys = [i["key"] for i in preview["items"] if i["default"]]
    controller.fail_set_credential = True          # il ripristino non riesce (controller occupato, ecc.)
    time.sleep(1.05)
    result = client.post(f"/api/backups/{old['id']}/restore", json={"sections": ["persone"], "keys": keys}, headers=admin).json()
    print("risultato:", result)
    names = [b["name"] for b in client.get("/api/backups", headers=admin).json()["backups"]]
    print("backup rimasti:", names)
    retry = client.post(f"/api/backups/{old['id']}/preview", json={"sections": ["persone"]}, headers=admin)
    print("riprova dal backup scelto:", retry.status_code, retry.json())

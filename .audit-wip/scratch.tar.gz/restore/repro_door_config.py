"""Porte e Lettori: una differenza nella configurazione della porta compare nell'anteprima ma non si ripristina."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    backup = await plant.backup()
    # Dopo il backup cambia solo la configurazione della serratura (o il Sensore Porta via ingresso)
    controller.door_configs["porta"]["Configuration"] = [{"Name": "Lock.Type", "Value": "FailSafe"}]

    items, result = await restore(plant, backup["id"], ["porte"])
    print("ANTEPRIMA 1:")
    show(items)
    print("RISULTATO:", result)
    print("Configurazione dopo il ripristino:", controller.door_configs["porta"]["Configuration"])
    items2, _ = await restore(plant, backup["id"], ["porte"], keys=[])
    print("ANTEPRIMA 2 (dopo il ripristino):")
    show(items2)


run(main())

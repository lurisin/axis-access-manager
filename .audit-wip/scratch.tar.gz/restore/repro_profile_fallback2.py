"""Variante 'riporta': l'anteprima mostra il gruppo del backup, il ripristino scrive quello predefinito."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    g1 = await plant.rules.create_group("Solo Ufficio", "", "standard_office_hours", "admin")
    paolo = await plant.access.create_person("Paolo", "04cc", "admin", group=g1["token"])
    backup = await plant.backup()
    g2 = await plant.rules.create_group("Visitatori", "", "standard_office_hours", "admin")
    await plant.access.set_person_access(paolo["id"], g2["token"], "", "", "admin")
    await plant.rules.delete_group(g1["token"], "admin")

    items, result = await restore(plant, backup["id"], ["persone"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    card = db.get_person(paolo["id"])["cards"][0]
    print("profilo scritto:", card["access_profile"], "| predefinito:", plant.access.default_group)


run(main())

"""Porte e Lettori: se ora le porte non si leggono (errore di lettura), ogni porta risulta 'non piu' programmata
sul controller' e l'anteprima consiglia il Ripristino Completo."""

from harness import make_plant, restore, run, show
from app.vapix import VapixError


async def main():
    plant, db, controller = make_plant()
    backup = await plant.backup()

    async def broken():
        raise VapixError("il controller non risponde (ReadTimeout)")

    controller.list_doors = broken
    items, _ = await restore(plant, backup["id"], ["porte"], keys=[])
    show(items)


run(main())

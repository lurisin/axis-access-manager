"""Ripristino completo: se l'elenco delle tessere ora non si legge, il controller sembra 'appena resettato'
e la rimozione di quello che c'e' in piu' e' spuntata di serie (anche le fasce orarie)."""

from conftest import FakeController
from harness import make_plant, restore, run, show
from app.vapix import VapixError

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()
    # Lavoro buono fatto dopo il backup su un controller che funziona: una fascia e una porta nuove
    rule_schedule = await plant.rules.create_schedule(
        "Turno Notte", "", [{"days": ["MO"], "start": "22:00", "end": "23:59"}], False, "admin"
    )
    controller.doors["Door9"] = {"token": "Door9", "Name": "Magazzino Nuovo"}
    await plant.access.create_person("Bruno", "04bb", "admin")

    async def broken():
        raise VapixError("il controller non risponde (ReadTimeout)")

    controller.list_credentials = broken   # lettura delle tessere non riuscita (timeout con molte tessere)
    items, _ = await restore(plant, backup["id"], FULL, keys=[])
    print("ANTEPRIMA:")
    show([i for i in items if i["action"] == "togli" or i["key"] == "tessere"])
    print("schedule nuovo:", rule_schedule)


run(main())

"""Tessera passata da A a B dopo il backup: l'anteprima dice 'resta sua' (di B) ma la riga di B, spuntata
di serie, la toglie. Dopo il ripristino la tessera non e' di nessuno."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    anna = await plant.access.create_person("Anna", "04aa", "admin")
    bruno = await plant.access.create_person("Bruno", "04bb", "admin")
    backup = await plant.backup()
    # La tessera 04aa passa da Anna a Bruno (Anna, rimasta senza tessere, sparisce)
    await plant.access.delete_card(anna["cards"][0]["id"], "admin")
    await plant.access.add_card(bruno["id"], "04aa", "admin")

    items, result = await restore(plant, backup["id"], ["persone"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    print("04aa ora:", db.card_by_number("04aa"))
    print("credenziali sul controller:", [c["IdData"][0]["Value"] for c in controller.credentials.values()])


run(main())

"""Porta aggiunta all'app dopo il backup: l'anteprima di 'Porte e Lettori' mostra le sue impostazioni dell'app
che tornano a '—', il ripristino non le tocca e la riga si ripresenta sempre."""

from test_backup import DOOR
from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    backup = await plant.backup()
    db.save_door(None, plant.controller_id, DOOR | {"door_token": "porta2", "name": "Cantina", "snapshot_camera": "camera.cantina"})
    for attempt in (1, 2):
        items, result = await restore(plant, backup["id"], ["porte"])
        print(f"TENTATIVO {attempt}:")
        show(items)
        print("  risultato:", result)
    print("porte nell'app:", [(d["door_token"], d["snapshot_camera"]) for d in db.list_doors()])


run(main())

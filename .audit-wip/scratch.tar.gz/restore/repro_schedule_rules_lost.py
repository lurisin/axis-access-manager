"""Dopo un reset, una qualsiasi lettura delle fasce (pagina Fasce Orarie, Gruppi/Tipologie) cancella le regole
dell'app delle fasce che il controller non ha piu'. Il ripristino completo ricrea le fasce sul controller ma non
rimette le regole dell'app, che pure sono nei Dati Comuni del backup."""

from harness import make_plant, restore, run, show

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    rules = [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "07:00", "end": "19:00"}]
    sched = await plant.rules.create_schedule("Turno Giorno", "", rules, True, "admin")
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()
    _, parts = plant.backups.load(backup["id"])
    print("regole nel backup:", [s for s in parts["comuni"]["schedules"] if s["token"] == sched["token"]])
    controller.factory_reset()
    await plant.rules.list_schedules()        # l'utente apre Fasce Orarie / Tipologie prima del ripristino
    print("regole nel db dopo la lettura:", db.schedule_rules())
    items, result = await restore(plant, backup["id"], FULL, password="x")
    print("ripristino: failed =", result["failed"])
    print("fascia sul controller:", sched["token"] in controller.schedules)
    print("regole nel db dopo il ripristino:", db.schedule_rules())
    listed = next(s for s in await plant.rules.list_schedules() if s["token"] == sched["token"])
    print("pagina Fasce: managed =", listed["managed"], "| holidays =", listed["holidays"])
    # Una festivita' aggiunta dopo non arriva piu' alla fascia
    await plant.rules.add_holidays([{"day": "2026-12-08", "name": "Immacolata", "yearly": False}], "admin")
    print("eccezioni della fascia:", controller.schedules[sched["token"]].get("ExceptionScheduleDefinition"))


run(main())

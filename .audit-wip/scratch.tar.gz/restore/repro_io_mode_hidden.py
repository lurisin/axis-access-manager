"""Ripristino completo, morsetti: se cambia solo il modo (linea supervisionata), l'anteprima mostra
'Assegnato a: X -> X' e nasconde la differenza che verra' scritta."""

from harness import make_plant, restore, run, show

FULL = ["dispositivo", "controller", "tessere"]


async def main():
    plant, db, controller = make_plant()
    user = [{"Type": "idpoint", "token": "lettore-1", "Usage": "REX"}]
    controller.io_assignments = {"REX": {"IoMode": "in:pu/gnd", "IoUser": user}}
    await plant.access.create_person("Anna", "04aa", "admin")
    backup = await plant.backup()
    controller.io_assignments["REX"]["IoMode"] = "supervised"   # linea supervisionata impostata dopo il backup

    items, result = await restore(plant, backup["id"], FULL, keys=["prog-io:REX"])
    show([i for i in items if i["key"].startswith("prog-io")])
    print("RISULTATO:", result["applied"], "| modo ora:", controller.io_assignments["REX"]["IoMode"])


run(main())

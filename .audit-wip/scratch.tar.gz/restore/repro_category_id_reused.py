"""Tipologie: il numero di una tipologia eliminata viene riusato da SQLite per la successiva. Il ripristino
abbina per numero e trasforma la tipologia nuova (con le sue persone) in quella del backup."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    always = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    office = {"target": "door", "target_id": plant.scala, "schedule": "standard_office_hours"}
    await plant.rules.save_category(None, {"name": "Dipendenti", "rules": [office]}, "admin")
    pulizie = await plant.rules.save_category(None, {"name": "Pulizie", "color": "teal", "rules": [always]}, "admin")
    backup = await plant.backup()
    # Dopo il backup: Pulizie eliminata, nasce Ospiti (solo orario d'ufficio) con una persona
    await plant.rules.delete_category(pulizie["id"], "admin")
    ospiti = await plant.rules.save_category(None, {"name": "Ospiti", "color": "orange", "rules": [office]}, "admin")
    print("id di Pulizie nel backup:", pulizie["id"], "| id di Ospiti:", ospiti["id"])
    ospite = await plant.access.create_person("Visitatore", "04cc", "admin", category_id=ospiti["id"])

    items, result = await restore(plant, backup["id"], ["tipologie"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    print("tipologie:", [(c["id"], c["name"]) for c in db.list_categories()])
    person = db.get_person(ospite["id"])
    profile = controller.profiles[person["cards"][0]["access_profile"]]
    print("Visitatore: tipologia", db.get_category(person["category_id"])["name"], "| fasce del suo profilo:",
          [p["Schedule"] for p in profile["AccessPolicy"]])


run(main())

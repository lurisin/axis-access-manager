"""Persone: profilo della tessera sparito -> la tessera ricreata riceve il gruppo predefinito, senza dirlo."""

from harness import make_plant, restore, run, show


async def main():
    plant, db, controller = make_plant()
    # Gruppo ristretto creato dalla pagina Gruppi (solo fascia orario d'ufficio)
    group = await plant.rules.create_group("Solo Ufficio", "", "standard_office_hours", "admin")
    paolo = await plant.access.create_person("Paolo", "04cc", "admin", group=group["token"])
    print("Paolo prima:", db.get_person(paolo["id"])["cards"][0]["access_profile"])
    backup = await plant.backup()
    # Dopo il backup Paolo viene eliminato e il gruppo, rimasto inutilizzato, anche
    await plant.access.delete_person(paolo["id"], "admin")
    await plant.rules.delete_group(group["token"], "admin")

    items, result = await restore(plant, backup["id"], ["persone"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    restored = db.get_person(paolo["id"])
    card = restored["cards"][0]
    print("Paolo dopo: profilo della tessera =", card["access_profile"], "(predefinito:", plant.access.default_group, ")")
    cred = controller.credentials[card["axis_credential_token"]]
    print("Sul controller:", cred["CredentialAccessProfile"])
    print("Schedule del profilo scritto:", controller.profiles[card["access_profile"]]["Schedule"])


run(main())

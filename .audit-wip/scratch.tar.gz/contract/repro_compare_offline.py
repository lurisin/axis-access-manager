"""Backup → Confronta con "Stato attuale" mentre il controller non risponde: la parte del controller manca dallo stato
attuale e tutta la sua configurazione compare come tolta, con la nota "non c'è nel backup più recente"."""

import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()
controller.add_existing("utente_mario", "Mario Rossi", "04aa")
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    client.post("/api/sync")
    backup = client.post("/api/backups", json={"name": "prima"}).json()
    controller.offline = True
    # device_info fallisce: il controller "non risponde"
    data = client.get(f"/api/backups/{backup['id']}/compare", params={"other": "attuale"}).json()
    for g in data["groups"]:
        print(f"[{g['title']}] nota: {g['note']!r}")
        for s in g["sections"]:
            print(f"   {s['title']}: tolti {len(s['removed'])} {[i['label'] for i in s['removed']][:4]}")
    data = client.get(
        f"/api/backups/{backup['id']}/compare", params={"other": "attuale", "part": f"controller:{1}"}
    ).json()
    print("dalla scheda Backup del controller:", [(g["title"], g["note"]) for g in data["groups"]])

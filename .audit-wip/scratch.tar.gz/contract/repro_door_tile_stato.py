"""Cruscotto di un utente "Solo Stato" (il ruolo dei nuovi utenti): /api/door-overview toglie l'ultimo passaggio
(last = None) perché non ha il permesso Registro, e il riquadro Porte lo legge come "Nessun passaggio registrato"."""

import tempfile
from datetime import UTC, datetime
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db")
admin = {"X-Remote-User-Name": "admin", "X-Remote-User-Display-Name": "Admin"}
guard = {"X-Remote-User-Name": "portiere", "X-Remote-User-Display-Name": "Portiere"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    print("ruolo del nuovo utente:", client.get("/api/me", headers=guard).json()["role"])
    now = datetime.now(tz=UTC).isoformat(timespec="seconds")
    for _ in range(3):
        app.state.db.add_event(ts=now, kind="concesso", person_name="Anna", card="04AA", door="porta")
    [door] = client.get("/api/door-overview", headers=guard).json()
    print("door-overview per Solo Stato: today =", door["today"], "| last =", door["last"])
    print('doorTile: d.last ? ... : "Nessun passaggio registrato"  →  "Nessun passaggio registrato · Oggi 3 accessi"')

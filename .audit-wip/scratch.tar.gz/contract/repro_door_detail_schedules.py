"""Porta → "Chi Può Entrare": per una tipologia con fasce diverse per porta, la riga della porta mostra tutte le fasce
del profilo, compresa "Sempre" che il profilo porta solo perché le fasce sono diverse (vedi _build_profile)."""

import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()
# Seconda porta del controller con il suo punto di accesso e lettore
controller.access_points.append(
    {
        "token": "ap-cantina",
        "Entity": "porta2",
        "EntityType": "axtdc:Door",
        "Name": "Cantina",
        "Enabled": True,
        "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
        "Attribute": [{"Name": "Direction", "Value": "in"}],
    }
)
controller.access_controllers["Axis-x AccessController"]["AccessPoint"].append("ap-cantina")
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    ctrl_id = client.get("/api/installation").json()["controllers"][0]["id"]
    door2 = client.post(f"/api/controllers/{ctrl_id}/doors", json={"door_token": "porta2", "name": "Cantina"}).json()
    doors = {d["token"]: d["id"] for d in client.get("/api/door-overview").json()}
    print("porte:", doors)
    body = {
        "name": "Pulizie",
        "color": "green",
        "rules": [
            {"target": "door", "target_id": doors["porta"], "schedule": "standard_office_hours"},
            {"target": "door", "target_id": doors["porta2"], "schedule": "standard_always"},
        ],
    }
    r = client.post("/api/categories", json=body)
    print("tipologia:", r.status_code, r.json())
    token = r.json()["token"]
    profile = controller.profiles[token]
    print("profilo sul controller: Schedule =", profile["Schedule"])
    for p in profile["AccessPolicy"]:
        print("   regola", p["AccessPoint"], "→", p["Schedule"])
    detail = client.get(f"/api/door-detail/{doors['porta']}").json()
    for g in detail["groups"]:
        print(f"door-detail Ingresso → {g['name']}: schedule_names = {g['schedule_names']}")
    cat = next(c for c in client.get("/api/categories").json() if c["name"] == "Pulizie")
    print("pagina Tipologie (righe):", cat["rules"])

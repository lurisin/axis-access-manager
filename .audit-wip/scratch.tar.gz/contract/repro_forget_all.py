"""Persone → "Togli dall'App": la conferma conta le tessere non presenti dai dati caricati nella pagina, ma la richiesta
manda ids = null ("tutte quelle non presenti adesso"). Se nel frattempo la sincronizzazione ne ha segnate altre
(controller resettato), il server toglie anche quelle, con le persone."""

import tempfile
import time
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x", "access_profile": "profilo_sempre"}
)
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    time.sleep(1.5)
    for i, name in enumerate(["Anna", "Luca", "Marta", "Paolo"]):
        client.post("/api/persons", json={"name": name, "card": f"04a{i}"})
    # Una tessera tolta a mano dal controller: la pagina Persone mostra "1 Tessera Non Presente"
    anna = next(p for p in client.get("/api/persons").json() if p["name"] == "Anna")
    controller.credentials.pop(anna["cards"][0]["axis_credential_token"])
    client.post("/api/sync")
    page = client.get("/api/persons").json()
    n = sum(1 for p in page for c in p["cards"] if c["missing_since"])
    print(f"la pagina chiede: Togliere dall'app {'la tessera non presente' if n == 1 else f'le {n} tessere non presenti'}?")
    # Intanto il controller viene resettato e la sincronizzazione dei 15 minuti segna tutte le tessere
    controller.factory_reset()
    client.post("/api/sync")
    r = client.post("/api/missing-cards/forget", json={"ids": None}).json()
    print("risposta:", r, "| persone rimaste nell'app:", len(client.get("/api/persons").json()))

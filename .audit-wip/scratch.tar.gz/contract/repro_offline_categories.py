"""Controller spento: le tipologie (che stanno nel database dell'app) arrivano alla pagina solo con /api/groups, che
legge prima i profili dal controller e fallisce. La scheda persona mostra "Tipologia: Nessuna" e la finestra Accesso
propone "Nessuna" (value 0); salvando, il server scrive category_id 0 nel database prima di fallire sul controller."""

import tempfile
import time
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

controller = FakeController()
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x", "access_profile": "profilo_sempre"}
)
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    time.sleep(1.5)
    doors = {d["token"]: d["id"] for d in client.get("/api/door-overview").json()}
    cat = client.post(
        "/api/categories",
        json={"name": "Dipendenti", "rules": [{"target": "door", "target_id": doors["porta"], "schedule": "standard_always"}]},
    ).json()
    person = client.post("/api/persons", json={"name": "Anna", "card": "04aa", "category_id": cat["id"]}).json()
    print("prima: tipologia della persona =", person["category_id"])

    async def offline(*args, **kwargs):
        raise VapixError("il controller non risponde (ConnectTimeout)")

    controller.list_access_profiles = offline
    controller.get_credentials = offline
    r = client.get("/api/groups")
    print("GET /api/groups con il controller spento:", r.status_code, r.json())
    print("le tipologie sono nel database:", [c["name"] for c in app.state.db.list_categories()])
    # La pagina: categorySelect(p.category_id) senza tipologie caricate → <option value="0" selected>Nessuna</option>
    r = client.put(f"/api/persons/{person['id']}/access", json={"category_id": 0, "valid_from": "", "valid_to": ""})
    print("PUT accesso:", r.status_code, r.json())
    print("dopo l'errore: tipologia della persona =", app.state.db.get_person(person["id"])["category_id"])
    print("attività:", app.state.db.list_audit(limit=1)[0]["action"], "-", app.state.db.list_audit(limit=1)[0]["detail"])

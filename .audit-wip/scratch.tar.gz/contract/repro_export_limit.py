"""Impostazioni → "Registro CSV" (e il CSV del Registro): oltre EXPORT_LIMIT righe il file si ferma senza dirlo."""

import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import EXPORT_LIMIT, create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db")
with TestClient(app) as client:
    db = app.state.db
    start = datetime.now(tz=UTC) - timedelta(days=120)
    rows = []
    # 120 giorni di un ufficio: 30 passaggi con tessera all'ora per 14 ore (lettura + concesso)
    for i in range(120 * 14 * 30):
        ts = (start + timedelta(minutes=2 * i)).isoformat(timespec="seconds")
        rows += [(ts, "lettura", "04AA", "Anna", "porta"), (ts, "concesso", "04AA", "Anna", "porta")]
    with db._lock:
        db._conn.executemany(
            "INSERT INTO events (ts, kind, card, person_name, door) VALUES (?, ?, ?, ?, ?)", rows
        )
        db._conn.commit()
    total = db.count_matching_events()
    csv = client.get("/api/export/events.csv").text
    lines = csv.splitlines()
    print("eventi nel registro:", total, "| righe nel CSV (senza intestazione):", len(lines) - 1, "| limite:", EXPORT_LIMIT)
    print("primo evento del registro:", rows[0][0][:16], "| evento più vecchio nel CSV:", lines[-1].split(";")[0])

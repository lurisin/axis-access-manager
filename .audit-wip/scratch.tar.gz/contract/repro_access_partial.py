"""Modifica dell'accesso di una persona con una tessera "Non Sul Controller" (non la prima): la risposta è un errore
400, ma tipologia e profilo della prima tessera sono già cambiati; la scheda nella pagina non si ricarica."""

import tempfile
import time
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    time.sleep(1.5)
    doors = {d["token"]: d["id"] for d in client.get("/api/door-overview").json()}
    rule = [{"target": "door", "target_id": doors["porta"], "schedule": "standard_always"}]
    a = client.post("/api/categories", json={"name": "Dipendenti", "rules": rule}).json()
    rule2 = [{"target": "door", "target_id": doors["porta"], "schedule": "standard_office_hours"}]
    b = client.post("/api/categories", json={"name": "Ospiti", "rules": rule2}).json()
    person = client.post("/api/persons", json={"name": "Anna", "card": "04aa", "category_id": a["id"]}).json()
    person = client.post(f"/api/persons/{person['id']}/cards", json={"card": "04bb"}).json()
    # La seconda tessera sparisce dal controller (tolta a mano) e la sincronizzazione la segna
    second = person["cards"][1]["axis_credential_token"]
    controller.credentials.pop(second)
    client.post("/api/sync")
    before = client.get(f"/api/persons/{person['id']}").json()
    print("prima:", before["category_id"], [(c["number"], c["access_profile"], c["missing_since"] != "") for c in before["cards"]])
    r = client.put(f"/api/persons/{person['id']}/access", json={"category_id": b["id"], "valid_from": "", "valid_to": ""})
    print("risposta:", r.status_code, r.json())
    after = client.get(f"/api/persons/{person['id']}").json()
    print("dopo: ", after["category_id"], [(c["number"], c["access_profile"]) for c in after["cards"]])
    first = person["cards"][0]["axis_credential_token"]
    print("sul controller, prima tessera:", controller.credentials[first]["CredentialAccessProfile"][0]["AccessProfile"])

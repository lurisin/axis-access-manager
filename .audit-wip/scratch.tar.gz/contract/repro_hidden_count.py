"""Registro, vista "Da Controllare": il riquadro "N accessi riusciti non mostrati" usa i tipi della pagina
(ACCESS_KINDS = concesso,apertura_remota,uscita,citofono,lettura) invece della regola del server
(ACCESS_COUNT_KINDS = concesso, apertura_remota, uscita)."""

import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.db import local_day_start
from app.main import ACCESS_COUNT_KINDS, create_app

html = Path("axis_access_manager/app/static/index.html").read_text()
ui_kinds = re.search(r'const ACCESS_KINDS = "([^"]+)"', html).group(1)
print("ACCESS_KINDS della pagina:", ui_kinds)
print("ACCESS_COUNT_KINDS del server:", ",".join(ACCESS_COUNT_KINDS))

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db")
with TestClient(app) as client:
    db = app.state.db
    now = datetime.now(tz=UTC).isoformat(timespec="seconds")
    # Un passaggio con tessera concesso (lettura + concesso), un passaggio negato fuori fascia di una persona
    # registrata (lettura + negato) e una chiamata al citofono senza apertura
    db.add_event(ts=now, kind="lettura", card="04AA", person_name="Anna", door="porta")
    db.add_event(ts=now, kind="concesso", card="04AA", person_name="Anna", door="porta")
    db.add_event(ts=now, kind="lettura", card="04BB", person_name="Luca", door="porta")
    db.add_event(ts=now, kind="negato", card="04BB", person_name="Luca", detail="fuori fascia oraria", door="porta")
    db.add_event(ts=now, kind="citofono", detail="Citofono", door="porta")
    since = datetime.fromisoformat(local_day_start()).isoformat()
    shown = client.get("/api/events/count", params={"kind": "negato,sconosciuta,allarme,manomissione"}).json()
    hidden = client.get("/api/events/count", params={"kind": ui_kinds, "since": since}).json()
    dash = client.get("/api/dashboard").json()["today"]
    print("vista Da Controllare, eventi mostrati:", shown["count"])
    print("riquadro della pagina: 'accessi riusciti non mostrati (oggi)' =", hidden["count"])
    print("accessi di oggi secondo il cruscotto:", dash["granted"] + dash["remote"] + dash["exits"])

"""Ogni VapixError diventa 502 e la pagina, per ogni richiesta non GET con 502, apre "Il Controller Non Ha Risposto /
La modifica non è stata completata" con Riprova: anche per la prova di collegamento (nessuna modifica) e per
un rifiuto del controller (Fault) o credenziali sbagliate (il controller ha risposto)."""

import tempfile
from pathlib import Path

import httpx
from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app
from app.vapix import A1210Client

controller = FakeController()
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    controller.offline = True
    r = client.post("/api/controllers/test", json={"host": "10.0.0.9", "username": "root", "password": "x"})
    print("prova di collegamento, controller spento:", r.status_code, r.json())


# Risposte reali di un controller che risponde: 401 (credenziali) e Fault (richiesta rifiutata)
async def check(handler):
    client = A1210Client("10.0.0.9", "root", "x", transport=httpx.MockTransport(handler))
    try:
        await client.device_info()
    except Exception as err:  # noqa: BLE001
        return type(err).__name__, str(err)
    finally:
        await client.aclose()


import asyncio  # noqa: E402

print("401 dal controller →", asyncio.run(check(lambda req: httpx.Response(401))))
print(
    "Fault dal controller →",
    asyncio.run(check(lambda req: httpx.Response(200, json={"Fault": {"Reason": "InvalidArgVal"}}))),
)
print("(entrambe diventano 502 con l'exception_handler di VapixError in main.py)")

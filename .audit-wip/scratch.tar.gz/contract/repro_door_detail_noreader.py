"""Porta senza punti di accesso (nessun lettore): door-detail elenca in "Chi Può Entrare" tutte le tipologie."""

import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()  # "porta2" (Cantina) non ha punti di accesso né lettori
settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x", "access_profile": "profilo_sempre"}
)
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    ctrl_id = client.get("/api/installation").json()["controllers"][0]["id"]
    client.post(f"/api/controllers/{ctrl_id}/doors", json={"door_token": "porta2", "name": "Cantina"})
    doors = {d["token"]: d["id"] for d in client.get("/api/door-overview").json()}
    client.post(
        "/api/categories",
        json={"name": "Ospiti", "rules": [{"target": "door", "target_id": doors["porta"], "schedule": "standard_office_hours"}]},
    )
    detail = client.get(f"/api/door-detail/{doors['porta2']}").json()
    print("Cantina, lettori:", detail["readers"], "| Chi Può Entrare:", [(g["name"], g["schedule_names"]) for g in detail["groups"]])

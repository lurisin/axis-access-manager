"""Nuovo controller dalla pagina: il modulo manda sempre area_id (0 = "Nessuna Area", preselezionata), quindi la
regola del server per un controller nuovo senza area (_default_area: l'unica area, o la struttura predefinita) non
scatta mai; al riavvio ensure_default_site() lo sposta da solo."""

import tempfile
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "", "mqtt_topic_prefix": ""})
tmp = Path(tempfile.mkdtemp())
controller = FakeController()


def place(client):
    c = client.get("/api/installation").json()["controllers"][0]
    return c["area_id"], c["place"]


body = {
    "name": "Controller A1210",
    "host": "10.0.0.5",
    "username": "root",
    "password": "x",
    "mqtt_topic_prefix": "accessi/x",
    "verify_ssl": False,
    "description": "",
}
with TestClient(create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")) as client:
    site = client.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    client.post(f"/api/sites/{site}/areas", json={"name": "Reception"})
    # Come la pagina: area_id = Number(val(root, "area_id")) = 0 con "Nessuna Area" preselezionata
    print("POST come la pagina (area_id 0):", client.post("/api/controllers", json={**body, "area_id": 0}).json())
    print("  area dopo il salvataggio:", place(client))
with TestClient(create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")) as client:
    print("  area dopo il riavvio dell'add-on:", place(client))

tmp2 = Path(tempfile.mkdtemp())
with TestClient(create_app(settings, allow_any_client=True, controller=controller, db_path=tmp2 / "b.db")) as client:
    site = client.post("/api/sites", json={"name": "Hotel"}).json()["id"]
    client.post(f"/api/sites/{site}/areas", json={"name": "Reception"})
    print("POST senza area_id (regola del server):", client.post("/api/controllers", json=body).json())
    print("  area dopo il salvataggio:", place(client))

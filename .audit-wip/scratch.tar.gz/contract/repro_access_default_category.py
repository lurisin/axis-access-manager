"""Persona letta dal controller dopo l'avvio (senza tipologia): la finestra "Accesso di …" preseleziona la tipologia
predefinita (categorySelect(0)), quindi salvare anche solo la validità manda category_id della predefinita e il
server riscrive il profilo delle tessere con quello della tipologia predefinita."""

import tempfile
import time
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

controller = FakeController()
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    time.sleep(1.5)  # la manutenzione all'avvio (sincronizzazione e adopt_groups) è già passata
    # Tipologia predefinita "Ospiti" con il suo profilo
    doors = {d["token"]: d["id"] for d in client.get("/api/door-overview").json()}
    ospiti = client.post(
        "/api/categories",
        json={"name": "Ospiti", "rules": [{"target": "door", "target_id": doors["porta"], "schedule": "standard_office_hours"}]},
    ).json()
    client.put("/api/default-category", json={"category_id": ospiti["id"]})
    # Persona registrata sul controller con un altro strumento, con il profilo "profilo_sempre" (sempre)
    controller.add_existing("utente_mario", "Mario Rossi", "04aa")
    client.post("/api/sync")
    person = next(p for p in client.get("/api/persons").json() if p["name"] == "Mario Rossi")
    print("prima: tipologia", person["category_id"], "profilo", person["cards"][0]["access_profile"])
    # La pagina manda la tipologia preselezionata (la predefinita) anche se si cambia solo la scadenza
    body = {"category_id": ospiti["id"], "valid_from": "", "valid_to": "2030-01-01T00:00:00.000Z"}
    after = client.put(f"/api/persons/{person['id']}/access", json=body).json()
    print("dopo:  tipologia", after["category_id"], "profilo", after["cards"][0]["access_profile"])
    cred = next(c for c in controller.credentials.values() if c["UserToken"] == "utente_mario")
    print("sul controller:", cred["CredentialAccessProfile"])

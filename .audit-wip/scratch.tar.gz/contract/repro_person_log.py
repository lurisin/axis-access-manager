"""Scheda persona → "Tutto il Registro" (e "Tutti i Suoi Eventi"): la pagina cerca per nome (q=nome) invece di usare
person_id, che /api/events accetta: compaiono eventi di altre persone e mancano quelli registrati col nome di prima."""

import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x", "access_profile": "profilo_sempre"})
tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    luca = client.post("/api/persons", json={"name": "Luca", "card": "04aa"}).json()
    gian = client.post("/api/persons", json={"name": "Gianluca", "card": "04bb"}).json()
    db = app.state.db
    t = datetime.now(tz=UTC) - timedelta(hours=2)
    db.add_event(ts=t.isoformat(timespec="seconds"), kind="concesso", card="04AA", person_id=luca["id"], person_name="Luca")
    db.add_event(ts=(t + timedelta(minutes=1)).isoformat(timespec="seconds"), kind="concesso", card="04BB", person_id=gian["id"], person_name="Gianluca")
    # Poi "Luca" viene rinominato "Luca Bianchi": gli eventi vecchi restano con il nome di allora
    client.patch(f"/api/persons/{luca['id']}", json={"name": "Luca Bianchi"})
    db.add_event(ts=(t + timedelta(minutes=2)).isoformat(timespec="seconds"), kind="concesso", card="04AA", person_id=luca["id"], person_name="Luca Bianchi")
    p = client.get(f"/api/persons/{luca['id']}").json()
    print("scheda (person_id):", [(e["person_name"]) for e in p["events"]])
    via_name = client.get("/api/events", params={"q": p["name"]}).json()
    print("Tutto il Registro (q=nome attuale):", [e["person_name"] for e in via_name])
    old_name = client.get("/api/events", params={"q": "Luca"}).json()
    print("Tutti i Suoi Eventi da un evento vecchio (q='Luca'):", [e["person_name"] for e in old_name])
    print("con person_id:", [e["person_name"] for e in client.get("/api/events", params={"person_id": luca["id"]}).json()])

"""Registro: refreshLog() ridisegna solo se cambia l'elenco degli id. La foto (snapshot) e "· più pressioni" arrivano
dopo l'inserimento della riga: con gli stessi id la pagina tiene la riga vecchia, senza foto."""

import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from conftest import FakeController
from fastapi.testclient import TestClient

from app.config import parse_options
from app.main import create_app

html = Path("axis_access_manager/app/static/index.html").read_text()
print(re.search(r"async function refreshLog\(\) \{[\s\S]*?\n\}", html).group(0))
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db")
with TestClient(app) as client:
    db = app.state.db
    now = datetime.now(tz=UTC).isoformat(timespec="seconds")
    event_id = db.add_event(ts=now, kind="negato", card="04CC", detail="tessera non registrata", door="porta")
    first = client.get("/api/events", params={"kind": "negato,sconosciuta,allarme,manomissione", "limit": 100}).json()
    # after_event (main._wire) salva la foto qualche istante dopo l'inserimento
    db.set_event_snapshot(event_id, f"{event_id}_x.jpg")
    db.set_event_detail(event_id, "tessera non registrata · più pressioni")
    second = client.get("/api/events", params={"kind": "negato,sconosciuta,allarme,manomissione", "limit": 100}).json()
    same_ids = [e["id"] for e in first] == [e["id"] for e in second]
    print("stessi id:", same_ids, "| snapshot prima:", first[0]["snapshot"] or "''", "dopo:", second[0]["snapshot"])
    print("dettaglio prima:", first[0]["detail"], "| dopo:", second[0]["detail"])

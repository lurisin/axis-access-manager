"""Verifica: utente non amministratore con solo 'impianti' imposta una telecamera con '../' e fa leggere all'add-on
un endpoint Core API diverso da camera_proxy."""

import asyncio
import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

import httpx  # noqa: E402
from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import CORE_API, HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

requested = []


def handler(request: httpx.Request) -> httpx.Response:
    requested.append(request.url.raw_path.decode())
    if request.url.path == "/core/api/error_log":
        return httpx.Response(200, content=b"ERROR secret=XYZ", headers={"content-type": "text/plain"})
    if request.url.path == "/core/api/states":
        return httpx.Response(200, json=[{"entity_id": "camera.porta", "state": "idle", "attributes": {}}])
    return httpx.Response(404)


snapdir = Path(tempfile.mkdtemp())
ha = HomeAssistant(token="supervisor-token", snapshot_dir=snapdir)
ha._client = httpx.AsyncClient(
    base_url=CORE_API, headers={"Authorization": "Bearer supervisor-token"}, transport=httpx.MockTransport(handler)
)
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
app = create_app(
    settings, allow_any_client=True, controller=FakeController(), db_path=Path(tempfile.mkdtemp()) / "c.db", home_assistant=ha
)
ADMIN = {"X-Remote-User-Name": "admin", "X-Remote-User-Display-Name": "Admin"}
TECH = {"X-Remote-User-Name": "tecnico", "X-Remote-User-Display-Name": "Tecnico"}
with TestClient(app) as client:
    print("admin me:", client.get("/api/me", headers=ADMIN).json().get("role"))
    print("tecnico me:", client.get("/api/me", headers=TECH).json().get("role"))
    r = client.put("/api/users/tecnico", headers=ADMIN, json={"name": "Tecnico", "perms": ["impianti"]})
    print("admin assegna solo impianti:", r.status_code, r.json())
    door = client.app.state.db.list_doors()[0]
    body = {"door_token": door["door_token"], "name": door["name"], "snapshot_camera": "camera.x/../../error_log"}
    r = client.put(f"/api/doors/{door['id']}", json=body, headers=TECH)
    print("PUT porta dal tecnico:", r.status_code)
    ctrl = client.app.state.db.list_controllers()[0]
    r = client.put(f"/api/controllers/{ctrl['id']}/camera", json={"camera": "camera.x/../../../../addons/self/info"}, headers=TECH)
    print("PUT camera controller dal tecnico:", r.status_code, r.json())

    async def deny():
        row = client.app.state.service.log_event(
            ts="2026-10-28T08:00:00+00:00", kind="negato", card="0A1B", door=door["door_token"]
        )
        await asyncio.sleep(0.3)
        return row

    row = client.portal.call(deny)
    print("richieste ad HA:", requested)
    print("file:", [p.name for p in snapdir.iterdir()])
    r = client.get(f"/api/events/{row['id']}/snapshot", headers=ADMIN)
    print("GET istantanea:", r.status_code, r.headers.get("content-type"), r.content)
    r = client.get(f"/api/events/{row['id']}/snapshot", headers=TECH)
    print("GET istantanea dal tecnico (senza registro):", r.status_code)

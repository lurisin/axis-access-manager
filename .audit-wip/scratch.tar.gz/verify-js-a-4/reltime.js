const fs = require('fs');
const src = fs.readFileSync('/home/user/axis-access-manager/axis_access_manager/app/static/index.html', 'utf8');
const pick = (re) => src.match(re)[0];
const code = [
  pick(/const fmtDate = [^\n]*\n/), pick(/const fmtTime = [^\n]*\n/),
  pick(/function relTime\(iso\) \{[\s\S]*?\n\}\n/),
].join('\n');
function run(nowIso, evIso) {
  const RealDate = Date;
  const fixed = new RealDate(nowIso).getTime();
  class FakeDate extends RealDate { constructor(...a) { if (a.length === 0) super(fixed); else super(...a); } static now() { return fixed; } }
  const f = new Function('Date', code + '; return relTime;')(FakeDate);
  return f(evIso);
}
const now = '2026-10-28T10:00:00+01:00';
console.log('+40min', run(now, '2026-10-28T10:40:00+01:00'));
console.log('+3h', run(now, '2026-10-28T13:00:00+01:00'));
console.log('domani', run(now, '2026-10-29T10:00:00+01:00'));
console.log('-30s', run(now, '2026-10-28T09:59:30+01:00'));
console.log('DST lun 30/3 10:00, ev sab 28/3 23:30 ->', run('2026-03-30T10:00:00+02:00', '2026-03-28T23:30:00+01:00'));
console.log('DST lun 30/3 10:00, ev sab 28/3 22:30 ->', run('2026-03-30T10:00:00+02:00', '2026-03-28T22:30:00+01:00'));
console.log('DST end lun 26/10 10:00, ev dom 25/10 00:30 ->', run('2026-10-26T10:00:00+01:00', '2026-10-25T00:30:00+02:00'));

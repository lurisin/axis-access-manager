import os, tempfile, asyncio
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
from app.service import user_token_for

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})

def mk():
    c = FakeController()
    work = Path(tempfile.mkdtemp())
    return c, create_app(settings, allow_any_client=True, controller=c, db_path=work / "api.db")

# A: import with long common prefix
print("=== A: import")
c, app = mk()
a, b = "Cooperativa Sociale Pulizie Splendor - Mario Bianchi", "Cooperativa Sociale Pulizie Splendor - Luca Verdi"
print(user_token_for(a)[:-12], user_token_for(b)[:-12])
csv = f"nome;tessera\n{a};04a1\n{b};04b2\nTerzo Tizio;04c3\n"
with TestClient(app, raise_server_exceptions=False) as client:
    r = client.post("/api/import/persons", json={"csv": csv, "apply": True})
    print("import:", r.status_code, r.text[:200])
    print("app persons:", [(p["name"], [x["number"] for x in p["cards"]]) for p in client.get("/api/persons").json()])
    print("controller users:", {t: u["Name"] for t, u in c.users.items()})
    print("creds:", [(x["UserToken"], x["IdData"][0]["Value"]) for x in c.credentials.values()])
    client.post("/api/sync")
    print("after sync:", [(p["name"], [x["number"] for x in p["cards"]]) for p in client.get("/api/persons").json()])

# A2: accent variant
print("=== A2: accent / punctuation variants")
for x, y in [("Nicolò Rossi", "Nicolo Rossi"), ("D'Angelo Marco", "D Angelo Marco"), ("Mario Rossi", "Mario Rossi.")]:
    print(x, "|", y, user_token_for(x)[:-12] == user_token_for(y)[:-12])

# B: restore_missing with two "(Senza nome)" persons created from credentials without user
print("=== B: restore_missing")
c, app = mk()
with TestClient(app, raise_server_exceptions=False) as client:
    for i, num in enumerate(["0a01", "0a02", "0a03"]):
        c.credentials[f"cr{i}"] = {"token": f"cr{i}", "UserToken": "", "Description": "", "Enabled": True,
                                   "IdData": [{"Name": "Card", "Value": num}], "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre"}]}
    r = client.post("/api/sync"); print("sync1", r.status_code, r.text[:200])
    print("persons:", [(p["name"], p["axis_user_token"], [x["number"] for x in p["cards"]]) for p in client.get("/api/persons").json()])
    c.credentials.clear()
    r = client.post("/api/sync"); print("sync2", r.status_code, r.text[:200])
    r = client.post("/api/missing-cards/restore", json={"ids": None})
    print("restore:", r.status_code, r.text[:300])
    print("persons:", [(p["name"], p["axis_user_token"], [(x["number"], x["missing_since"]) for x in p["cards"]]) for p in client.get("/api/persons").json()])
    print("controller users:", list(c.users))
    print("creds:", [(x["UserToken"], x["IdData"][0]["Value"]) for x in c.credentials.values()])

import os, tempfile
from datetime import datetime as _dt
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app
import app.service as svc

class FrozenDT(_dt):
    @classmethod
    def now(cls, tz=None):
        if tz is None:
            return _dt(2026, 10, 28, 9, 0, 0)
        return _dt.now(tz)
svc.datetime = FrozenDT  # same second for every token (simulates rows processed within one second)

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
c = FakeController()
app = create_app(settings, allow_any_client=True, controller=c, db_path=Path(tempfile.mkdtemp()) / "api.db")
a, b = "Cooperativa Sociale Pulizie Splendor - Mario Bianchi", "Cooperativa Sociale Pulizie Splendor - Luca Verdi"
csv = f"nome;tessera\n{a};04a1\n{b};04b2\nTerzo Tizio;04c3\n"
with TestClient(app, raise_server_exceptions=False) as client:
    r = client.post("/api/import/persons", json={"csv": csv, "apply": True})
    print("import:", r.status_code, r.text[:200])
    print("app persons:", [(p["name"], [x["number"] for x in p["cards"]]) for p in client.get("/api/persons").json()])
    print("controller users:", {t: u["Name"] for t, u in c.users.items()})
    print("creds:", [(x["UserToken"], x["IdData"][0]["Value"]) for x in c.credentials.values()])
    client.post("/api/sync")
    print("after sync:", [(p["name"], [x["number"] for x in p["cards"]]) for p in client.get("/api/persons").json()])

print("=== B + sync")
c = FakeController()
app = create_app(settings, allow_any_client=True, controller=c, db_path=Path(tempfile.mkdtemp()) / "api.db")
with TestClient(app, raise_server_exceptions=False) as client:
    for i, num in enumerate(["0a01", "0a02", "0a03"]):
        c.credentials[f"cr{i}"] = {"token": f"cr{i}", "UserToken": "", "Description": "", "Enabled": True,
                                   "IdData": [{"Name": "Card", "Value": num}], "CredentialAccessProfile": [{"AccessProfile": "profilo_sempre"}]}
    client.post("/api/sync"); c.credentials.clear(); client.post("/api/sync")
    r = client.post("/api/missing-cards/restore", json={"ids": None}); print("restore:", r.status_code)
    client.post("/api/sync")
    print("after sync:", [(p["name"], p["axis_user_token"], [(x["number"], bool(x["missing_since"])) for x in p["cards"]]) for p in client.get("/api/persons").json()])

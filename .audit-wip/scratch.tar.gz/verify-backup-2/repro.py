import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

from conftest import FakeController
from test_backup import Plant

from app.backup import BackupError
from app.config import parse_options
from app.db import Database

SCRATCH = Path(__file__).parent


async def main():
    work = Path(tempfile.mkdtemp(dir=SCRATCH, prefix="w_"))
    settings = parse_options(
        {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
         "mqtt_topic_prefix": "accessi/x"}
    )
    db = Database(work / "test.db")
    plant = Plant(db, FakeController(), settings, work / "backup")
    key = f"controller:{plant.controller_id}"

    # Scenario: controller changes -> new part, then power loss -> 0 byte
    good = await plant.backup()
    await plant.programming.update_door("porta", {"access_time": 9}, "admin")
    changed = await plant.backups.create("automatico", "", "", plant.clients, skip_unchanged=True)
    print("changed summary:", changed["summary"])
    h = changed["parts"][key]["hash"]
    part = plant.backups.store.parts / f"{h}.json.gz"
    part.write_bytes(b"")

    now = datetime.now(tz=UTC)
    made = []
    for hour in range(1, 5):
        m = await plant.backups.run_scheduled(plant.clients, now=now + timedelta(minutes=61 * hour))
        made.append(m and (m["kind"], m["summary"], m["parts"][key]["hash"] == h))
    print("hourly:", made)
    print("before_change:", (await plant.backups.before_change("prima_modifica", "admin", plant.clients, window=False) or {}).get("summary"))
    v = plant.backups.verify()
    print("verify damaged", v["damaged"], "of", v["backups"])

    # restore from the good backup
    try:
        before = await plant.backups.create("prima_ripristino", "x", "admin", plant.clients)
        plant.backups.load(before["id"])
        print("load ok")
    except BackupError as err:
        print("restore aborted:", err)

    # Follow DOCS: delete damaged backups, then check again
    for m in plant.backups.store.list():
        try:
            plant.backups.load(m["id"])
        except BackupError:
            await plant.backups.delete(m["id"], "admin")
    print("part exists after deleting damaged:", part.exists())
    m = await plant.backups.run_scheduled(plant.clients, now=now + timedelta(hours=10))
    print("next scheduled:", m and (m["summary"], m["parts"][key]["hash"] == h), "size", part.stat().st_size if part.exists() else None)
    v = plant.backups.verify()
    print("verify after cleanup ok:", v["ok"], v["damaged"], "of", v["backups"])


asyncio.run(main())

const { chromium } = require("playwright");
(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  await ctl({ delay: { set_credential: 2 } });
  await page.goto(base + "/#persone");
  await page.waitForSelector("#p-new");
  // control: no Esc
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=name]");
  await page.fill("#modal [name=name]", "Luca Verdi");
  await page.fill("#modal [name=card]", "04E1E2E3");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(3000);
  const rows = await page.$$eval("#p-list .person-row", (r) => r.map((x) => x.querySelector(".name")?.textContent.trim()));
  // x button during save
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=name]");
  await page.fill("#modal [name=name]", "Sara Neri");
  await page.fill("#modal [name=card]", "04F1F2F3");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(300);
  await page.click("#modal [data-x]");
  await page.waitForTimeout(3000);
  const rows2 = await page.$$eval("#p-list .person-row", (r) => r.map((x) => x.querySelector(".name")?.textContent.trim()));
  // retry same card
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=name]");
  await page.fill("#modal [name=name]", "Sara Neri");
  await page.fill("#modal [name=card]", "04F1F2F3");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(3000);
  const toast = await page.$eval("#toast", (t) => t.style.display !== "none" ? t.textContent : "");
  console.log({ controlRows: rows, afterXRows: rows2, retryToast: toast });
  await ctl({ delay: {} });
  await browser.close();
})();

// Repro H: renderTopStatus ricrea i bollini ogni 5 s con innerHTML: il focus da tastiera si perde
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  await page.request.post(base + "/__event", { data: { ts: new Date().toISOString(), kind: "allarme", door: "porta", detail: "porta forzata" } });
  await page.goto(base + "/#porte");
  await page.waitForSelector('#top-status [data-pop="alarms"]');
  await page.focus('#top-status [data-pop="alarms"]');
  const before = await page.evaluate(() => document.activeElement?.dataset?.pop || document.activeElement?.tagName);
  await page.waitForTimeout(5600);
  const after = await page.evaluate(() => document.activeElement?.dataset?.pop || document.activeElement?.tagName);
  // Tendina aperta e focus su "Segna Tutti Come Visti"
  await page.click('#top-status [data-pop="alarms"]');
  await page.focus("#top-pop [data-pop-seen]");
  const popBefore = await page.evaluate(() => document.activeElement?.hasAttribute("data-pop-seen"));
  await page.waitForTimeout(5600);
  const popAfter = await page.evaluate(() => document.activeElement?.hasAttribute("data-pop-seen") || document.activeElement?.tagName);
  console.log({ chipFocusBefore: before, chipFocusAfter5s: after, popButtonFocusBefore: popBefore, popButtonFocusAfter5s: popAfter });
  await browser.close();
})();

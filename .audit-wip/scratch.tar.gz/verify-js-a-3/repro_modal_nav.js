// Repro G: un link dentro #modal cambia pagina ma la finestra resta aperta sopra la pagina nuova
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  const r = await page.request.post(base + "/api/persons", { data: { name: "Anna Bianchi", card: "04A1B2C3" } });
  const anna = await r.json();
  await page.request.post(base + "/__event", { data: { ts: new Date().toISOString(), kind: "concesso", door: "porta", card: "04A1B2C3", person_id: anna.id, person_name: "Anna Bianchi" } });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("[data-dash-events] [data-event]");
  await page.click("[data-dash-events] [data-event]");
  await page.waitForSelector("#modal[open]");
  await page.click('#modal a[href^="#porte/"]');
  await page.waitForTimeout(1200);
  console.log("dopo il link Porta:", { hash: await page.evaluate(() => location.hash), title: await page.textContent("#page-title"), modalOpen: await page.$eval("#modal", (d) => d.open), modalTitle: await page.$eval("#modal h2", (h) => h.textContent) });
  // Mentre #modal è aperta il refresh periodico e il ricaricamento dopo un aggiornamento restano fermi
  console.log("refreshView fermo con #modal aperta:", await page.evaluate(() => document.querySelector("#modal").open));
  await page.keyboard.press("Escape");
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("[data-dash-events] [data-event]");
  await page.click("[data-dash-events] [data-event]");
  await page.waitForSelector("#modal[open]");
  await page.click('#modal a[href^="#persone/"]');
  await page.waitForTimeout(1500);
  console.log("dopo Scheda Persona:", { hash: await page.evaluate(() => location.hash), modalOpen: await page.$eval("#modal", (d) => d.open), sheetOpen: await page.$eval("#sheet", (d) => d.open) });
  await page.click("#sheet [data-close]");
  await page.waitForTimeout(300);
  console.log("chiusa la scheda:", { modalOpen: await page.$eval("#modal", (d) => d.open), modalTitle: await page.$eval("#modal h2", (h) => h.textContent) });
  await browser.close();
})();

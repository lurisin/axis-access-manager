// Repro F: un 502 del proxy Ingress (add-on in riavvio, corpo non JSON) viene presentato come "Il Controller Non Ha Risposto"
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  await page.goto(base + "/#cruscotto");
  await page.waitForSelector("#dash");
  await page.click("#top-edit");
  await page.click('.dw[data-w="settimana"] [data-remove]');
  // Come risponde Home Assistant quando l'add-on non è raggiungibile: 502 text/plain "502: Bad Gateway"
  await page.route("**/api/dashboard/layout", (route) => route.request().method() === "PUT"
    ? route.fulfill({ status: 502, contentType: "text/plain", body: "502: Bad Gateway" }) : route.continue());
  await page.click("#dash-save");
  await page.waitForSelector("#retry[open]");
  console.log("titolo:", await page.$eval("#retry h2", (e) => e.textContent));
  console.log("testo:", await page.$eval("#retry .dlg-body", (e) => e.textContent.replace(/\s+/g, " ").trim()));
  await browser.close();
})();

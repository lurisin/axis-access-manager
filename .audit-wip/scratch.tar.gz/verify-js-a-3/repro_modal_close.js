// Repro D: la finestra si chiude con Esc o × mentre il salvataggio è in corso; chi la ha aperta riceve null
const { chromium } = require("playwright");

(async () => {
  const base = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1300, height: 900 } });
  const ctl = (body) => page.request.post(base + "/__ctl", { data: body });
  await ctl({ delay: {}, offline: [] });
  await page.goto(base + "/#persone");
  await page.waitForSelector("#p-new");
  const rowsBefore = await page.$$eval("#p-list .person-row", (r) => r.length);
  await ctl({ delay: { set_credential: 3 } });
  await page.click("#p-new");
  await page.waitForSelector("#modal[open] [name=name]");
  await page.fill("#modal [name=name]", "Paolo Gialli");
  await page.fill("#modal [name=card]", "04D1D2D3");
  await page.click("#modal .dlg-foot button.primary");
  await page.waitForTimeout(300);
  const disabled = await page.$$eval("#modal .dlg-foot button", (b) => b.map((x) => x.disabled));
  const xEnabled = await page.$eval("#modal [data-x]", (b) => !b.disabled);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  const closedEarly = !(await page.$eval("#modal", (d) => d.open));
  await page.waitForTimeout(3500);
  const toast = await page.$eval("#toast", (t) => t.style.display !== "none" ? t.textContent : "");
  const rowsAfter = await page.$$eval("#p-list .person-row", (r) => r.map((x) => x.textContent.trim()));
  const persons = await (await page.request.get(base + "/api/persons")).json();
  console.log({ rowsBefore, footerDisabled: disabled, closeButtonEnabled: xEnabled, closedWithEscDuringSave: closedEarly, toast, listAfter: rowsAfter, inDb: persons.map((p) => p.name) });
  await ctl({ delay: {} });
  await browser.close();
})();

import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    tok = c.post("/api/schedules", json={"name": "Uffici", "rules": [{"days": ["MO"], "start": "08:00", "end": "18:00"}], "holidays": True}).json()["token"]
    orig = ctrl.set_schedule
    async def offline(*a, **k):
        raise VapixError("il controller non risponde (ConnectTimeout)")
    ctrl.set_schedule = offline
    r = c.post("/api/holidays", json={"day": "2026-12-08", "name": "Immacolata", "yearly": True})
    print("add holiday while offline:", r.status_code, r.json())
    ctrl.set_schedule = orig
    print("holidays in app:", [h["day"] for h in c.get("/api/holidays").json()])
    print("exception on controller:", ctrl.schedules[tok].get("ExceptionScheduleDefinition"))
    # Controller di nuovo raggiungibile: sincronizzazione manuale, nessuna riscrittura delle fasce
    c.post("/api/sync")
    print("after sync, exception on controller:", ctrl.schedules[tok].get("ExceptionScheduleDefinition"))
    print("audit:", [(a["action"], a["detail"]) for a in c.get("/api/audit").json()][:2])

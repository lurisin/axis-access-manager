import asyncio, os, tempfile, sys
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from app.config import parse_options
from app.db import Database
import test_full_restore as tfr
from test_backup import Plant

async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    ctrl = FakeController()
    settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
    plant = Plant(db, ctrl, settings, tmp / "backup")
    tfr.bench_like(ctrl)
    await plant.rules.add_holidays([{"day": "2026-12-25", "name": "Natale", "yearly": True}], "admin")
    tok = (await plant.rules.create_schedule("Uffici", "", [{"days": ["MO"], "start": "08:00", "end": "18:00"}], True, "admin"))["token"]
    print("managed before:", db.schedule_rules().keys())
    backup = await plant.backup()
    ctrl.factory_reset()
    # Utente apre la pagina Persone / Regole: GET /api/groups -> list_schedules
    await plant.rules.list_schedules()
    print("managed after GET:", db.schedule_rules().keys())
    items, result = await tfr.full_restore(plant, backup["id"], password="segreta")
    print("restored schedule on controller:", tok in ctrl.schedules)
    print("managed after full restore:", db.schedule_rules().keys())
    sched = [s for s in await plant.rules.list_schedules() if s["token"] == tok][0]
    print("managed flag shown:", sched["managed"], "holidays:", sched["holidays"])
    # Nuova festività: la fascia non viene più aggiornata
    ctrl.calls.clear()
    await plant.rules.add_holidays([{"day": "2027-01-06", "name": "Epifania", "yearly": True}], "admin")
    print("set_schedule calls after new holiday:", [c for c in ctrl.calls if c[0] == "set_schedule"])
    print("exception now:", ctrl.schedules[tok].get("ExceptionScheduleDefinition"))

asyncio.run(main())

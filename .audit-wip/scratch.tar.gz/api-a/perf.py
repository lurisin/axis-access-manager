import tempfile, time, random
from datetime import UTC, datetime, timedelta
from pathlib import Path
from app.db import Database
db = Database(Path(tempfile.mkdtemp()) / "p.db")
start = datetime.now(tz=UTC) - timedelta(days=365)
rows = []
kinds = ["concesso", "lettura", "negato", "uscita", "apertura_remota"]
for i in range(100_000):
    ts = (start + timedelta(seconds=i * 315)).isoformat(timespec="seconds")
    rows.append((ts, random.choice(kinds), "04aa", 1, "Anna", "", "controller", "", "porta", 0, ""))
with db._lock:
    db._conn.executemany("INSERT INTO events (ts, kind, card, person_id, person_name, detail, source, raw, door, recovered, ref) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
    db._conn.commit()
for name, fn in [
    ("last_door_events", lambda: db.last_door_events(("concesso", "negato", "sconosciuta", "apertura_remota", "uscita", "citofono"))),
    ("last_accesses", db.last_accesses),
    ("list_events limit 8", lambda: db.list_events(limit=8)),
    ("count_matching kind", lambda: db.count_matching_events(kind="concesso")),
]:
    t = time.perf_counter(); fn(); print(name, round((time.perf_counter() - t) * 1000), "ms")

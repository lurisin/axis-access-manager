import os, tempfile
from datetime import UTC, datetime
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.events import Event
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    svc = app.state.service
    print("doors:", [d["door_token"] for d in app.state.doors])
    # Coperchio del controller aperto (manutenzione): evento senza porta, per scelta della 0.9.1
    svc.record_event(Event("Device", "Device/Casing/Open/", datetime.now(tz=UTC), {"Open": "1"}))
    rows = c.get("/api/events").json()
    print("event:", [(e["kind"], e["door"], e["detail"], e["source"]) for e in rows])
    ov = c.get("/api/door-overview").json()
    print("door overview today:", ov[0]["name"], ov[0]["today"])
    det = c.get(f"/api/door-detail/{ov[0]['id']}").json()
    print("door detail events:", [(e["kind"], e["detail"]) for e in det["events"]])

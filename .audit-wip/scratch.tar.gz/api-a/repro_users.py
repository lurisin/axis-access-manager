import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    admin = {"X-Remote-User-Id": "a1", "X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
    c.get("/api/me", headers=admin)
    guest = {"X-Remote-User-Id": "g1", "X-Remote-User-Name": "ospite", "X-Remote-User-Display-Name": "Ospite"}
    print("ospite:", c.get("/api/me", headers=guest).json()["perms"])
    # Utente HA che accede con il provider command_line (LDAP): il Supervisor non manda X-Remote-User-Name
    ldap = {"X-Remote-User-Id": "l1", "X-Remote-User-Display-Name": "Utente LDAP"}
    me = c.get("/api/me", headers=ldap).json()
    print("ldap me:", me["user"], me["admin"], me["role"])
    print("ldap GET /api/users:", c.get("/api/users", headers=ldap).status_code)
    r = c.put("/api/users/ospite", json={"perms": ["utenti"]}, headers=ldap)
    print("ldap promotes ospite to admin:", r.status_code, r.json().get("perms"))
    print("audit:", c.get("/api/audit", headers=admin).json()[0])

import os, tempfile, time
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    admin = {"X-Remote-User-Name": "rising"}
    c.get("/api/me", headers=admin)
    mario = {"X-Remote-User-Name": "mario", "X-Remote-User-Display-Name": "mario"}
    c.get("/api/me", headers=mario)
    r = c.put("/api/users/mario", json={"name": "Mario Rossi (Portineria)", "perms": ["stato"]}, headers=admin)
    print("saved:", r.json()["name"])
    app.state.users._seen.clear()  # come dopo un minuto
    c.get("/api/me", headers=mario)
    print("after mario opens app:", [u["name"] for u in c.get("/api/users", headers=admin).json()["users"] if u["username"] == "mario"])

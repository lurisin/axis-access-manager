import os, sys, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    r = c.post("/api/persons", json={"name": "Ospite Uno", "card": "04aa", "valid_from": "2026-10-28T08:00", "valid_to": "2026-11-30T18:00"})
    print(r.status_code, r.json()["cards"][0]["valid_to"])
    csv_text = c.get("/api/export/persons.csv").content.decode("utf-8")
    print(csv_text)
    r = c.post("/api/import/persons", json={"csv": csv_text, "apply": False})
    print(r.json())

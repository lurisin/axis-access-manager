import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from app.db import Database
from app.notifications import NotificationService

db = Database(Path(tempfile.mkdtemp()) / "n.db")
svc = NotificationService(db)
t0 = datetime(2026, 10, 27, 10, 0, tzinfo=UTC)
for m in (0, 3, 6):
    db.add_event(ts=(t0 + timedelta(minutes=m)).isoformat(timespec="seconds"), kind="allarme", detail="porta aperta troppo a lungo", door="porta")
args = dict(mqtt_configured=False, mqtt_connected=False, controller_configured=False, controller_online=None, sync={}, door_names={"porta": "Porta"})
now = t0 + timedelta(minutes=10)
cur = svc.collect(now=now, **args)
svc.mark_seen([i["id"] for i in cur], cur)
print("visto:", [(i["id"], i["title"]) for i in svc.listing(cur)["items"]], svc.listing(cur)["open"])
# 24 ore e 1 minuto dopo il primo allarme: nessun allarme nuovo
now = t0 + timedelta(hours=24, minutes=1)
cur = svc.collect(now=now, **args)
lst = svc.listing(cur)
print("dopo 24h:", [(i["id"], i["title"], i["seen"]) for i in lst["items"]], "da gestire:", lst["open"])

import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    cats = c.get("/api/categories").json()
    print("categories:", [(x["id"], x["name"], x["group_token"]) for x in cats])
    doors = app.state.doors
    new = c.post("/api/categories", json={"name": "Pulizie", "rules": [{"target": "door", "target_id": doors[0]["id"], "schedule": "standard_office_hours"}]}).json()
    print("new category:", new)
    p = c.post("/api/persons", json={"name": "Anna", "card": "04aa"}).json()
    print("person:", p["category_id"], p["cards"][0]["access_profile"])
    async def offline(*a, **k):
        raise VapixError("il controller non risponde (ConnectTimeout)")
    orig = ctrl.get_credentials
    ctrl.get_credentials = offline
    r = c.put(f"/api/persons/{p['id']}/access", json={"group": "", "valid_from": "", "valid_to": "", "category_id": new["id"]})
    print("change category while offline:", r.status_code, r.json())
    ctrl.get_credentials = orig
    q = c.get(f"/api/persons/{p['id']}").json()
    print("after: category", q["category_id"], "card profile", q["cards"][0]["access_profile"], "controller profile", list(ctrl.credentials.values())[0]["CredentialAccessProfile"])
    print("audit:", [(a["action"], a["detail"]) for a in c.get("/api/audit").json()][:2])

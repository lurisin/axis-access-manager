import os, tempfile
from datetime import UTC, datetime
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.events import Event
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    p = c.post("/api/persons", json={"name": "Anna", "card": "04aa"}).json()
    c.patch(f"/api/cards/{p['cards'][0]['id']}", json={"enabled": False})
    svc = app.state.service
    now = datetime.now(tz=UTC)
    tok = p["cards"][0]["axis_credential_token"]
    svc.record_event(Event("IdPoint", "IdPoint/Request/IdData/$source/IdPointToken/lettore-1", now, {"Card": "04aa"}))
    svc.record_event(Event("AccessControl", "AccessControl/Denied/Credential/$source/AccessPointToken/ap-in", now, {"CredentialToken": tok, "Reason": "CredentialNotEnabled", "AccessPointToken": "ap-in"}))
    print("events:", [(e["kind"], e["detail"]) for e in c.get("/api/events").json()])
    print("persona last_access:", c.get(f"/api/persons/{p['id']}").json()["last_access"])
    print(c.get("/api/export/persons.csv").content.decode().splitlines()[1])

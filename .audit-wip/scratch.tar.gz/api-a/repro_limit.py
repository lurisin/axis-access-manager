import os, tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app, raise_server_exceptions=False) as c:
    db = app.state.db
    for i in range(1200):
        db.add_event(ts=(datetime.now(tz=UTC) - timedelta(minutes=i)).isoformat(timespec="seconds"), kind="concesso")
    print("limit=100:", len(c.get("/api/events?limit=100").json()))
    print("limit=-1:", len(c.get("/api/events?limit=-1").json()))
    print("italia year=10000:", c.post("/api/holidays/italia", json={"year": 10000}).status_code)

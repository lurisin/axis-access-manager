import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    # Installatore: primo utente, amministratore
    c.get("/api/me", headers={"X-Remote-User-Id": "u1", "X-Remote-User-Name": "tecnico"})
    # In Home Assistant l'username viene cambiato (Impostazioni → Persone → Cambia nome utente)
    me = c.get("/api/me", headers={"X-Remote-User-Id": "u1", "X-Remote-User-Name": "tecnico.rossi"}).json()
    print("stesso utente HA, nuovo username:", me["role"], me["admin"])
    print("gestione utenti:", c.get("/api/users", headers={"X-Remote-User-Id": "u1", "X-Remote-User-Name": "tecnico.rossi"}).status_code)
    # Un altro utente HA creato poi con il vecchio username eredita l'amministrazione
    me = c.get("/api/me", headers={"X-Remote-User-Id": "u9", "X-Remote-User-Name": "tecnico"}).json()
    print("nuovo utente HA con il vecchio username:", me["role"], me["admin"])

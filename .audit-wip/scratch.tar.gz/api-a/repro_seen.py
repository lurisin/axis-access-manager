import os, tempfile
from datetime import UTC, datetime
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    admin = {"X-Remote-User-Name": "rising"}
    c.get("/api/me", headers=admin)
    stato = {"X-Remote-User-Name": "portiere"}
    c.get("/api/me", headers=stato)  # Solo Stato
    db = app.state.db
    now = datetime.now(tz=UTC).isoformat(timespec="seconds")
    eid = db.add_event(ts=now, kind="allarme", detail="porta forzata", source="porta", door="porta")
    s = c.get("/api/summary", headers=admin).json()
    print("admin alarms before:", [(a["id"], a["seen"]) for a in s["alarms"]])
    print("portiere sees:", [i["id"] for i in c.get("/api/notifications", headers=stato).json()["items"]])
    gid = f"g{eid}-{eid}"
    r = c.post("/api/notifications/seen", json={"ids": [gid]}, headers=stato)
    print("portiere marks hidden alarm seen:", r.status_code, r.json())
    s = c.get("/api/summary", headers=admin).json()
    print("admin alarms after:", s["alarms"])
    print("audit:", [a["action"] for a in c.get("/api/audit", headers=admin).json()][:3])

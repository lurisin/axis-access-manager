import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    tok = c.post("/api/schedules", json={"name": "Uffici", "rules": [{"days": ["MO"], "start": "08:00", "end": "18:00"}], "holidays": True}).json()["token"]
    c.post("/api/holidays/italia", json={"year": 2026})
    c.post("/api/holidays/italia", json={"year": 2027})  # l'anno dopo, per la Pasquetta 2028
    hol = c.get("/api/holidays").json()
    print(len(hol), "festività")
    print([ (h["day"], h["name"]) for h in hol if h["name"] == "Natale"])
    print("VEVENT nel calendario eccezioni:", ctrl.schedules[tok]["ExceptionScheduleDefinition"].count("BEGIN:VEVENT"))


import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
from app.vapix import VapixError

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    db = app.state.db
    # Dopo la migrazione 0.10: due tipologie con lo stesso profilo (quello predefinito)
    door = app.state.doors[0]["id"]
    ospiti = db.save_category(None, {"name": "Ospiti", "color": "blue", "group_token": "profilo_sempre", "valid_days": 0, "description": ""})
    db.set_category_rules(ospiti, [{"target": "door", "target_id": door, "schedule": "standard_always"}])
    ids = []
    for i, n in enumerate(["Anna", "Bruno", "Carla"]):
        p = c.post("/api/persons", json={"name": n, "card": f"04a{i}", "category_id": ospiti}).json()
        ids.append(p["id"])
    print("profiles:", [c.get(f"/api/persons/{i}").json()["cards"][0]["access_profile"] for i in ids])
    # Il controller va in timeout alla seconda tessera
    orig = ctrl.set_credential
    n = {"k": 0}
    async def flaky(cred):
        n["k"] += 1
        if n["k"] == 2:
            raise VapixError("il controller non risponde (ReadTimeout)")
        return await orig(cred)
    ctrl.set_credential = flaky
    body = {"name": "Ospiti", "color": "blue", "rules": [{"target": "door", "target_id": door, "schedule": "standard_office_hours"}]}
    r = c.put(f"/api/categories/{ospiti}", json=body)
    print("first try:", r.status_code, r.json())
    r = c.put(f"/api/categories/{ospiti}", json=body)  # Riprova
    print("retry:", r.status_code, r.json())
    cat = [x for x in c.get("/api/categories").json() if x["id"] == ospiti][0]
    print("category token:", cat["group_token"], "custom:", cat["custom"])
    print("profiles:", [c.get(f"/api/persons/{i}").json()["cards"][0]["access_profile"] for i in ids])

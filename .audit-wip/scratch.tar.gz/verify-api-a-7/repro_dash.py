import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
ctrl = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=ctrl, db_path=tmp / "a.db")
with TestClient(app) as c:
    st = app.state
    c.portal.call(st.health.check_all)
    def show(label):
        d = c.get("/api/dashboard").json()["system"]
        n = [(i["title"], i["text"]) for i in c.get("/api/notifications").json()["items"] if i["type"] in ("controller", "mqtt")]
        h = [(x.get("name"), x.get("health", {}).get("online"), x.get("health", {}).get("unreachable")) for x in c.get("/api/installation").json()["controllers"]]
        print(label, "| health:", h, "| dashboard controller_online:", d["controller_online"], "mqtt:", d["mqtt_connected"], "| notifiche:", n)
    show("1) senza MQTT, controller risponde")
    # MQTT configurato e collegato, controller risponde via HTTPS ma LWT offline
    st.mqtt = st.mqtt or object()
    st.monitor.connected = True
    st.monitor.controller_online = False
    show("2) LWT offline, HTTPS ok")
    # LWT online, ma il controller non risponde più via HTTPS
    st.monitor.controller_online = True
    ctrl.offline = True
    c.portal.call(st.health.check_all)
    c.portal.call(st.health.check_all)
    show("3) LWT online, HTTPS ko")

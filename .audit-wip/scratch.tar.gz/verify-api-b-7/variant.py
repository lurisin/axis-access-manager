"""Controller resettato: aprendo Persone (api/groups) l'app cancella le regole delle sue fasce; il Ripristino Completo
ricrea le fasce sul controller ma non le regole nell'app, e le festività aggiunte dopo non arrivano più al controller."""
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    office = client.post("/api/schedules", json={"name": "Uffici", "holidays": True, "rules": [
        {"days": ["MO", "TU", "WE", "TH", "FR"], "start": "08:00", "end": "18:00"}]}, headers=admin).json()
    client.post("/api/holidays", json={"day": "2026-12-25", "name": "Natale"}, headers=admin)
    print("regole nell'app:", list(app.state.db.schedule_rules()))
    backup = client.post("/api/backups", json={"name": "prima del reset"}, headers=admin).json()
    controller.factory_reset()
    import sys
    if sys.argv[1:] == ["groups"]: client.get("/api/groups", headers=admin)
    print("regole dopo aver aperto Persone:", list(app.state.db.schedule_rules()))
    body = {"sections": ["dispositivo", "controller", "tessere"], "part": "controller:1"}
    items = client.post(f"/api/backups/{backup['id']}/preview", json=body, headers=admin).json()["items"]
    keys = [i["key"] for i in items if not i["blocked"]]
    result = client.post(f"/api/backups/{backup['id']}/restore", json={**body, "keys": keys}, headers=admin).json()
    print("ripristino completo:", len(result["applied"]), "righe,", len(result["failed"]), "non riuscite")
    print("fascia sul controller:", office["token"] in controller.schedules,
          "| regole nell'app:", list(app.state.db.schedule_rules()))
    client.post("/api/holidays", json={"day": "2027-01-01", "name": "Capodanno"}, headers=admin)
    exceptions = controller.schedules[office["token"]].get("ExceptionScheduleDefinition") or ""
    print("Capodanno 2027 nelle eccezioni della fascia sul controller:", "20270101" in exceptions)
    s = [x for x in client.get("/api/schedules", headers=admin).json() if x["token"] == office["token"]][0]
    print("dopo il ripristino: managed=", s["managed"], "holidays=", s["holidays"], "name=", s["name"])
    print("stato fascia nel nuovo backup:", [x for x in client.post("/api/backups", json={"name": "dopo"}, headers=admin).json().get("id", []) and []])

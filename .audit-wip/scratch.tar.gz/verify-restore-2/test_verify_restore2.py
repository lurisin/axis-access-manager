import sys
sys.path.insert(0, "/home/user/axis-access-manager/tests")
from conftest import *  # noqa
from test_backup import plant  # noqa: F401  fixture


async def test_only_new_card(plant, controller, db):
    anna = await plant.access.create_person("Anna", "04aa", "admin")
    bruno = await plant.access.create_person("Bruno", "04bb", "admin")
    backup = await plant.backup()
    await plant.access.add_card(anna["id"], "04cc", "admin")
    await plant.access.delete_person(bruno["id"], "admin")
    items, result = await plant.restore(backup["id"], ["persone"])
    for i in items:
        print("ITEM", i["label"], i["action"], i["default"], i["blocked"], i["changes"], i["warnings"])
    print("RESULT", result)
    a = db.get_person(anna["id"])
    print("ANNA CARDS", [c["number"] for c in a["cards"]])
    print("CTRL creds", sorted(c.get("IdData", c) if False else k for k in controller.credentials))
    print("card_by_number 04cc", db.card_by_number("04cc"))


async def test_card_moved(plant, controller, db):
    anna = await plant.access.create_person("Anna", "04aa", "admin")
    bruno = await plant.access.create_person("Bruno", "04bb", "admin")
    backup = await plant.backup()
    await plant.access.delete_person(anna["id"], "admin")
    await plant.access.add_card(bruno["id"], "04aa", "admin")
    items, result = await plant.restore(backup["id"], ["persone"])
    for i in items:
        print("ITEM", i["label"], i["action"], i["default"], i["blocked"], i["changes"], i["warnings"])
    print("RESULT", result)
    print("card_by_number 04aa", db.card_by_number("04aa"))
    b = db.get_person(bruno["id"])
    print("BRUNO CARDS", [c["number"] for c in b["cards"]])
    print("CTRL creds n", len(controller.credentials))

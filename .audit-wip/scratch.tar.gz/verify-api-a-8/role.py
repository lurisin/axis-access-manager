import os, tempfile
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=Path(tempfile.mkdtemp()) / "a.db")
with TestClient(app) as c:
    admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}
    c.get("/api/me", headers=admin)
    r = c.post("/api/users", json={"username": "mario", "name": "Mario", "perms": ["stato", "persone_modifica"]}, headers=admin)
    print(r.status_code)
    for a in c.get("/api/audit", headers=admin).json()[:2]:
        print(a)

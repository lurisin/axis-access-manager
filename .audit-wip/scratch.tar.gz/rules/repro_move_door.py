"""Porta spostata fuori dall'unica area coperta da una tipologia: il profilo resta e la porta si apre ancora."""

import asyncio
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "tests")
from conftest import FakeController  # noqa: E402
from test_rules_service import place, row  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.db import Database  # noqa: E402
from app.rules_service import RulesService  # noqa: E402
from app.service import AccessService  # noqa: E402


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    controller.access_points.append(
        {"token": "ap-cantina", "Entity": "porta2", "Attribute": [{"Name": "Direction", "Value": "in"}]}
    )
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"}
    )
    rules = RulesService(AccessService(db, controller, settings))
    ids = place(db)
    # Pulizie: solo l'area Locali Tecnici, dove c'e' solo la Cantina
    clean = await rules.save_category(None, {"name": "Pulizie", "rules": [row("area", ids["tech"])]}, "a")
    print("prima:", [p["AccessPoint"] for p in controller.profiles[clean["token"]]["AccessPolicy"]])
    # L'amministratore sposta la Cantina nell'area Camere: Pulizie non deve piu' aprirla
    db.set_door_area(ids["cantina"], ids["rooms"])
    changed = await rules.refresh_category_profiles()
    print("profili aggiornati:", changed)
    print("dopo:", [p["AccessPoint"] for p in controller.profiles[clean["token"]]["AccessPolicy"]])
    print("Pulizie nel DB dice:", rules._door_schedules(db.category_rules(clean["id"])))


asyncio.run(main())

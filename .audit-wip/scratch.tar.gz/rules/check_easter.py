import sys
from datetime import date, timedelta
from app.rules import easter, italian_holidays, holidays_ical, parse_schedule_ical, schedule_ical, normalize_rules, describe_rules
# Gauss algorithm (Anonymous Gregorian) cross-check via different formulation (Oudin)
def oudin(y):
    g = y % 19; c = y // 100
    h = (c - c // 4 - (8 * c + 13) // 25 + 19 * g + 15) % 30
    i = h - (h // 28) * (1 - (h // 28) * (29 // (h + 1)) * ((21 - g) // 11))
    j = (y + y // 4 + i + 2 - c + c // 4) % 7
    l = i - j
    m = 3 + (l + 40) // 44
    d = l + 28 - 31 * (m // 4)
    return date(y, m, d)
bad = [y for y in range(1900, 2300) if easter(y) != oudin(y)]
print("easter mismatches:", bad)
try:
    from dateutil.easter import easter as de
    print("dateutil mismatches:", [y for y in range(1583, 4000) if easter(y) != de(y)])
except ImportError:
    print("no dateutil")
h = italian_holidays([2026, 2027])
print([x["day"] for x in h])
print("4 ottobre presente:", any(x["day"].endswith("-10-04") for x in h))
# round trip
for rules in ([{"days": ["MO","TU","WE","TH","FR","SA","SU"], "start": "00:00", "end": "24:00"}],
              [{"days": ["SA"], "start": "22:00", "end": "24:00"}, {"days": ["SU"], "start": "00:00", "end": "06:00"}]):
    print(parse_schedule_ical(schedule_ical(rules)) == rules)

"""Tipologia con profilo in comune: salvandola le persone passano al nuovo profilo una alla volta.
Una tessera 'Non Sul Controller' interrompe il ciclo e le persone successive restano sul profilo vecchio,
e risalvando la tipologia non vengono più spostate (old_token == token)."""

import asyncio
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "tests")
from conftest import FakeController  # noqa: E402
from test_rules_service import place, row  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.db import Database  # noqa: E402
from app.rules_service import RulesService  # noqa: E402
from app.service import AccessService, ServiceError  # noqa: E402


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"}
    )
    rules = RulesService(AccessService(db, controller, settings))
    ids = place(db)
    db.set_setting("default_group", "profilo_sempre")
    # Come dopo la migrazione 0.10: due tipologie sullo stesso profilo
    ospite = db.save_category(
        None, {"name": "Ospite", "color": "purple", "group_token": "profilo_sempre", "valid_days": 0, "description": ""}
    )
    db.set_category_rules(ospite, [row("door", ids["scala"])])
    altra = db.save_category(
        None, {"name": "Dipendente", "color": "blue", "group_token": "profilo_sempre", "valid_days": 0, "description": ""}
    )
    db.set_category_rules(altra, [row("door", ids["scala"])])
    persons = []
    for name, card in (("Anna", "04aa"), ("Bruno", "04bb"), ("Carla", "04cc")):
        persons.append(await rules.access.create_person(name, card, "admin", category_id=ospite))
    # La tessera di Anna è sparita dal controller (reset parziale): resta in app "Non Sul Controller"
    controller.credentials.pop(persons[0]["cards"][0]["axis_credential_token"])
    db.mark_cards_missing([persons[0]["cards"][0]["id"]], "2026-10-28T08:00:00Z")

    fields = {"name": "Ospite", "rules": [row("door", ids["scala"], "standard_office_hours")]}
    try:
        await rules.save_category(ospite, fields, "admin")
    except ServiceError as err:
        print("errore mostrato:", err)
    new_token = db.get_category(ospite)["group_token"]
    print("profilo della tipologia:", new_token)
    for p in persons:
        print(" ", p["name"], db.get_person(p["id"])["cards"][0]["access_profile"])
    result = await rules.save_category(ospite, fields, "admin")
    print("risalvata, persone spostate:", result["updated"])
    for p in persons:
        print(" ", p["name"], db.get_person(p["id"])["cards"][0]["access_profile"])


asyncio.run(main())

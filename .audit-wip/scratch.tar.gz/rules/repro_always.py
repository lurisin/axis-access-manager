"""La fascia 'Sempre' (standard_always) si può modificare, ma l'app la usa come fascia 'neutra' del profilo
delle tipologie con fasce diverse per porta (l'A1210 valuta profilo E regola)."""
import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from test_rules_service import place, row
from app.config import parse_options
from app.db import Database
from app.rules_service import RulesService
from app.service import AccessService

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = FakeController()
    c.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Attribute": [{"Name": "Direction", "Value": "in"}]})
    s = parse_options({"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"})
    r = RulesService(AccessService(db, c, s))
    ids = place(db)
    h24 = (await r.create_schedule("H24 Reperibili", "", [{"days": ["MO","TU","WE","TH","FR","SA","SU"], "start": "00:00", "end": "24:00"}], False, "a"))["token"]
    cat = await r.save_category(None, {"name": "Tecnico", "rules": [row("door", ids["scala"], h24), row("door", ids["cantina"], "standard_office_hours")]}, "a")
    prof = c.profiles[cat["token"]]
    print("profilo Tecnico: Schedule", prof["Schedule"], {p["AccessPoint"]: p["Schedule"] for p in prof["AccessPolicy"]})
    listed = {x["token"]: x for x in await r.list_schedules()}
    print("'Sempre' usata da:", listed["standard_always"]["groups"])
    # L'amministratore limita 'Sempre' (es. per chi ha la fascia Sempre su una porta secondaria)
    await r.update_schedule("standard_always", "Sempre", "", [{"days": ["MO","TU","WE","TH","FR"], "start": "07:00", "end": "20:00"}], True, "a")
    print("ora il Varco Scala per Tecnico = H24 AND 'Sempre' (lun-ven 7-20, no festivi), non più H24")

asyncio.run(main())

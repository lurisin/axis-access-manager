"""Tipologia il cui profilo non ha regole su porte dell'app: adopt_groups la 'sistema' a ogni avvio."""
import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from test_rules_service import place
from app.config import parse_options
from app.db import Database
from app.rules_service import RulesService
from app.service import AccessService

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = FakeController()
    c.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Attribute": []})
    c.profiles["cantina"] = {"token": "cantina", "Name": "Cantina", "Schedule": ["standard_always"],
        "AccessPolicy": [{"AccessPoint": "ap-cantina", "Schedule": ["standard_always"]}]}
    s = parse_options({"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"})
    r = RulesService(AccessService(db, c, s))
    ids = place(db)
    db.delete_door(ids["cantina"])  # porta2 non gestita dall'app
    db.save_category(None, {"name": "Cantina", "color": "blue", "group_token": "cantina", "valid_days": 0, "description": ""})
    for boot in range(3):
        print("avvio", boot, "adopt_groups =", await r.adopt_groups())
    print([a["detail"] for a in db.list_audit() if a["action"] == "gruppi passati alle tipologie"])

asyncio.run(main())

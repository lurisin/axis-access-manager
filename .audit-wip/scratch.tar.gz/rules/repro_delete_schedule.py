"""Fascia usata solo da una riga Dove e Quando su un'area ancora senza lettori: si elimina senza avviso.
Quando una porta entra nell'area, il profilo della tipologia riceve una fascia che non esiste più."""

import asyncio
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "tests")
from conftest import FakeController  # noqa: E402
from test_rules_service import place, row  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.db import Database  # noqa: E402
from app.rules_service import RulesService  # noqa: E402
from app.service import AccessService, ServiceError  # noqa: E402

NIGHT = [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "20:00", "end": "24:00"}]


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    controller.access_points.append(
        {"token": "ap-cantina", "Entity": "porta2", "Attribute": [{"Name": "Direction", "Value": "in"}]}
    )
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"}
    )
    rules = RulesService(AccessService(db, controller, settings))
    ids = place(db)
    empty_area = db.save_area(None, ids["site"], "Magazzino")  # area senza porte, per ora
    night = (await rules.create_schedule("Notte", "", NIGHT, True, "admin"))["token"]
    cat = await rules.save_category(
        None, {"name": "Vigilanza", "rules": [row("door", ids["scala"]), row("area", empty_area, night)]}, "admin"
    )
    listed = {s["token"]: s for s in await rules.list_schedules()}
    print("fascia Notte 'usata da':", listed[night]["groups"], "-> il tasto Elimina compare")
    await rules.delete_schedule(night, "admin")
    print("eliminata; righe della tipologia:", db.category_rules(cat["id"]))
    # La Cantina entra nel Magazzino
    db.set_door_area(ids["cantina"], empty_area)
    await rules.refresh_category_profiles()
    policies = {p["AccessPoint"]: p["Schedule"] for p in controller.profiles[cat["token"]]["AccessPolicy"]}
    print("profilo scritto:", policies, "fasce sul controller:", sorted(controller.schedules))
    try:
        await rules.save_category(
            cat["id"], {"name": "Vigilanza", "rules": [row("door", ids["scala"]), row("area", empty_area, night)]}, "a"
        )
    except ServiceError as err:
        print("modifica della tipologia:", err)


asyncio.run(main())

"""Una lettura delle fasce mentre il controller non le ha (reset, controller diverso all'indirizzo) cancella
per sempre le regole dell'app: dopo il ripristino le festività non si applicano più a quelle fasce."""

import asyncio
import copy
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "tests")
from conftest import FakeController  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.db import Database  # noqa: E402
from app.rules_service import RulesService  # noqa: E402
from app.service import AccessService  # noqa: E402

OFFICE = [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "08:00", "end": "18:00"}]


async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "t.db")
    controller = FakeController()
    settings = parse_options(
        {"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"}
    )
    rules = RulesService(AccessService(db, controller, settings))
    token = (await rules.create_schedule("Ufficio", "", OFFICE, True, "admin"))["token"]
    await rules.add_holidays([{"day": "2026-12-25", "name": "Natale", "yearly": True}], "admin")
    saved = copy.deepcopy(controller.schedules[token])
    print("managed prima:", token in db.schedule_rules())

    # Reset del controller (o un altro A1210 risponde all'indirizzo): l'utente apre Persone/Tipologie/Fasce
    controller.schedules.pop(token)
    await rules.list_schedules()  # GET /api/schedules o /api/groups
    print("managed dopo la lettura:", token in db.schedule_rules())

    # Ripristino completo: la fascia torna con lo stesso token
    controller.schedules[token] = saved
    await rules.add_holidays([{"day": "2027-08-16", "name": "Ponte", "yearly": False}], "admin")
    exc = controller.schedules[token]["ExceptionScheduleDefinition"]
    print("ponte 16/08 nella fascia:", "20270816" in exc)
    listed = {s["token"]: s for s in await rules.list_schedules()}[token]
    print("managed:", listed["managed"], "nome:", listed["name"])


asyncio.run(main())

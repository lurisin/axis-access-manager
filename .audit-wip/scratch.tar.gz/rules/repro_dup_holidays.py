import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.rules_service import RulesService
from app.service import AccessService

OFFICE = [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "08:00", "end": "18:00"}]

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    c = FakeController()
    s = parse_options({"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"})
    r = RulesService(AccessService(db, c, s))
    tok = (await r.create_schedule("Ufficio", "", OFFICE, True, "a"))["token"]
    await r.add_italian_holidays(2026, "a")   # clic nel 2026
    await r.add_italian_holidays(2027, "a")   # clic nel 2027 per avere la Pasquetta 2028
    hol = db.list_holidays()
    print(len(hol), "righe;", [ (h["day"], h["name"]) for h in hol if h["name"] == "Immacolata Concezione"])
    # L'azienda decide di lavorare l'8 dicembre: l'utente elimina la riga dell'Immacolata che vede
    await r.delete_holiday("2027-12-08", "a")
    exc = c.schedules[tok]["ExceptionScheduleDefinition"]
    print("8 dicembre ancora escluso:", "BYMONTH=12" in exc and "20261208" in exc)
    print("eventi nel calendario eccezioni:", exc.count("BEGIN:VEVENT"))

asyncio.run(main())

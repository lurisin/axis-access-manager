"""Porta spostata in un'area mentre il controller non accetta scritture: l'aggiornamento dei profili delle
tipologie fallisce (solo un warning nel log) e nessuno lo ripete più."""
import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from test_rules_service import place, row
from app.config import parse_options
from app.db import Database
from app.rules_service import RulesService
from app.service import AccessService
from app.vapix import ControllerGuard, VapixError

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    raw = FakeController()
    raw.access_points.append({"token": "ap-cantina", "Entity": "porta2", "Attribute": [{"Name": "Direction", "Value": "in"}]})
    c = ControllerGuard(raw)
    s = parse_options({"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"})
    r = RulesService(AccessService(db, c, s))
    ids = place(db)
    pul = await r.save_category(None, {"name": "Pulizie", "rules": [row("area", ids["rooms"])]}, "a")
    c.paused = "controller non confermato"          # oppure controller che non risponde
    db.set_door_area(ids["cantina"], ids["rooms"])   # update_door -> reload_runtime -> _refresh_categories
    try:
        await r.refresh_category_profiles()
    except VapixError as e:
        print("refresh fallito (solo log.warning in _refresh_categories):", e)
    c.paused = ""
    print("Pulizie sul controller:", [p["AccessPoint"] for p in raw.profiles[pul["token"]]["AccessPolicy"]],
          "| secondo l'app dovrebbe aprire anche ap-cantina")

asyncio.run(main())

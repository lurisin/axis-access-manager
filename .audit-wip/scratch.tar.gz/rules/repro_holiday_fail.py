import asyncio, sys, tempfile
from pathlib import Path
sys.path.insert(0, "tests")
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.rules_service import RulesService
from app.service import AccessService
from app.vapix import ControllerGuard, VapixError

OFFICE = [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "08:00", "end": "18:00"}]

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    raw = FakeController()
    c = ControllerGuard(raw)
    s = parse_options({"a1210_host": "x", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "a/x"})
    r = RulesService(AccessService(db, c, s))
    tok = (await r.create_schedule("Ufficio", "", OFFICE, True, "a"))["token"]
    await r.add_holidays([{"day": "2026-11-02", "name": "Ponte", "yearly": False}], "a")
    c.paused = "controller diverso all'indirizzo"
    try:
        await r.delete_holiday("2026-11-02", "a")
    except VapixError as e:
        print("errore mostrato:", e)
    print("elenco festività in app:", db.list_holidays())
    print("2 novembre ancora escluso sul controller:", "20261102" in raw.schedules[tok]["ExceptionScheduleDefinition"])
    c.paused = ""
    # nessun riallineamento finché l'add-on non si riavvia (reapply_holidays(only_changed=True) solo all'avvio)

asyncio.run(main())

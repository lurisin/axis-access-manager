import re, httpx
from app.config import normalize_host
for v in ["fe80::1", "2001:db8::10", "192.168.1.50:8o", "a1210.local:443:1", "::", "[fe80::1]", "192.168.1.50:99999", "https://fe80::1/", "192.168.1.50:", "a..b", "-x"]:
    h = normalize_host(v)
    ok = bool(re.match(r"^[A-Za-z0-9.\-:\[\]]+$", h))
    try:
        httpx.AsyncClient(base_url=f"https://{h}"); res = "ok"
    except Exception as e:
        res = f"{type(e).__name__}: {e}"
    print(repr(v), "regex", ok, "->", res)

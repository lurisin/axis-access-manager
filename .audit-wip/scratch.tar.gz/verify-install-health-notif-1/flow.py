import os, tempfile, asyncio
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from app.config import parse_options
from app.main import create_app

db_path = Path(tempfile.mkdtemp()) / "x.db"
CTRL = {"name": "A1210", "host": "127.0.0.1:9", "username": "root", "password": "x", "mqtt_topic_prefix": "acc"}
app = create_app(parse_options({}), allow_any_client=True, db_path=db_path)
with TestClient(app, raise_server_exceptions=False) as client:
    cid = client.post("/api/controllers", json=CTRL).json()["id"]
    raw_before = app.state.raw_controller
    r = client.post("/api/controllers/test", json={**CTRL, "host": "fe80::1"})
    print("test ->", r.status_code, r.text[:100])
    r = client.put(f"/api/controllers/{cid}", json={**CTRL, "host": "fe80::1", "password": ""})
    print("save ->", r.status_code, r.text[:100])
    print("db host:", app.state.db.get_controller(cid)["host"])
    print("raw_controller same obj (closed):", app.state.raw_controller is raw_before, raw_before._client.is_closed)
    print("monitor_task:", app.state.monitor_task)
    # health check
    async def hc():
        try:
            await app.state.health.check_all()
            print("check_all ok", {k:(v.online, v.error, v.failures) for k,v in app.state.health.states.items()})
        except Exception as e:
            print("check_all raised", type(e).__name__, e)
    client.portal.call(hc)
    for p in ["/api/summary", "/api/controllers", "/api/status"]:
        r = client.get(p); print(p, r.status_code, r.text[:150])
    # fix it via API?
    r = client.put(f"/api/controllers/{cid}", json={**CTRL, "host": "127.0.0.1:9", "password": ""})
    print("fix save ->", r.status_code, r.text[:100])
    client.put(f"/api/controllers/{cid}", json={**CTRL, "host": "fe80::1", "password": ""})

print("--- restart ---")
try:
    with TestClient(create_app(parse_options({}), allow_any_client=True, db_path=db_path)) as client:
        print("started", client.get("/api/summary").status_code)
except Exception as e:
    print("BOOT FAILED:", type(e).__name__, e)

import json
from fastapi.testclient import TestClient
from app.main import create_app

ADMIN = {"X-Remote-User-Name": "rising", "X-Remote-User-Display-Name": "Rising"}


def test_category_id_reused_api(settings, controller, tmp_path, monkeypatch):
    monkeypatch.delenv("SUPERVISOR_TOKEN", raising=False)
    app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp_path / "api.db")
    with TestClient(app) as c:
        c.get("/api/me", headers=ADMIN)
        door = c.get("/api/installation", headers=ADMIN).json()["controllers"][0]["doors"][0]["id"]
        office = [{"target": "door", "target_id": door, "schedule": "standard_office_hours"}]
        always = [{"target": "door", "target_id": door, "schedule": "standard_always"}]
        dip = c.post("/api/categories", json={"name": "Dipendenti", "rules": office}, headers=ADMIN).json()
        pul = c.post("/api/categories", json={"name": "Pulizie", "rules": always}, headers=ADMIN).json()
        bk = c.post("/api/backups", json={"name": "B"}, headers=ADMIN).json()
        r = c.delete(f"/api/categories/{pul['id']}", headers=ADMIN)
        print("delete", r.status_code)
        osp = c.post("/api/categories", json={"name": "Ospiti", "rules": office}, headers=ADMIN).json()
        print("ids: Dipendenti", dip["id"], "Pulizie", pul["id"], "Ospiti", osp["id"])
        p = c.post("/api/persons", json={"name": "Visitatore", "card": "04cc", "category_id": osp["id"]}, headers=ADMIN).json()
        prev = c.post(f"/api/backups/{bk['id']}/preview", json={"sections": ["tipologie"]}, headers=ADMIN).json()
        for i in prev["items"]:
            print("PREVIEW", json.dumps({k: i[k] for k in ("key", "action", "label", "text", "changes", "blocked", "default")}, ensure_ascii=False))
        keys = [i["key"] for i in prev["items"] if i["default"] and not i["blocked"]]
        res = c.post(f"/api/backups/{bk['id']}/restore", json={"sections": ["tipologie"], "keys": keys}, headers=ADMIN).json()
        print("RESULT", res)
        cats = c.get("/api/categories", headers=ADMIN).json()
        print("CATS", [(x["id"], x["name"], x["persons"], x["rules"]) for x in cats])
        person = [x for x in c.get("/api/persons", headers=ADMIN).json() if x["id"] == p["id"]][0]
        prof = controller.profiles[person["cards"][0]["access_profile"]]
        print("Visitatore category_id", person["category_id"], "schedules", [pp["Schedule"] for pp in prof["AccessPolicy"]])

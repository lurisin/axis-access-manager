"""Tipologia insieme alle persone, ma la ricreazione è bloccata: la persona prende il gruppo predefinito."""
from harness import make_plant, restore, run, show
from test_rules_service import OFFICE


async def main():
    plant, db, controller = make_plant()
    rule_all = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    dip = await plant.rules.save_category(None, {"name": "Dipendenti", "rules": [rule_all]}, "admin")
    plant.rules.set_default_category(dip["id"], "admin")
    sera = (await plant.rules.create_schedule("Sera", "", OFFICE, True, "admin"))["token"]
    pul = await plant.rules.save_category(None, {"name": "Pulizie", "rules": [{"target": "door", "target_id": plant.scala, "schedule": sera}]}, "admin")
    anna = await plant.access.create_person("Anna", "04aa", "admin", category_id=pul["id"])
    backup = await plant.backup()
    await plant.access.delete_person(anna["id"], "admin")
    await plant.rules.delete_category(pul["id"], "admin")
    await plant.rules.delete_schedule(sera, "admin")
    items, result = await restore(plant, backup["id"], ["tipologie", "persone"])
    show(items)
    print("RISULTATO:", result)
    p = db.get_person(anna["id"])
    print("Anna:", p["category_id"], p["cards"][0]["access_profile"], "default:", plant.access.default_group)

run(main())

"""Percorso raggiungibile dalla UI: tipologie, non gruppi."""
import sys
from harness import make_plant, restore, run, show, preview


async def scenario(variant):
    plant, db, controller = make_plant()
    rule_all = {"target": "door", "target_id": plant.scala, "schedule": "standard_always"}
    dip = await plant.rules.save_category(None, {"name": "Dipendenti", "rules": [rule_all]}, "admin")
    plant.rules.set_default_category(dip["id"], "admin")
    rule_off = {"target": "door", "target_id": plant.scala, "schedule": "standard_office_hours"}
    pul = await plant.rules.save_category(None, {"name": "Pulizie", "rules": [rule_off]}, "admin")
    osp = await plant.rules.save_category(None, {"name": "Ospite", "rules": [rule_off]}, "admin")
    anna = await plant.access.create_person("Anna", "04aa", "admin", category_id=pul["id"])
    print("default_group:", plant.access.default_group, "dip token", dip["token"], "pul token", pul["token"])
    backup = await plant.backup()
    if variant == "ricrea":
        await plant.access.delete_person(anna["id"], "admin")
    else:
        await plant.access.set_person_access(anna["id"], "", "", "", "admin", category_id=osp["id"])
    await plant.rules.delete_category(pul["id"], "admin")
    print("profilo Pulizie ancora sul controller:", pul["token"] in controller.profiles)
    items, result = await restore(plant, backup["id"], ["persone"])
    print("ANTEPRIMA:")
    show(items)
    print("RISULTATO:", result)
    p = db.get_person(anna["id"])
    card = p["cards"][0]
    print("Anna dopo: category_id=", p["category_id"], "profilo=", card["access_profile"])
    print("Schedule profilo scritto:", [pol.get("Schedule") for pol in controller.profiles[card["access_profile"]].get("AccessPolicy", [])], controller.profiles[card["access_profile"]].get("Schedule"))

run(scenario(sys.argv[1]))

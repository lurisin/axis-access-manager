from conftest import controller, db, settings  # noqa: F401
from test_backup import DOOR, Plant  # noqa: F401
import pytest


@pytest.fixture
def plant(db, controller, settings, tmp_path):
    return Plant(db, controller, settings, tmp_path / "backup")


async def test_door_config_not_restored(plant, controller):
    backup = await plant.backup()
    # Come il Sensore Porta: cambia solo il DoorMonitor nella configurazione della porta
    await plant.programming._set_door_monitor("porta", {"DoorMonitor.Type": "Standard"})
    items, result = await plant.restore(backup["id"], ["porte"])
    print("ITEMS1", [(i["key"], i["default"], i["changes"]) for i in items])
    print("RESULT", result)
    print("CONFIG AFTER", controller.door_configs["porta"]["Configuration"])
    items2, _ = await plant.restore(backup["id"], ["porte"], keys=[])
    print("ITEMS2", [(i["key"], i["changes"]) for i in items2])
    assert items2  # la riga ricompare


async def test_door_added_to_app_after_backup(plant, controller, db):
    backup = await plant.backup()
    db.save_door(None, plant.controller_id, DOOR | {"door_token": "porta2", "name": "Cantina", "snapshot_camera": "camera.cantina"})
    items, result = await plant.restore(backup["id"], ["porte"])
    print("ITEMS1", [(i["key"], i["default"], i["changes"]) for i in items])
    print("RESULT", result)
    print("APP DOORS", [(d["door_token"], d["snapshot_camera"]) for d in db.list_doors()])
    items2, _ = await plant.restore(backup["id"], ["porte"], keys=[])
    print("ITEMS2", [(i["key"], i["changes"]) for i in items2])

// Verifica contract-10, contract-11, contract-12 nel browser (harness privato su 127.0.0.1:9202)
const { chromium } = require("playwright");
const { execFileSync } = require("child_process");
const BASE = "http://127.0.0.1:9202/";
const DB = __dirname + "/h/ui.db";
const sql = (q) => execFileSync("python3", ["-c", `import sqlite3,sys; c=sqlite3.connect(sys.argv[1]); r=c.execute(sys.argv[2]).fetchall(); c.commit(); print(r)`, DB, q]).toString().trim();

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on("pageerror", (e) => console.log("PAGEERROR", e.message));

  // contract-10
  await page.goto(BASE + "#impostazioni/utenti");
  await page.waitForSelector("#u-new");
  await page.click("#u-new");
  await page.waitForSelector("#modal [name=role]");
  const shown = await page.$eval("#modal [name=role]", (s) => s.options[s.selectedIndex].text + " / " + s.value);
  const checked = await page.$$eval("#modal [name=perm]:checked", (l) => l.map((x) => x.value));
  console.log("contract-10 Nuovo Utente: ruolo mostrato =", shown, "| permessi spuntati =", checked);
  await page.fill("#modal [name=username]", "secondo_admin");
  // l'utente "sceglie" Amministratore, già mostrato: nessun change
  const checked2 = await page.$$eval("#modal [name=perm]:checked", (l) => l.map((x) => x.value));
  console.log("contract-10 dopo selectOption(amministratore) già selezionato: spuntati =", checked2);
  await page.click("#modal button[type=submit]");
  await page.waitForTimeout(800);
  const users = await page.evaluate(async () => (await (await fetch("api/users")).json()).users.filter((u) => u.username === "secondo_admin"));
  console.log("contract-10 utente creato:", JSON.stringify(users.map((u) => ({ role: u.role, perms: u.perms, admin: u.admin }))));
  await page.evaluate(() => fetch("api/users/secondo_admin", { method: "DELETE" }));

  // contract-11
  const ctrls = await page.evaluate(async () => (await (await fetch("api/installation")).json()).controllers.map((c) => c.id));
  await page.goto(BASE + `#impianti/c${ctrls[0]}/connessione`);
  await page.waitForSelector("#ctrl-test");
  await page.evaluate(() => fetch("__harness/scenario/offline", { method: "POST" }));
  await page.click("#ctrl-test");
  await page.waitForTimeout(1500);
  const retryOpen = await page.$eval("#retry", (d) => d.open);
  const retryText = retryOpen ? await page.$eval("#retry", (d) => d.innerText.replace(/\s+/g, " ")) : "";
  console.log("contract-11 Prova Collegamento a controller spento: retryBox aperto =", retryOpen, "|", retryText);
  if (retryOpen) await page.click("#retry [data-r='0']");
  await page.waitForTimeout(500);
  console.log("contract-11 riga risultato:", await page.$eval("#ctrl-test-result", (e) => e.innerText));
  await page.evaluate(() => fetch("__harness/scenario/normal", { method: "POST" }));

  // contract-12
  await page.goto(BASE + "#registro");
  await page.waitForSelector("#l-list [data-event]");
  await page.waitForTimeout(1000);
  const top = await page.$eval("#l-list [data-event]", (e) => Number(e.dataset.event));
  const before = await page.$eval(`#l-list [data-event="${top}"]`, (e) => e.innerHTML.includes("con istantanea"));
  console.log("contract-12 riga in cima", top, "con foto prima:", before, sql(`select kind, detail, snapshot from events where id=${top}`));
  sql(`update events set snapshot='${top}_x.jpg', detail=detail || ' · più pressioni' where id=${top}`);
  await page.waitForTimeout(17000);
  const after = await page.$eval(`#l-list [data-event="${top}"]`, (e) => e.innerHTML.includes("con istantanea"));
  await page.click(`#l-list [data-event="${top}"]`);
  await page.waitForTimeout(500);
  const panel = await page.evaluate(() => { const p = document.querySelector("#l-detail"); return p ? p.innerText.replace(/\s+/g, " ") : "(nessun pannello)"; });
  const hasImg = await page.evaluate(() => !!document.querySelector("#l-detail img.thumb"));
  console.log("contract-12 dopo 17 s (refresh automatico): icona foto =", after, "| foto nel dettaglio =", hasImg, "| dettaglio:", panel.slice(0, 200));
  await page.reload();
  await page.waitForSelector(`#l-list [data-event="${top}"]`);
  const reloaded = await page.$eval(`#l-list [data-event="${top}"]`, (e) => e.innerHTML.includes("con istantanea"));
  console.log("contract-12 dopo ricarica: icona foto =", reloaded);
  // ripristino
  sql(`update events set snapshot='', detail=replace(detail, ' · più pressioni', '') where id=${top}`);
  await browser.close();
})();

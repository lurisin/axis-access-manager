import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    new = client.post("/api/controllers/1/doors", json={"door_token": "porta2", "name": "Cantina"}, headers=admin).json()
    detail = client.get(f"/api/door-detail/{new['id']}", headers=admin).json()
    print("Cantina (nessun lettore): lettori", detail["readers"], "| Chi Può Entrare:", [g["name"] for g in detail["groups"]])

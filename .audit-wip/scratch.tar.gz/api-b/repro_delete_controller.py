"""Rimuovi Controller: le porte spariscono anche se una tipologia le usa (la porta da sola non si può togliere)."""
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
# Seconda porta del controller con il suo lettore (cantina)
controller.access_points.append({"token": "ap-cantina", "Entity": "porta2", "EntityType": "axtdc:Door", "Name": "Cantina",
    "Enabled": True, "IdPointDevice": [{"IdPoint": "lettore-2", "DeviceUUID": ""}],
    "Attribute": [{"Name": "Direction", "Value": "in"}]})
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    rules = [{"target": "door", "target_id": door["id"], "schedule": "standard_always"}]
    cat = client.post("/api/categories", json={"name": "Dipendenti", "rules": rules}, headers=admin).json()
    print("tipologia:", cat)
    print("profilo di Dipendenti all'inizio:", [p["AccessPoint"] for p in controller.profiles[cat["token"]]["AccessPolicy"]])
    # Una modifica di programmazione nello Storico del controller 1
    client.put("/api/programming/doors/porta", json={"name": "Ingresso vecchio"}, headers=admin)
    r = client.delete(f"/api/doors/{door['id']}", headers=admin)
    print("DELETE porta:", r.status_code, r.json())
    r = client.delete("/api/controllers/1", headers=admin)
    print("DELETE controller:", r.status_code, r.json())
    print("righe della tipologia:", client.get("/api/categories", headers=admin).json()[0]["rules"])
    r = client.put(f"/api/categories/{cat['id']}", json={"name": "Dipendenti", "color": "green", "rules": rules},
                   headers=admin)
    print("modifica della tipologia (solo il colore):", r.status_code, r.json())
    # Controller aggiunto di nuovo: stesso numero, stessa porta, storico del vecchio
    body = {"name": "Nuovo", "host": "10.0.0.2", "username": "root", "password": "x", "mqtt_topic_prefix": "accessi/y"}
    new = client.post("/api/controllers", json=body, headers=admin).json()
    nd = client.post(f"/api/controllers/{new['id']}/doors", json={"door_token": "porta2", "name": "Cantina"},
                     headers=admin).json()
    print("nuovo controller:", new, "nuova porta:", nd)
    print("profilo di Dipendenti sul controller:", [p["AccessPoint"] for p in controller.profiles[cat["token"]]["AccessPolicy"]])
    print("storico del nuovo controller:", [c["summary"] for c in client.get("/api/programming", headers=admin).json()["changes"]])

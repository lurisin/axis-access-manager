"""Riparazioni una tantum dopo la prima sincronizzazione: un errore di una diventa "Sincronizzazione non riuscita"
(notifica Controller Non Raggiungibile) e salta per sempre (fino al riavvio) quelle successive, come adopt_groups."""
import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402
from app.vapix import VapixError  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
controller.add_existing("utente_mario", "Mario Rossi", "04aa")
# Gruppo creato con un altro strumento: fascia solo nella regola, il controller rifiuta la riscrittura
controller.profiles["vecchio"] = {"token": "vecchio", "Name": "Vecchio", "Enabled": True,
                                  "AccessPolicy": [{"AccessPoint": "ap-in", "Schedule": ["standard_always"]}]}


async def refuse(profile):
    raise VapixError("il controller ha rifiutato la richiesta: InvalidArgVal")

controller.set_access_profile = refuse
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    for _ in range(100):
        if app.state.last_sync["at"]:
            break
        time.sleep(0.1)
    print("last_sync:", app.state.last_sync)
    faults = [(f["type"], f["title"], f["text"]) for f in client.get("/api/summary", headers=admin).json()["faults"]]
    print("guasti:", faults)
    persons = client.get("/api/persons", headers=admin).json()
    print("Mario Rossi, tipologia:", persons[0]["category_id"], "| tipologia predefinita:",
          client.get("/api/me", headers=admin).json()["default_category"])

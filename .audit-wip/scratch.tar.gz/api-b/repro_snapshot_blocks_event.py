"""Istantanea non salvabile (disco pieno, /media di rete non raggiungibile): l'evento non arriva a Home Assistant."""
import asyncio
import logging
import os
import tempfile
from pathlib import Path

import httpx

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import CORE_API, HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

logging.basicConfig(level=logging.ERROR)
tmp = Path(tempfile.mkdtemp())
(tmp / "file").write_text("x")
# Cartella delle istantanee che non si può scrivere: come /media piena o non montata
ha = HomeAssistant(token="t", snapshot_dir=tmp / "file" / "snap")
ha._client = httpx.AsyncClient(base_url=CORE_API, transport=httpx.MockTransport(
    lambda request: httpx.Response(200, content=b"\xff\xd8jpeg")))
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db", home_assistant=ha,
                 scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    body = {k: door[k] for k in ("name", "door_token", "ha_buttons", "snapshot_camera", "snapshot_on_granted",
                                 "intercom_name", "intercom_relay", "intercom_open_door", "intercom_mqtt_prefix",
                                 "area_id")}
    client.put(f"/api/doors/{door['id']}", json={**body, "snapshot_camera": "camera.ingresso"}, headers=admin)
    published = []

    async def trigger():
        async def record(row):
            published.append(row["kind"])

        app.state.bridge.publish_event = record
        for kind, detail in (("allarme", "porta forzata"), ("concesso", "")):
            app.state.service.log_event(ts="2026-10-28T08:00:00+00:00", kind=kind, detail=detail, door="porta",
                                        source="porta")
        await asyncio.sleep(0.3)

    client.portal.call(trigger)
    print("eventi pubblicati in Home Assistant:", published, "(attesi: allarme e concesso)")
    print("errori telecamera mostrati:", app.state.snapshot_errors)

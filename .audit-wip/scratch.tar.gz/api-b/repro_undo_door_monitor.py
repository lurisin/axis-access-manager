"""Annulla nello Storico Modifiche di un Sensore Porta: Contatto Porta resta com'era (non si rilegge)."""
import os
import tempfile
import time
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
controller.door_physical = "Unknown"  # nessun contatto porta
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    for _ in range(50):
        if app.state.health.states.get(1) and app.state.health.states[1].online:
            break
        time.sleep(0.1)
    # Sensore Porta collegato: il controller ora vede la porta chiusa
    controller.door_physical = "Closed"
    r = client.put("/api/programming/inputs/DPS", json={"role": "door_monitor", "door": "porta", "contact": "no"},
                   headers=admin)
    print("Sensore Porta scritto:", r.status_code, "| contatto nell'app:", app.state.monitor.door_physical.get("porta"),
          "| HA:", app.state.bridge.state()["contatti"])
    # Annullato dallo Storico: il controller torna senza contatto porta
    change = client.get("/api/programming", headers=admin).json()["changes"][0]
    controller.door_physical = "Unknown"
    r = client.post(f"/api/programming/changes/{change['id']}/undo", headers=admin)
    print("Annulla:", r.status_code, "| contatto nell'app:", app.state.monitor.door_physical.get("porta"),
          "| HA:", app.state.bridge.state()["contatti"])
    # Stessa cosa salvando l'ingresso come Non Usato: qui si rilegge
    controller.door_physical = "Closed"
    client.put("/api/programming/inputs/DPS", json={"role": "door_monitor", "door": "porta", "contact": "no"},
               headers=admin)
    controller.door_physical = "Unknown"
    client.put("/api/programming/inputs/DPS", json={"role": ""}, headers=admin)
    print("Salvato come Non Usato | contatto nell'app:", app.state.monitor.door_physical.get("porta"),
          "| HA:", app.state.bridge.state()["contatti"])

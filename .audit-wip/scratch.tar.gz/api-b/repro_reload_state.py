"""Cambiare la telecamera di una porta riavvia tutto il collegamento: lo stato visto via MQTT si perde."""
import json
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}


def msg(topic, data):
    return json.dumps({"timestamp": 1761638400000, "message": {"source": {}, "key": {}, "data": data}}).encode()


with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    m = app.state.monitor
    m.handle("accessi/x/eventi/Door/State/DoorAlarm/$source/DoorToken/porta", msg("", {"State": "DoorForcedOpen"}))
    m.handle("accessi/x/eventi/Device/Casing/Open", msg("", {"Open": "1"}))
    m.handle("accessi/x/eventi/Device/IO/Port/port/3", msg("", {"state": "1"}))
    m.handle("accessi/x/eventi/Device/Status/SystemReady", msg("", {"ready": "1"}))
    before = app.state.bridge.state()
    print("prima:", before["condizioni"]["porta"]["allarme"]["stato"], before["controller"], before["ingressi"]["3"])
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    body = {k: door[k] for k in ("name", "door_token", "ha_buttons", "snapshot_camera", "snapshot_on_granted",
                                 "intercom_name", "intercom_relay", "intercom_open_door", "intercom_mqtt_prefix",
                                 "area_id")}
    body["snapshot_camera"] = "camera.ingresso"
    print("PUT porta (solo telecamera):", client.put(f"/api/doors/{door['id']}", json=body, headers=admin).status_code)
    after = app.state.bridge.state()
    print("dopo:", after["condizioni"]["porta"]["allarme"]["stato"], after["controller"], after["ingressi"]["3"])

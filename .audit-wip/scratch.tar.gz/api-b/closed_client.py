"""Cosa succede a una richiesta di A1210Client dopo aclose() (reload_runtime durante una sincronizzazione)."""
import asyncio

import httpx

from app.vapix import A1210Client, VapixError


async def main():
    def handler(request):
        return httpx.Response(200, json={"Credential": []})

    client = A1210Client("a1210.local", "u", "p", transport=httpx.MockTransport(handler))
    print("prima:", await client.list_credentials())
    await client.aclose()
    try:
        await client.list_credentials()
    except VapixError as err:
        print("VapixError (gestito):", err)
    except Exception as err:  # noqa: BLE001
        print("NON VapixError:", type(err).__name__, err)


asyncio.run(main())

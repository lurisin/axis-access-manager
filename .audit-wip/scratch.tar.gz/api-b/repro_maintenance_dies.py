"""reload_runtime() durante la sincronizzazione periodica: il task _maintenance muore per sempre.

Client VAPIX veri (A1210Client) con un trasporto finto: GetCredentialList risponde dopo 0,5 s, come un A1210
con molte tessere. Mentre _maintenance aspetta la risposta, un utente salva una porta (reload_runtime).
"""
import asyncio
import json
import logging
import os
import sys
import tempfile

import httpx

os.environ.pop("SUPERVISOR_TOKEN", None)

import app.main as main  # noqa: E402
from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.vapix import A1210Client  # noqa: E402

logging.basicConfig(level=logging.WARNING)
entered = None
calls = []


async def handler(request: httpx.Request) -> httpx.Response:
    body = json.loads(request.content or b"{}")
    method = next(iter(body), "") if request.url.path.startswith("/vapix") else body.get("method", "")
    calls.append(method)
    path = request.url.path
    if path.endswith("basicdeviceinfo.cgi"):
        return httpx.Response(200, json={"data": {"propertyList": {"ProdNbr": "A1210", "SerialNumber": "X", "Version": "1"}}})
    if path.endswith(".cgi"):
        return httpx.Response(200, json={"data": {}})
    if method == "pacsaxis:GetCredentialList":
        entered.set()
        await asyncio.sleep(0.5)
        return httpx.Response(200, json={"Credential": []})
    if method == "axudb:GetUserList":
        return httpx.Response(200, json={"User": []})
    if method == "pacsaxis:GetAccessPointList":
        return httpx.Response(200, json={"AccessPoint": []})
    if method == "pacsaxis:GetAccessProfileList":
        return httpx.Response(200, json={"AccessProfile": []})
    if method == "pacsaxis:GetAccessControllerList":
        return httpx.Response(200, json={"AccessController": []})
    if method == "tdc:GetDoorInfoList":
        return httpx.Response(200, json={"DoorInfo": [{"token": "porta", "Name": "Porta"}]})
    if method == "tdc:GetDoorState":
        return httpx.Response(200, json={"DoorState": {"DoorMode": "Locked", "DoorPhysicalState": "Closed"}})
    if method == "axlog:FetchEvents":
        return httpx.Response(200, json={"Event": [], "More": False})
    if method == "axsch:GetScheduleList":
        return httpx.Response(200, json={"Schedule": []})
    return httpx.Response(200, json={})


def fake_client(host, username, password, verify_ssl=False):
    return A1210Client(host, username, password, verify_ssl, transport=httpx.MockTransport(handler))


main.A1210Client = fake_client


async def scenario():
    global entered
    entered = asyncio.Event()
    settings = parse_options(
        {"a1210_host": "127.0.0.1:9", "a1210_username": "root", "a1210_password": "x", "door_token": "porta",
         "access_profile": "", "mqtt_topic_prefix": "accessi/x"}
    )
    tmp = tempfile.mkdtemp()
    app = main.create_app(settings, allow_any_client=True, db_path=os.path.join(tmp, "a.db"),
                          home_assistant=HomeAssistant(token="", snapshot_dir=__import__("pathlib").Path(tmp)),
                          scheduled_backups=False)
    try:
        async with app.router.lifespan_context(app):
            await asyncio.wait_for(entered.wait(), 40)
            task = next(t for t in asyncio.all_tasks() if t.get_coro().__name__ == "_maintenance")
            print("sincronizzazione periodica in corso: salvo una porta (reload_runtime)")
            await main.reload_runtime(app)
            await asyncio.sleep(1.5)
            print("_maintenance terminato:", task.done())
            if task.done():
                print("eccezione:", repr(task.exception()))
            print("last_sync:", app.state.last_sync)
            # Una richiesta di rilettura (controller tornato raggiungibile) non trova più nessuno
            calls.clear()
            app.state.sync_wake.set()
            await asyncio.sleep(0.8)
            print("GetCredentialList dopo sync_wake:", calls.count("pacsaxis:GetCredentialList"))
        print("spegnimento pulito")
    except Exception as err:  # noqa: BLE001
        print("spegnimento interrotto da:", repr(err))


asyncio.run(scenario())

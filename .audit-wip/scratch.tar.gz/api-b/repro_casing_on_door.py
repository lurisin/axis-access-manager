"""Coperchio del controller aperto (evento senza porta): con una porta sola finisce negli allarmi della porta."""
import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    now = datetime.now(tz=UTC).isoformat(timespec="seconds")
    app.state.db.add_event(ts=now, kind="manomissione", detail="coperchio del controller aperto", source="Controller A1210")
    door = client.get("/api/door-overview", headers=admin).json()[0]
    print("porta", door["name"], "allarmi oggi:", door["today"]["alarms"])
    detail = client.get(f"/api/door-detail/{door['id']}", headers=admin).json()
    print("eventi di questa porta:", [(e["kind"], e["detail"]) for e in detail["events"]])
    notes = client.get("/api/notifications", headers=admin).json()["items"]
    print("notifica:", [(n["title"], n["door"]) for n in notes if n["type"] == "door_alarm"])

"""Dettaglio porta, Chi Può Entrare: con due fasce sulla porta la tipologia compare anche con "Sempre"."""
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    morning = client.post("/api/schedules", json={"name": "Mattina", "rules": [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "07:00", "end": "09:00"}]}, headers=admin).json()
    evening = client.post("/api/schedules", json={"name": "Sera", "rules": [{"days": ["MO", "TU", "WE", "TH", "FR"], "start": "18:00", "end": "20:00"}]}, headers=admin).json()
    rules = [{"target": "door", "target_id": door["id"], "schedule": morning["token"]},
             {"target": "door", "target_id": door["id"], "schedule": evening["token"]}]
    print(client.post("/api/categories", json={"name": "Pulizie", "rules": rules}, headers=admin).json())
    detail = client.get(f"/api/door-detail/{door['id']}", headers=admin).json()
    for g in detail["groups"]:
        print("Chi Può Entrare:", g["name"], "->", ", ".join(g["schedule_names"]) or "sempre")

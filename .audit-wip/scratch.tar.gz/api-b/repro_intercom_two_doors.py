"""Stesso videocitofono su due porte (relè 1 e relè 2): le chiamate arrivano a una porta sola."""
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from conftest import FakeController  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    door = client.get("/api/installation", headers=admin).json()["controllers"][0]["doors"][0]
    body = {k: door[k] for k in ("name", "door_token", "ha_buttons", "snapshot_camera", "snapshot_on_granted",
                                 "intercom_name", "intercom_relay", "intercom_open_door", "intercom_mqtt_prefix",
                                 "area_id")}
    client.put(f"/api/doors/{door['id']}", json={**body, "intercom_name": "Citofono", "intercom_relay": 1}, headers=admin)
    client.post("/api/controllers/1/doors", json={"door_token": "porta2", "name": "Cancello",
                                                  "intercom_name": "Citofono", "intercom_relay": 2}, headers=admin)
    first, second = app.state.intercoms
    handler = app.state.monitor.extra_subscriptions[first.call_topic]
    print("stesso topic delle chiamate:", first.call_topic == second.call_topic,
          "| riceve le chiamate:", handler.__self__.door["name"])

"""Un indirizzo che supera la validazione di Impianti ma che httpx rifiuta ("fe80::1", "a1210:8o43").

1) PUT /api/controllers/1: il salvataggio va nel database, poi reload_runtime fallisce a metà (500).
2) Riavvio dell'add-on con lo stesso database: il lifespan fallisce, l'add-on non parte più.
"""
import os
import tempfile
from pathlib import Path

os.environ.pop("SUPERVISOR_TOKEN", None)

from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.ha import HomeAssistant  # noqa: E402
from app.main import create_app  # noqa: E402

tmp = Path(tempfile.mkdtemp())
settings = parse_options(
    {"a1210_host": "127.0.0.1:9", "a1210_username": "root", "a1210_password": "x", "door_token": "porta",
     "mqtt_topic_prefix": "accessi/x"}
)


def make():
    return create_app(settings, allow_any_client=True, db_path=tmp / "a.db",
                      home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)


admin = {"X-Remote-User-Name": "admin"}
with TestClient(make(), raise_server_exceptions=False) as client:
    client.get("/api/me", headers=admin)
    test = client.post("/api/controllers/test", json={"host": "fe80::1", "username": "root"}, headers=admin)
    print("Prova Collegamento con fe80::1:", test.status_code, test.text[:80])
    body = {"name": "Controller", "host": "fe80::1", "username": "root", "password": "", "mqtt_topic_prefix": "accessi/x"}
    r = client.put("/api/controllers/1", json=body, headers=admin)
    print("PUT /api/controllers/1:", r.status_code, r.text[:80])
    print("host salvato:", client.get("/api/installation", headers=admin).json()["controllers"][0]["host"])
    r = client.post("/api/sync", headers=admin)
    print("POST /api/sync dopo il salvataggio:", r.status_code, r.text[:80])

try:
    with TestClient(make()) as client:
        print("riavvio: GET /api/me ->", client.get("/api/me").status_code)
except Exception as err:  # noqa: BLE001
    print("riavvio dell'add-on fallito:", type(err).__name__, err)

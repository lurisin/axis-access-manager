"""Porta tolta dall'app (o pulsanti spenti su una porta oltre la prima): le sue entità restano in Home Assistant."""
import asyncio
import tempfile
from pathlib import Path

from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge


class Recorder:
    def __init__(self):
        self.topics = {}

    async def publish(self, topic, payload, qos=0, retain=False):
        self.topics[topic] = payload


async def main():
    db = Database(Path(tempfile.mkdtemp()) / "a.db")
    settings = parse_options({"door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    monitor = EventMonitor(prefix="accessi/x", door_token="porta")
    doors = [
        {"id": 1, "door_token": "porta", "name": "Ingresso", "ha_buttons": True},
        {"id": 2, "door_token": "porta2", "name": "Cantina", "ha_buttons": True},
    ]
    broker = Recorder()
    await HaBridge(settings, monitor, db, doors).on_connect(broker)
    published = {t for t, p in broker.topics.items() if t.endswith("/config") and p}
    # Dopo "Togli dall'App" della Cantina: nuovo bridge con una porta sola, nuova connessione
    after = Recorder()
    await HaBridge(settings, monitor, db, doors[:1]).on_connect(after)
    cleared = {t for t, p in after.topics.items() if t.endswith("/config") and not p}
    republished = {t for t, p in after.topics.items() if t.endswith("/config") and p}
    stale = sorted(t for t in published if t not in cleared and t not in republished)
    print("entità della Cantina rimaste in Home Assistant:")
    for topic in stale:
        print("  ", topic)
    db.close()


asyncio.run(main())

import asyncio, os, tempfile, time
from datetime import UTC, datetime, timedelta
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
from app import main as m
from app.config import parse_options
from app.ha import HomeAssistant
from app.main import create_app
tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    for _ in range(50):
        if app.state.health.states.get(1) and app.state.health.states[1].online:
            break
        time.sleep(0.1)
    last = (datetime.now(tz=UTC) - timedelta(hours=1)).replace(microsecond=0)
    app.state.db.add_event(ts=last.isoformat(), kind="concesso", detail="x")
    async def fake_recover(since):
        return 3
    app.state.service.recover_events = fake_recover
    app.state.recover_pending = True
    client.portal.call(m._recover_if_needed, app.state)
    a = [r for r in app.state.db.list_audit() if r["action"] == "eventi recuperati dal controller"]
    print("TZ:", os.environ.get("TZ"), "| ultimo evento UTC:", last.isoformat(), "| locale:", last.astimezone().strftime("%d/%m %H:%M"))
    print("audit:", a[0]["detail"] if a else None)

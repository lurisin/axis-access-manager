import asyncio, tempfile
from pathlib import Path
from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge
class R:
    def __init__(self): self.t = {}
    async def publish(self, topic, payload, qos=0, retain=False): self.t[topic] = payload
async def main():
    db = Database(Path(tempfile.mkdtemp()) / "a.db")
    s = parse_options({"door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    mon = EventMonitor(prefix="accessi/x", door_token="porta")
    on = [{"id": 1, "door_token": "porta", "name": "Ingresso", "ha_buttons": True}, {"id": 2, "door_token": "porta2", "name": "Cantina", "ha_buttons": True}]
    off = [on[0], {**on[1], "ha_buttons": False}]
    r = R(); await HaBridge(s, mon, db, off).on_connect(r)
    print("pulsanti Cantina spenti -> topic toccati:", sorted(t for t in r.t if "apri_porta" in t))
    db.close()
asyncio.run(main())

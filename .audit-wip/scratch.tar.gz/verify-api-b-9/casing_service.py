import os, tempfile
from datetime import UTC, datetime
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
from conftest import FakeController
from fastapi.testclient import TestClient
from app.config import parse_options
from app.events import Event
from app.ha import HomeAssistant
from app.main import create_app
tmp = Path(tempfile.mkdtemp())
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db",
                 home_assistant=HomeAssistant(token="", snapshot_dir=tmp), scheduled_backups=False)
admin = {"X-Remote-User-Name": "admin"}
with TestClient(app) as client:
    client.get("/api/me", headers=admin)
    print("porte:", len(app.state.doors))
    app.state.service.record_event(Event("Device", "Device/Casing/Open/$source/Name/Casing", datetime.now(tz=UTC), {"Open": "1"}))
    ev = app.state.db.list_events()[0]
    print("evento:", ev["kind"], ev["detail"], "door=", repr(ev["door"]))
    door = client.get("/api/door-overview", headers=admin).json()[0]
    print("allarmi oggi porta:", door["today"]["alarms"])
    d = client.get(f"/api/door-detail/{door['id']}", headers=admin).json()
    print("eventi porta:", [(e["kind"], e["detail"]) for e in d["events"]])

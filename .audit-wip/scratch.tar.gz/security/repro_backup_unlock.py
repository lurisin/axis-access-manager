"""Un utente con il solo permesso Backup sblocca un backup e ne provoca l'eliminazione con la ritenzione."""
import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from fastapi.testclient import TestClient  # noqa: E402

from app.config import parse_options  # noqa: E402
from app.main import create_app  # noqa: E402
from conftest import FakeController  # noqa: E402

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "t.db", scheduled_backups=False)
with TestClient(app) as client:
    admin = {"X-Remote-User-Name": "rising"}
    client.get("/api/me", headers=admin)
    client.post("/api/users", json={"username": "tecnico", "perms": ["backup"]}, headers=admin)
    tech = {"X-Remote-User-Name": "tecnico"}
    # Politica stretta scelta dall'amministratore: si tiene solo l'ultimo, il backup importante è bloccato
    keep = client.post("/api/backups", json={"name": "Prima dei lavori"}, headers=admin).json()
    client.put(f"/api/backups/{keep['id']}/lock", json={"locked": True}, headers=admin)
    r = client.put("/api/backups/policy", json={"keep_last": 1, "keep_daily": 0, "keep_weekly": 0, "keep_monthly": 0, "keep_yearly": 0, "confirm": True}, headers=admin)
    print("policy:", r.status_code, r.json().get("saved"))
    ids = [b["id"] for b in client.get("/api/backups", headers=tech).json()["backups"]]
    print("prima:", ids)
    # Utente Backup: sblocca e crea un backup (permessi che ha)
    client.put(f"/api/backups/{keep['id']}/lock", json={"locked": False}, headers=tech)
    client.post("/api/backups", json={"name": "nuovo"}, headers=tech)
    ids = [b["id"] for b in client.get("/api/backups", headers=tech).json()["backups"]]
    print("dopo:", ids, "| 'Prima dei lavori' ancora presente:", keep["id"] in ids)
    audit = client.get("/api/audit?limit=20", headers=admin).json()
    print([ (a["user"], a["action"]) for a in audit[:5]])

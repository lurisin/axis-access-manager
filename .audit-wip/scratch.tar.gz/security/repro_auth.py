"""Verifica di comportamenti di autorizzazione (solo lettura del repo, DB temporaneo)."""

import os
import tempfile
from pathlib import Path

os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)

from fastapi.testclient import TestClient  # noqa: E402

from app.main import create_app  # noqa: E402
from app.config import parse_options  # noqa: E402
from conftest import FakeController  # noqa: E402

settings = parse_options(
    {"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"}
)
tmp = Path(tempfile.mkdtemp())
controller = FakeController()
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "t.db", scheduled_backups=False)

with TestClient(app) as client:
    admin = {"X-Remote-User-Name": "rising", "X-Remote-User-Id": "id-admin", "X-Remote-User-Display-Name": "Rising"}
    assert client.get("/api/me", headers=admin).json()["admin"] is True

    # 1) Utente di HA senza nome utente (solo Id e nome visualizzato): che permessi riceve?
    no_username = {"X-Remote-User-Id": "id-ldap", "X-Remote-User-Display-Name": "Utente LDAP"}
    me = client.get("/api/me", headers=no_username).json()
    print("1) /api/me senza X-Remote-User-Name:", {k: me[k] for k in ("user", "username", "admin", "role")})
    print("   GET /api/users ->", client.get("/api/users", headers=no_username).status_code)
    r = client.post("/api/users", json={"username": "nuovo_admin", "perms": ["utenti"]}, headers=no_username)
    print("   POST /api/users (crea amministratore) ->", r.status_code)

    # 2) Solo Stato che segna come viste notifiche di tipi che non vede (allarmi porta: serve "registro")
    guest = {"X-Remote-User-Name": "ospite"}
    client.get("/api/me", headers=guest)
    state = app.state
    db = state.db
    event_id = db.add_event(ts="2099-01-01T00:00:00+00:00", kind="allarme", detail="porta forzata", source="porta", door="porta")
    # Evento nelle ultime 24 ore
    from datetime import UTC, datetime

    db._execute("UPDATE events SET ts = ? WHERE id = ?", (datetime.now(tz=UTC).isoformat(timespec="seconds"), event_id))
    admin_items = client.get("/api/notifications", headers=admin).json()["items"]
    alarm = next(i for i in admin_items if i["type"] == "door_alarm")
    guest_items = client.get("/api/notifications", headers=guest).json()["items"]
    print("2) allarme visibile all'ospite?", any(i["id"] == alarm["id"] for i in guest_items))
    audit_before = len(client.get("/api/audit?limit=500", headers=admin).json())
    r = client.post("/api/notifications/seen", json={"ids": [alarm["id"]]}, headers=guest)
    print("   POST seen dall'ospite ->", r.status_code)
    after = next(i for i in client.get("/api/notifications", headers=admin).json()["items"] if i["id"] == alarm["id"])
    audit_after = len(client.get("/api/audit?limit=500", headers=admin).json())
    print("   allarme ora 'visto' per l'amministratore:", after["seen"], "| righe di attività aggiunte:", audit_after - audit_before)

    # 3) Utente con il solo permesso Backup: sblocca un backup bloccato da un amministratore
    client.post("/api/users", json={"username": "tecnico", "perms": ["backup"]}, headers=admin)
    tech = {"X-Remote-User-Name": "tecnico"}
    b = client.post("/api/backups", json={"name": "Da tenere"}, headers=admin).json()
    client.put(f"/api/backups/{b['id']}/lock", json={"locked": True}, headers=admin)
    r = client.put(f"/api/backups/{b['id']}/lock", json={"locked": False}, headers=tech)
    print("3) sblocco da utente Backup ->", r.status_code, "locked:", r.json().get("locked"))
    print("   DELETE diretto da utente Backup ->", client.delete(f"/api/backups/{b['id']}", headers=tech).status_code)

    # 4) Esportazione CSV: celle che iniziano con caratteri di formula restano come sono?
    p = client.post("/api/persons", json={"name": "Anna", "card": "04aa", "notes": "=1+1", "company": "+39 06 1234"}, headers=admin).json()
    csv_text = client.get("/api/export/persons.csv", headers=admin).text
    line = next(line for line in csv_text.splitlines() if "04aa" in line)
    print("4) riga CSV esportata:", line)

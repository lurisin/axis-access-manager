import re, sys
src = open(sys.argv[1]).read()
start = src.index("<script>")
lines = src.split("\n")
# map offset -> line
offsets = []
pos = 0
for i, l in enumerate(lines):
    offsets.append(pos)
    pos += len(l) + 1
import bisect
def line_of(off):
    return bisect.bisect_right(offsets, off)
i = start
out = []
while True:
    j = src.find("${", i)
    if j < 0: break
    # find matching }
    depth = 0
    k = j + 2
    d = 1
    while k < len(src) and d:
        c = src[k]
        if c == "{": d += 1
        elif c == "}": d -= 1
        k += 1
    expr = src[j+2:k-1]
    out.append((line_of(j), expr))
    i = j + 2
safe = re.compile(r'^\s*(esc\(|icon\(|plural\(|Number\(|pad\(|fmt|relTime|[0-9]|i\b|n\b)')
for ln, expr in out:
    e = expr.strip()
    if e.startswith("esc(") and e.count("esc(") == 1 and e.endswith(")") :
        continue
    if e.startswith("icon(") and "," not in e[:30]:
        continue
    print(f"{ln}: {e[:200]!s}")

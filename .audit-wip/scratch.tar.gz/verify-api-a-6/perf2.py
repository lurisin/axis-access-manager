import tempfile, time, random, json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from app.db import Database
for N in (100_000, 300_000):
    db = Database(Path(tempfile.mkdtemp()) / "p.db")
    start = datetime.now(tz=UTC) - timedelta(days=365)
    rows = []
    kinds = ["concesso", "lettura", "negato", "uscita", "apertura_remota"]
    raw = json.dumps({"CredentialHolderName": "utente_ciccio_bello_261025005209", "AccessPointToken": "accesso_via_consulta_ingresso_scala", "CredentialToken": "Axis-b8a44fe6a074:1792889564.863735000", "topic": "AccessControl/AccessGranted/Credential"})
    step = 365*86400 // N
    for i in range(N):
        ts = (start + timedelta(seconds=i * step)).isoformat(timespec="seconds")
        rows.append((ts, random.choice(kinds), "04aa", 1, "Anna", "", "controller", raw, random.choice(["porta", "porta2"]), 0, ""))
    with db._lock:
        db._conn.executemany("INSERT INTO events (ts, kind, card, person_id, person_name, detail, source, raw, door, recovered, ref) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
        db._conn.commit()
    for name, fn in [
        ("last_door_events", lambda: db.last_door_events(("concesso", "negato", "sconosciuta", "apertura_remota", "uscita", "citofono"))),
        ("last_accesses", db.last_accesses),
        ("door_event_counts today", lambda: db.door_event_counts((datetime.now(tz=UTC)-timedelta(hours=10)).isoformat(timespec="seconds"))),
    ]:
        fn()
        best = 1e9
        for _ in range(3):
            t = time.perf_counter(); fn(); best = min(best, time.perf_counter() - t)
        print(N, name, round(best * 1000), "ms")
    print(db._conn.execute("EXPLAIN QUERY PLAN SELECT door, ts, kind, person_name, card FROM (SELECT door, ts, kind, person_name, card, ROW_NUMBER() OVER (PARTITION BY door ORDER BY ts DESC, id DESC) AS n FROM events WHERE kind IN ('concesso','negato')) WHERE n = 1").fetchall())

import os, tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
os.environ.pop("SUPERVISOR_TOKEN", None)
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre", "mqtt_topic_prefix": "accessi/x"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=Path(tempfile.mkdtemp()) / "a.db")
with TestClient(app) as c:
    db = app.state.db
    start = datetime.now(tz=UTC) - timedelta(days=300)
    rows = [((start + timedelta(seconds=i * 500)).isoformat(timespec="seconds"), "concesso" if i % 2 else "lettura", "04aa", None, "Anna", "", "controller", "", "porta", 0, f"r{i}") for i in range(52_000)]
    with db._lock:
        db._conn.executemany("INSERT INTO events (ts, kind, card, person_id, person_name, detail, source, raw, door, recovered, ref) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
        db._conn.commit()
    r = c.get("/api/export/events.csv")
    lines = r.content.decode("utf-8-sig").splitlines()
    print("status", r.status_code, "db events", db._query("SELECT COUNT(*) n FROM events")[0]["n"], "csv data rows", len(lines) - 1)
    print("first", lines[1][:40], "last", lines[-1][:40], "oldest in db", rows[0][0])
    print("headers", {k: v for k, v in r.headers.items() if k.lower().startswith(("x-", "content-disp"))})

import asyncio, json
import aiomqtt
from app import events
from app.config import MqttSettings

class Msg:
    def __init__(self, topic, payload, retain=False):
        self.topic = aiomqtt.Topic(topic); self.payload = payload; self.retain = retain

class FakeClient:
    msgs = []
    def __init__(self, **kw): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def subscribe(self, *a, **k): pass
    @property
    def messages(self):
        async def gen():
            for m in FakeClient.msgs:
                yield m
                await asyncio.sleep(0)
            await asyncio.sleep(3600)
        return gen()

events.aiomqtt.Client = FakeClient
seen = []
async def main():
    m = events.EventMonitor(prefix="accessi/x")
    m.on_event = lambda e, r: seen.append(e.topic)
    FakeClient.msgs = [
        Msg("accessi/x/eventi/AccessControl/AccessGranted/Anonymous/", json.dumps({"timestamp": 1700000000000, "message": {}}).encode()),
        Msg("accessi/x/eventi/Device/Prova", json.dumps({"timestamp": 1.7e18}).encode()),
        Msg("accessi/x/eventi/AccessControl/AccessGranted/Anonymous/", json.dumps({"timestamp": 1700000001000, "message": {}}).encode()),
    ]
    s = MqttSettings(host="x", port=1883, username=None, password=None) if True else None
    t = asyncio.create_task(m.run(s))
    await asyncio.sleep(0.2)
    print("events seen:", seen)
    print("task done:", t.done(), "exc:", repr(t.exception()) if t.done() else None)
    print("connected:", m.connected, "client set:", m.client is not None, "outages:", m.outages)
asyncio.run(main())

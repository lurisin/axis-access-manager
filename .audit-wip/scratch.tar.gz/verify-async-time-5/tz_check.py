import os, time, asyncio, tempfile
os.environ["TZ"] = "Europe/Rome"; time.tzset()
from pathlib import Path
from conftest import FakeController
from app.db import Database
from app import health
from app.rules import schedule_ical
async def main():
    db = Database(Path(tempfile.mkdtemp()) / "a.db")
    c = FakeController(); c.time_zone = "UTC"
    hm = health.HealthMonitor(db, lambda row: c)
    st = await hm.check({"id": 1, "name": "A1210", "serial": "", "model": "", "firmware": "", "cert_fingerprint": "", "identity_change": "", "host": "h", "username": "u", "password": "p", "verify_ssl": False})
    print("offset:", st.clock_offset, "tz:", st.time_zone, "fault:", repr(health.clock_fault(st)), "problem:", health.clock_problem(st))
    print("HA local offset:", time.strftime("%z"))
    print(schedule_ical([{"start": "08:00", "end": "18:00", "days": ["MO"]}]))
asyncio.run(main())

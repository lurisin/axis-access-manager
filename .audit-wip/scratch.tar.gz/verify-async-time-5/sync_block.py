import asyncio, sys, tempfile, time
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService

N = int(sys.argv[1])
async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db")
    c = FakeController()
    for i in range(N):
        c.add_existing(f"utente_{i}", f"Persona {i}", f"{0x1000 + i:x}")
    s = parse_options({"a1210_host": "x", "door_token": "porta", "mqtt_topic_prefix": "accessi/x"})
    svc = AccessService(db, c, s)
    await svc.sync_from_controller()
    gaps = []
    stop = False
    async def ticker():
        last = time.perf_counter()
        while not stop:
            await asyncio.sleep(0.01)
            now = time.perf_counter(); gaps.append(now - last); last = now
    t = asyncio.create_task(ticker())
    await asyncio.sleep(0.05)
    t0 = time.perf_counter()
    await svc.sync_from_controller()
    el = time.perf_counter() - t0
    await asyncio.sleep(0.05)
    stop = True; await t
    print(f"N={N} sync={el:.3f}s max loop gap={max(gaps):.3f}s")
asyncio.run(main())

import asyncio, tempfile, os
from pathlib import Path
os.environ["TZ"]="Europe/Rome"
import time; time.tzset()
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService
from app.transfer import persons_csv, import_persons

async def main():
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp/"t.db")
    c = FakeController()
    s = parse_options({"a1210_host":"x","door_token":"porta","access_profile":"profilo_sempre","mqtt_topic_prefix":"a/x"})
    svc = AccessService(db, c, s)
    await svc.create_person("Anna", "04aa", "admin", valid_to="2026-12-31T23:59:59")
    groups=[{"token":"profilo_sempre","name":"Sempre"}]
    names={"profilo_sempre":"Sempre"}
    text = persons_csv(db.list_persons(), names, db.last_accesses(), {})
    print(repr(text))
    res = await import_persons(svc, text, groups, "admin", apply=False)
    print(res)
asyncio.run(main())

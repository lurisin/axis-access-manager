import asyncio, tempfile
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService
from app.transfer import persons_csv, import_persons

async def main():
    db = Database(Path(tempfile.mkdtemp())/"t.db")
    c = FakeController()
    s = parse_options({"a1210_host":"x","door_token":"porta","access_profile":"profilo_sempre","mqtt_topic_prefix":"a/x"})
    svc = AccessService(db, c, s)
    await svc.create_person("Anna", "04aa", "admin", company="ACME; srl", notes='riga1\nriga "2"; ok')
    p = await svc.create_person("Bruno", "04bb", "admin")
    await svc.set_card_enabled(p["cards"][0]["id"], False, "admin")
    groups=[{"token":"profilo_sempre","name":"Sempre"}]
    text = persons_csv(db.list_persons(), {"profilo_sempre":"Sempre"}, db.last_accesses(), {})
    print(repr(text))
    res = await import_persons(svc, text, groups, "admin", apply=False)
    for r in res["righe"]: print(r)
    # Reimport su un impianto nuovo (anagrafica persa): Bruno era sospeso
    db2 = Database(Path(tempfile.mkdtemp())/"t.db"); c2 = FakeController(); svc2 = AccessService(db2, c2, s)
    res = await import_persons(svc2, text, groups, "admin", apply=True)
    print(res["riepilogo"])
    for person in db2.list_persons():
        print(person["name"], [(cd["number"], cd["enabled"]) for cd in person["cards"]])
asyncio.run(main())

import asyncio, sys, tempfile, pathlib, contextlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from mini_broker import MiniBroker
from app.config import parse_options, MqttSettings
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge

async def main():
    broker = MiniBroker(); await broker.start()
    s = parse_options({"door_token": "porta"})
    db = Database(pathlib.Path(tempfile.mkdtemp())/"x.db")
    m = EventMonitor(prefix="accessi/x", door_token="porta")
    b = HaBridge(s, m, db, [{"id": 1, "door_token": "porta", "name": "Porta", "ha_buttons": True}])
    m.will = b.will(); m.on_connect = b.on_connect; m.command_topic = b.command_topic
    task = asyncio.create_task(m.run(MqttSettings(host="127.0.0.1", port=broker.port)))
    await asyncio.sleep(1.5)
    # Come _stop_runtime allo spegnimento dell'add-on
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task
    await asyncio.sleep(0.3)
    avail = [(t, p) for t, p, r in broker.published if t.endswith("/disponibile")]
    print("disponibilità pubblicata:", avail)
    print("ultimi pacchetti dal client:", broker.packets[-3:])
asyncio.run(main())

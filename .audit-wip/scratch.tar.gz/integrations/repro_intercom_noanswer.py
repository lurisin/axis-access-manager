from app.intercom import IntercomBridge, IntercomSettings
logged = []
t = [1000.0]
b = IntercomBridge(IntercomSettings("Citofono", open_door=False), log=lambda **f: logged.append(f["detail"]),
                   open_door=None, clock=lambda: t[0])
b.handle("hmd/sensor/Citofono/Call-state/state", b"ringing")
t[0] += 6
b.handle("hmd/switch/Citofono/Door-1-relay/attributes", b'{"unlock_type":"HOUSEHOLDER","control_source":"app"}')
b.handle("hmd/switch/Citofono/Door-1-relay/state", b"ON")
t[0] += 20
b.handle("hmd/sensor/Citofono/Call-state/state", b"idle")
print(logged)

import asyncio, os, tempfile
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
import aiomqtt
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.main import create_app

settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x", "intercom_name": "Citofono", "intercom_open_door": True,
                          "intercom_relay": 1})
controller = FakeController()
tmp = Path(tempfile.mkdtemp())
app = create_app(settings, allow_any_client=True, controller=controller, db_path=tmp / "a.db")
with TestClient(app) as client:
    st = app.state
    ctrl_id = st.installation.primary["id"]
    r = client.post(f"/api/controllers/{ctrl_id}/doors", json={"door_token": "porta2", "name": "Cancello",
        "intercom_name": "Citofono", "intercom_relay": 2, "intercom_open_door": True, "ha_buttons": False})
    print("create door", r.status_code, r.json())
    st = app.state
    print("bridges", [(i.door["door_token"], i.call_topic, i.relay_topic) for i in st.intercoms])
    print("subscriptions", {k: v.__self__.door["door_token"] for k, v in st.monitor.extra_subscriptions.items()})
    st.monitor.door_modes["porta"] = "Locked"
    st.monitor.door_modes["porta2"] = "Locked"
    async def scenario():
        m = st.monitor
        m._dispatch_extra(aiomqtt.Topic("hmd/sensor/Citofono/Call-state/state"), b"ringing")
        m._dispatch_extra(aiomqtt.Topic("hmd/switch/Citofono/Door-1-relay/attributes"), b'{"unlock_type":"HOUSEHOLDER","control_source":"app"}')
        m._dispatch_extra(aiomqtt.Topic("hmd/switch/Citofono/Door-1-relay/state"), b"ON")
        for _ in range(10): await asyncio.sleep(0)
        m._dispatch_extra(aiomqtt.Topic("hmd/sensor/Citofono/Call-state/state"), b"idle")
        for _ in range(10): await asyncio.sleep(0)
    client.portal.call(scenario)
    for e in reversed(st.db.list_events(limit=10)):
        print(e["kind"], "|", e["detail"], "|", e["source"], "| door:", e["door"])
    print("controller calls", [c for c in controller.calls if c[0] == "access_door"])

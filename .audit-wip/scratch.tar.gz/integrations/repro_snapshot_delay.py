import asyncio, os, tempfile, time
from pathlib import Path
os.environ.pop("SUPERVISOR_TOKEN", None)
os.environ["AAM_SCHEDULED_BACKUPS"] = "0"
import httpx
from fastapi.testclient import TestClient
from conftest import FakeController
from app.config import parse_options
from app.ha import HomeAssistant
from app.main import create_app

async def slow_camera(request):
    await asyncio.sleep(3)  # telecamera lenta (cloud, Wi-Fi)
    return httpx.Response(200, content=b"\xff\xd8jpeg")

def failing_disk(path):
    raise OSError(28, "No space left on device")

tmp = Path(tempfile.mkdtemp())
ha = HomeAssistant(token="t", snapshot_dir=tmp / "media")
ha._client = httpx.AsyncClient(base_url="http://supervisor/core/api", transport=httpx.MockTransport(slow_camera))
settings = parse_options({"a1210_host": "a1210.local", "door_token": "porta", "access_profile": "profilo_sempre",
                          "mqtt_topic_prefix": "accessi/x", "snapshot_camera": "camera.ingresso"})
app = create_app(settings, allow_any_client=True, controller=FakeController(), db_path=tmp / "a.db", home_assistant=ha)
with TestClient(app) as client:
    st = app.state
    sent = []
    async def publish_event(row):
        sent.append((row["kind"], time.monotonic()))
    st.bridge.publish_event = publish_event
    async def scenario(fail=False):
        if fail:
            import app.ha as hamod
            orig = Path.write_bytes
            Path.write_bytes = lambda self, data: failing_disk(self)
        t0 = time.monotonic()
        st.service.log_event(ts=st.service.event_now(), kind="citofono", detail="ha suonato", source="Citofono", door="porta")
        await asyncio.sleep(4)
        if fail:
            Path.write_bytes = orig
        return t0
    t0 = client.portal.call(scenario)
    print("evento HA 'citofono' pubblicato dopo %.1f s" % (sent[0][1] - t0) if sent else "evento non pubblicato")
    sent.clear()
    client.portal.call(scenario, True)
    print("con disco pieno:", "evento HA pubblicato" if sent else "evento HA NON pubblicato")

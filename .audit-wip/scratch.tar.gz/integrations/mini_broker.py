"""Broker MQTT 3.1.1 minimo per le prove: CONNACK, SUBACK, PUBACK, registra i PUBLISH ricevuti e la DISCONNECT."""
import asyncio

class MiniBroker:
    def __init__(self):
        self.published = []
        self.packets = []
        self.server = None
        self.port = None

    async def start(self):
        self.server = await asyncio.start_server(self._client, "127.0.0.1", 0)
        self.port = self.server.sockets[0].getsockname()[1]

    async def _read_packet(self, reader):
        header = await reader.readexactly(1)
        mult, length = 1, 0
        while True:
            b = (await reader.readexactly(1))[0]
            length += (b & 127) * mult
            mult *= 128
            if not b & 128:
                break
        body = await reader.readexactly(length) if length else b""
        return header[0], body

    async def _client(self, reader, writer):
        try:
            while True:
                h, body = await self._read_packet(reader)
                kind = h >> 4
                self.packets.append(kind)
                if kind == 1:  # CONNECT
                    writer.write(bytes([0x20, 2, 0, 0]))
                elif kind == 8:  # SUBSCRIBE
                    pid = body[:2]
                    writer.write(bytes([0x90, 3]) + pid + bytes([1]))
                elif kind == 3:  # PUBLISH
                    qos = (h >> 1) & 3
                    tl = int.from_bytes(body[:2], "big")
                    topic = body[2:2 + tl].decode()
                    rest = body[2 + tl:]
                    if qos:
                        pid, rest = rest[:2], rest[2:]
                        writer.write(bytes([0x40, 2]) + pid)
                    self.published.append((topic, rest, bool(h & 1)))
                elif kind == 12:  # PINGREQ
                    writer.write(bytes([0xD0, 0]))
                elif kind == 14:  # DISCONNECT
                    self.packets.append("DISCONNECT")
                    writer.close()
                    return
                await writer.drain()
        except (asyncio.IncompleteReadError, ConnectionError):
            self.packets.append("EOF")

"""Prefisso del controller uguale a ha_topic_prefix: lo stato JSON dell'add-on finisce su <prefisso>/stato,
lo stesso topic del messaggio online/offline del controller. Il broker è simulato: ogni publish torna ai sottoscrittori."""
import asyncio, tempfile
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge
from app.service import AccessService

async def main():
    db = Database(Path(tempfile.mkdtemp())/"t.db")
    s = parse_options({"a1210_host": "x", "door_token": "porta", "mqtt_topic_prefix": "axis_access_manager"})
    monitor = EventMonitor(prefix="axis_access_manager", door_token="porta")
    service = AccessService(db, FakeController(), s, monitor)
    bridge = HaBridge(s, monitor, db, [{"id": 1, "door_token": "porta", "name": "Porta", "ha_buttons": True}])
    monitor.on_event = service.record_event; monitor.on_status = service.notify_change
    async def on_change(): await bridge.publish_state()
    service.on_change = on_change
    count = 0
    monitor.connected = True; monitor.client = object()
    async def publish(topic, payload, retain=False):
        nonlocal count
        count += 1
        monitor.handle(topic, payload.encode() if isinstance(payload, str) else payload)  # eco del broker
        return True
    monitor.publish = publish
    monitor.handle("axis_access_manager/stato", b"online")  # LWT del controller: online
    await asyncio.sleep(1)
    print("controller_online:", monitor.controller_online, "| pubblicazioni dello stato in 1 s:", count)
asyncio.run(main())

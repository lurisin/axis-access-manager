import asyncio, tempfile
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService
from app.transfer import import_persons

# File salvato da Excel come "CSV (delimitato dal separatore di elenco)": Windows-1252
raw = "nome;tessera;ditta;note\r\nNiccolò Bartolè;04cc;Caffè Società;chiavi più badge\r\n".encode("cp1252")
# Il browser lo legge con file.text(), sempre in UTF-8 (caratteri non validi -> U+FFFD)
text = raw.decode("utf-8", errors="replace")

async def main():
    db = Database(Path(tempfile.mkdtemp())/"t.db")
    c = FakeController()
    s = parse_options({"a1210_host":"x","door_token":"porta","access_profile":"profilo_sempre","mqtt_topic_prefix":"a/x"})
    svc = AccessService(db, c, s)
    res = await import_persons(svc, text, [{"token":"profilo_sempre","name":"Sempre"}], "admin", apply=True)
    print(res["righe"])
    p = db.list_persons()[0]
    print(repr(p["name"]), repr(p["company"]), repr(p["notes"]))
    print("utente sul controller:", [u["Name"] for u in c.users.values()])
asyncio.run(main())

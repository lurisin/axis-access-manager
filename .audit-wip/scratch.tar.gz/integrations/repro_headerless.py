import asyncio, tempfile
from pathlib import Path
from conftest import FakeController
from app.config import parse_options
from app.db import Database
from app.service import AccessService
from app.transfer import import_persons

async def main():
    db = Database(Path(tempfile.mkdtemp())/"t.db")
    c = FakeController()
    s = parse_options({"a1210_host":"x","door_token":"porta","access_profile":"profilo_sempre","mqtt_topic_prefix":"a/x"})
    svc = AccessService(db, c, s)
    p = await svc.create_person("Anna", "04aa", "admin", valid_to="2026-01-31T23:59:59", company="ACME", notes="badge temporaneo")
    groups=[{"token":"profilo_sempre","name":"Sempre"}]
    # File senza intestazione con solo nome e tessera (le colonne "obbligatorie")
    res = await import_persons(svc, "Anna;04aa\nLuca;04bb\n", groups, "admin", apply=False)
    print(res["righe"][0])
    res = await import_persons(svc, "Anna;04aa\nLuca;04bb\n", groups, "admin", apply=True)
    a = db.get_person(p["id"])
    print("dopo:", a["company"], "|", a["notes"], "|", a["cards"][0]["valid_to"])
    # Stesso contenuto con intestazione: nessuna modifica
    db2 = Database(Path(tempfile.mkdtemp())/"t.db"); svc2 = AccessService(db2, FakeController(), s)
    await svc2.create_person("Anna", "04aa", "admin", valid_to="2026-01-31T23:59:59", company="ACME")
    print((await import_persons(svc2, "nome;tessera\nAnna;04aa\n", groups, "admin", apply=False))["righe"][0])
asyncio.run(main())

import asyncio, tempfile
from pathlib import Path
from app.config import parse_options
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge

class FakeClient:
    def __init__(self): self.published = {}
    async def publish(self, topic, payload, qos=0, retain=False): self.published[topic] = payload

async def main():
    db = Database(Path(tempfile.mkdtemp()) / "t.db")
    s = parse_options({"door_token": "porta"})
    before = [{"id": 1, "door_token": "porta", "name": "Ingresso", "ha_buttons": True},
              {"id": 2, "door_token": "porta2", "name": "Cantina", "ha_buttons": True}]
    broker = FakeClient()
    await HaBridge(s, EventMonitor(prefix="x", door_token="porta"), db, before).on_connect(broker)
    retained_before = {t for t, p in broker.published.items() if t.startswith("homeassistant/") and p}
    # Caso 1: pulsanti tolti dalla seconda porta
    after = [before[0], {**before[1], "ha_buttons": False}]
    await HaBridge(s, EventMonitor(prefix="x", door_token="porta"), db, after).on_connect(broker)
    print("pulsanti spenti, config ancora pubblicata:",
          [t for t in retained_before if broker.published[t] and "apri" in t])
    # Caso 2: seconda porta rimossa
    await HaBridge(s, EventMonitor(prefix="x", door_token="porta"), db, [before[0]]).on_connect(broker)
    print("porta rimossa, entità rimaste:", sorted(t.split("/")[3] for t in retained_before if broker.published[t] and t.split("/")[3].endswith("_2")))
    # Caso 3: integrazione disattivata
    off = parse_options({"door_token": "porta", "ha_integration": False})
    await HaBridge(off, EventMonitor(prefix="x", door_token="porta"), db, [before[0]]).on_connect(broker)
    print("integrazione spenta, entità rimaste:", sorted(t.split("/")[3] for t in retained_before if broker.published[t]))
asyncio.run(main())

import asyncio, sys, tempfile, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from mini_broker import MiniBroker
from app.config import parse_options, MqttSettings
from app.db import Database
from app.events import EventMonitor
from app.ha_mqtt import HaBridge

async def main():
    broker = MiniBroker(); await broker.start()
    s = parse_options({"ha_topic_prefix": "accessi#casa", "door_token": "porta"})
    db = Database(pathlib.Path(tempfile.mkdtemp())/"x.db")
    m = EventMonitor(prefix="accessi/x", door_token="porta")
    b = HaBridge(s, m, db, [{"id": 1, "door_token": "porta", "name": "Porta", "ha_buttons": True}])
    m.will = b.will(); m.on_connect = b.on_connect; m.command_topic = b.command_topic
    task = asyncio.create_task(m.run(MqttSettings(host="127.0.0.1", port=broker.port)))
    await asyncio.sleep(2)
    print("task finito:", task.done(), "| eccezione:", repr(task.exception()) if task.done() else None)
    print("connected:", m.connected, "| entità pubblicate:", len(broker.published))
asyncio.run(main())

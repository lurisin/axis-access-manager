import re, sys
lines = open(sys.argv[1], encoding="utf-8").read().split("\n")
seen = {}
for n, line in enumerate(lines, 1):
    if n < 615: continue
    code = line.split("//")[0] if line.strip().startswith("//") else line
    if line.strip().startswith("//"): continue
    for m in re.finditer(r'"((?:[^"\\]|\\.)*)"|\'((?:[^\'\\]|\\.)*)\'', code):
        s = m.group(1) if m.group(1) is not None else m.group(2)
        if not s or not re.search(r"[A-Za-zÀ-ú]{2}", s): continue
        if re.fullmatch(r"[a-z_\-:#./\[\]=*0-9 ,()>]+", s) and " " not in s and len(s) < 40: continue  # identifiers/selectors
        if s.startswith(("api/", "#", ".", "[")) : continue
        seen.setdefault(s, []).append(n)
for s, ns in seen.items():
    print(f"{ns[0]}\t{len(ns)}\t{s[:160]}")

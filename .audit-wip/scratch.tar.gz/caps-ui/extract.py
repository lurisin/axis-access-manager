import re, sys
path = sys.argv[1]
lines = open(path, encoding="utf-8").read().split("\n")
# strip ${...} expressions (non-nested approx) to keep literal text
def strip_expr(s):
    out, depth, i = [], 0, 0
    while i < len(s):
        if s.startswith("${", i):
            depth += 1; i += 2; out.append("⟨"); continue
        if depth and s[i] == "{": depth += 1
        elif depth and s[i] == "}":
            depth -= 1
            if depth == 0: out.append("⟩"); i += 1; continue
        if depth == 0: out.append(s[i])
        i += 1
    return "".join(out)
pats = {
 "h2": r"<h2[^>]*>(.*?)(?:<span class=\"spacer|</h2>|<button|<a )",
 "h3": r"<h3[^>]*>(.*?)</h3>",
 "th": r"<th[^>]*>(.*?)</th>",
 "label": r"<label[^>]*>(.*?)</label>",
 "option": r"<option[^>]*>(.*?)</option>",
 "button": r"<button[^>]*>(.*?)</button>",
 "a": r"<a [^>]*>(.*?)</a>",
 "pill": r"<span class=\"pill[^\"]*\"[^>]*>(.*?)</span>",
 "empty": r"<div class=\"(?:empty|n-empty)\">(.*?)</div>",
 "b": r"<b[^>]*>(.*?)</b>",
 "summary": r"<summary[^>]*>(.*?)</summary>",
 "dt": r"<dt>(.*?)</dt>",
}
for name, pat in pats.items():
    print("=====", name)
    for n, line in enumerate(lines, 1):
        if n < 576: continue
        s = strip_expr(line)
        for m in re.finditer(pat, s):
            t = re.sub(r"<[^>]+>", "", m.group(1)).strip()
            if t and re.search(r"[A-Za-zÀ-ú]", t):
                print(f"{n}\t{t}")
